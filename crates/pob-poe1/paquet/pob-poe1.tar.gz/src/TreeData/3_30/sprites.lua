return {
    ["extraImages"]= {
        [1]= {
            ["x"]= -4560.69,
            ["y"]= 292.425,
            ["image"]= "Art/2DArt/BaseClassIllustrations/Str.png"
        },
        [2]= {
            ["x"]= 1994.17,
            ["y"]= 387.525,
            ["image"]= "Art/2DArt/BaseClassIllustrations/Dex.png"
        },
        [3]= {
            ["x"]= -1535.86,
            ["y"]= -3848.79,
            ["image"]= "Art/2DArt/BaseClassIllustrations/Int.png"
        },
        [4]= {
            ["x"]= -1956.43,
            ["y"]= 1756.39,
            ["image"]= "Art/2DArt/BaseClassIllustrations/StrDex.png"
        },
        [5]= {
            ["x"]= -3755.23,
            ["y"]= -3210.21,
            ["image"]= "Art/2DArt/BaseClassIllustrations/StrInt.png"
        },
        [6]= {
            ["x"]= 1704.07,
            ["y"]= -3799.71,
            ["image"]= "Art/2DArt/BaseClassIllustrations/DexInt.png"
        }
    },
    ["sprites"]= {
        ["background"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/background-3.png?f8ce4f31",
            ["w"]= 98,
            ["h"]= 98,
            ["coords"]= {
                ["Background2"]= {
                    ["x"]= 0,
                    ["y"]= 0,
                    ["w"]= 98,
                    ["h"]= 98
                }
            }
        },
        ["normalActive"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/skills-3.jpg?bdc2a0fd",
            ["w"]= 999,
            ["h"]= 1496,
            ["coords"]= {
                ["Art/2DArt/SkillIcons/passives/2handeddamage.png"]= {
                    ["x"]= 0,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/2handedspeed.png"]= {
                    ["x"]= 26,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AbyssRevampGazeoftheLichNode1.png"]= {
                    ["x"]= 52,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AbyssRevampGazeoftheLichNode2.png"]= {
                    ["x"]= 78,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AbyssRevampGazeoftheLichNode3.png"]= {
                    ["x"]= 104,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AbyssRevampGazeoftheLichNode4.png"]= {
                    ["x"]= 130,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AccuracyTemplarNode.png"]= {
                    ["x"]= 156,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AilmentDamageCritMultiplier.png"]= {
                    ["x"]= 182,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AreaDmgNode.png"]= {
                    ["x"]= 208,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AreaofEffectofMinionsNode.png"]= {
                    ["x"]= 234,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ArkhonsTools.png"]= {
                    ["x"]= 260,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ArmourAndEnergyShieldNode.png"]= {
                    ["x"]= 286,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ArmourAndEvasionNode.png"]= {
                    ["x"]= 312,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ArmourNode.png"]= {
                    ["x"]= 338,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Assassin.png"]= {
                    ["x"]= 364,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Berserker.png"]= {
                    ["x"]= 390,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Champion.png"]= {
                    ["x"]= 416,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Chieftain.png"]= {
                    ["x"]= 442,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Deadeye.png"]= {
                    ["x"]= 468,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Elementalist.png"]= {
                    ["x"]= 494,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Gladiator.png"]= {
                    ["x"]= 520,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Guardian.png"]= {
                    ["x"]= 546,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Hierophant.png"]= {
                    ["x"]= 572,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Inquisitor.png"]= {
                    ["x"]= 598,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Juggernaut.png"]= {
                    ["x"]= 624,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Necromancer.png"]= {
                    ["x"]= 650,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Occultist.png"]= {
                    ["x"]= 676,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Pathfinder.png"]= {
                    ["x"]= 702,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Raider.png"]= {
                    ["x"]= 728,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Saboteur.png"]= {
                    ["x"]= 754,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/SkillPoint.png"]= {
                    ["x"]= 780,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Slayer.png"]= {
                    ["x"]= 806,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Trickster.png"]= {
                    ["x"]= 832,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/Ambush.png"]= {
                    ["x"]= 858,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/SmallNode.png"]= {
                    ["x"]= 884,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/AbyssNode1.png"]= {
                    ["x"]= 910,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/AbyssNotable1.png"]= {
                    ["x"]= 936,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/AulBloodlineNode.png"]= {
                    ["x"]= 962,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/AulBloodlinechargedex.png"]= {
                    ["x"]= 0,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/AulBloodlinechargeint.png"]= {
                    ["x"]= 26,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/AulBloodlinechargestr.png"]= {
                    ["x"]= 52,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BestiaryNode1.png"]= {
                    ["x"]= 78,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BestiaryNotable4.png"]= {
                    ["x"]= 104,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BestiaryNotable5.png"]= {
                    ["x"]= 130,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BestiaryNotable6.png"]= {
                    ["x"]= 156,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BloodLineOlrothRune1.png"]= {
                    ["x"]= 182,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BloodLineOlrothRune2.png"]= {
                    ["x"]= 208,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BloodLineOlrothRune3.png"]= {
                    ["x"]= 234,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BoldUndertaking.png"]= {
                    ["x"]= 260,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BreachBossClaspedHands.png"]= {
                    ["x"]= 286,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/DeliriumNode1.png"]= {
                    ["x"]= 312,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/ExpeditionNode1.png"]= {
                    ["x"]= 338,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/HarbingerNotable3.png"]= {
                    ["x"]= 364,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/LichNode1.png"]= {
                    ["x"]= 390,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/LyciaNode1.png"]= {
                    ["x"]= 416,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/MorePrimalWispsSmall.png"]= {
                    ["x"]= 442,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/MoreVividWispsSmall.png"]= {
                    ["x"]= 468,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/MoreWildWispsSmall.png"]= {
                    ["x"]= 494,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/PerandusNotable2.png"]= {
                    ["x"]= 520,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RitualBloodlineNode.png"]= {
                    ["x"]= 546,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/UltimatumNode1.png"]= {
                    ["x"]= 572,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/UltimatumNotable6.png"]= {
                    ["x"]= 598,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/UltimatumNotableMonsters1.png"]= {
                    ["x"]= 624,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/UltimatumNotableMonsters2.png"]= {
                    ["x"]= 650,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/UltimatumNotableStoneCircle.png"]= {
                    ["x"]= 676,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AttackBlindNode.png"]= {
                    ["x"]= 702,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AttackDamangeAndEvasionNotableNode.png"]= {
                    ["x"]= 728,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AttackPoisonNode.png"]= {
                    ["x"]= 754,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AuraEffectNode.png"]= {
                    ["x"]= 780,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BannerAreaNode.png"]= {
                    ["x"]= 806,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BannerDurationNode.png"]= {
                    ["x"]= 832,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BannerEffectNode.png"]= {
                    ["x"]= 858,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BannerResourceAreaNode.png"]= {
                    ["x"]= 884,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/DmgAttackSpeed.png"]= {
                    ["x"]= 910,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/DmgCrit.png"]= {
                    ["x"]= 936,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/DmgLeech.png"]= {
                    ["x"]= 962,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/DmgWarcry.png"]= {
                    ["x"]= 0,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BlackFlameFire.png"]= {
                    ["x"]= 26,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BleedAndPoisonMitigateNode.png"]= {
                    ["x"]= 52,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BlockAttackDmgNode.png"]= {
                    ["x"]= 78,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BlockSpellDmgNode.png"]= {
                    ["x"]= 104,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Blood2.png"]= {
                    ["x"]= 130,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BluntInstrument.png"]= {
                    ["x"]= 156,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BowDamage.png"]= {
                    ["x"]= 182,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BoxOfJewels.png"]= {
                    ["x"]= 208,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Brand1.png"]= {
                    ["x"]= 234,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Brand2.png"]= {
                    ["x"]= 260,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BrandDmgNode.png"]= {
                    ["x"]= 286,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BrassDomeNode.png"]= {
                    ["x"]= 312,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Champion/AnEAttDamage.png"]= {
                    ["x"]= 338,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Champion/AnEAura.png"]= {
                    ["x"]= 364,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Champion/AnEFortify.png"]= {
                    ["x"]= 390,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Champion/AnETaunt.png"]= {
                    ["x"]= 416,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Champion/ImpalePassive.png"]= {
                    ["x"]= 442,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ChaosDamage.png"]= {
                    ["x"]= 468,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ChaosDamageOverTimeNode.png"]= {
                    ["x"]= 494,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ChaosDamagenode.png"]= {
                    ["x"]= 520,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ChaosResistNode.png"]= {
                    ["x"]= 546,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ChaosResistNotable.png"]= {
                    ["x"]= 572,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/LifeRegenFireDamage.png"]= {
                    ["x"]= 598,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/LifeRegenStrength.png"]= {
                    ["x"]= 624,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/LifeRegenTotemPlacementSpeed.png"]= {
                    ["x"]= 650,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ChoiroftheStorm.png"]= {
                    ["x"]= 676,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ClawCritStrikeChanceNode.png"]= {
                    ["x"]= 702,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ColdAndFireHybridNode.png"]= {
                    ["x"]= 728,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ColdDamageOverTimeNode.png"]= {
                    ["x"]= 754,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ColdDamagenode.png"]= {
                    ["x"]= 780,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ColdResistNode.png"]= {
                    ["x"]= 806,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CooldownWarcryNode1.png"]= {
                    ["x"]= 832,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CorpseDamage.png"]= {
                    ["x"]= 858,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CorpseLife.png"]= {
                    ["x"]= 884,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CrownOfTheInwardEye.png"]= {
                    ["x"]= 910,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CrustaceansCall.png"]= {
                    ["x"]= 936,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CrustaceousGrowth.png"]= {
                    ["x"]= 962,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CurseAreaofEffect.png"]= {
                    ["x"]= 0,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CurseCastSpeed.png"]= {
                    ["x"]= 26,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CurseDuration.png"]= {
                    ["x"]= 52,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CurseEffectNode.png"]= {
                    ["x"]= 78,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CurseManaCost.png"]= {
                    ["x"]= 104,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CurseManaReservation.png"]= {
                    ["x"]= 130,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CursemitigationclusterNode.png"]= {
                    ["x"]= 156,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DamageOverTime.png"]= {
                    ["x"]= 182,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DamageOverTimeNode.png"]= {
                    ["x"]= 208,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DeadEye/ProjectileDamageAccuracy.png"]= {
                    ["x"]= 234,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DeadEye/ProjectileDamageAttackSpeed.png"]= {
                    ["x"]= 260,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Deathsdoor.png"]= {
                    ["x"]= 286,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DivineFury.png"]= {
                    ["x"]= 312,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DivineWrath.png"]= {
                    ["x"]= 338,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DmgHeraldSkillsNode.png"]= {
                    ["x"]= 364,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DmgWhenChannelSkillsNode.png"]= {
                    ["x"]= 390,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DodgeAtksNode.png"]= {
                    ["x"]= 416,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DraugursLantern.png"]= {
                    ["x"]= 442,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DualWieldNodeDefensive.png"]= {
                    ["x"]= 468,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DualWieldNodeOffensive.png"]= {
                    ["x"]= 494,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DurationofMinionsNode.png"]= {
                    ["x"]= 520,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ElementalDamagenode.png"]= {
                    ["x"]= 546,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ElementalResistance2.png"]= {
                    ["x"]= 572,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/ElementalDamageAttackCasteSpeed.png"]= {
                    ["x"]= 598,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/ElementalDamageElementalResistances.png"]= {
                    ["x"]= 624,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/ElementalDamageFreezeShockIgnite.png"]= {
                    ["x"]= 650,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/EmpoweredAttackWarcryNode1.png"]= {
                    ["x"]= 676,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/EnergyShieldNode.png"]= {
                    ["x"]= 702,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/EnergyshieldLeechPassivessmall.png"]= {
                    ["x"]= 728,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/EssentiaSanguis.png"]= {
                    ["x"]= 754,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/EvasionNode.png"]= {
                    ["x"]= 780,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/EvasionandEnergyShieldNode.png"]= {
                    ["x"]= 806,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/FesteringResentment.png"]= {
                    ["x"]= 832,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/FireDamageOverTimeNode.png"]= {
                    ["x"]= 858,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/FireDamagenode.png"]= {
                    ["x"]= 884,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/FireResistNode.png"]= {
                    ["x"]= 910,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/FlaskDurationnode.png"]= {
                    ["x"]= 936,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/FortifyNode.png"]= {
                    ["x"]= 962,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/GenericWarcryNode1.png"]= {
                    ["x"]= 0,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/GenericWarcryNode2.png"]= {
                    ["x"]= 26,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/GenericWarcryNode3.png"]= {
                    ["x"]= 52,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GLADBlockChance.png"]= {
                    ["x"]= 78,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GLADOneHand.png"]= {
                    ["x"]= 104,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/GoddessScales.png"]= {
                    ["x"]= 130,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/GolemsNode.png"]= {
                    ["x"]= 156,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/GreenPhysicalDamageNode.png"]= {
                    ["x"]= 182,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/ArmourEnergyMeleeDamage.png"]= {
                    ["x"]= 208,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/ArmourEnergyShieldDefenseFromShields.png"]= {
                    ["x"]= 234,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/ArmourEnergyShieldManaPool.png"]= {
                    ["x"]= 260,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/ArmourEnergyShieldStaves.png"]= {
                    ["x"]= 286,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/GuardianHallowingFlameNode.png"]= {
                    ["x"]= 312,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/Minion Damage Armour and Energy Shield.png"]= {
                    ["x"]= 338,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/TimeOfNeed.png"]= {
                    ["x"]= 364,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/HalfColdHalfLightning.png"]= {
                    ["x"]= 390,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/HeraldBuffEffectNode2.png"]= {
                    ["x"]= 416,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/HeraldDamageNotable.png"]= {
                    ["x"]= 442,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/HeraldReservationNode.png"]= {
                    ["x"]= 468,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/ManaRegen.png"]= {
                    ["x"]= 494,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IgniteBleedNode.png"]= {
                    ["x"]= 520,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ImapleNode.png"]= {
                    ["x"]= 546,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ImpaleNode2.png"]= {
                    ["x"]= 572,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreaseCritChanceNode.png"]= {
                    ["x"]= 598,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreaseMinionLifeNode.png"]= {
                    ["x"]= 624,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedAttackDamageNode.png"]= {
                    ["x"]= 650,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedManaCostNode.png"]= {
                    ["x"]= 676,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedMaximumLifeNode.png"]= {
                    ["x"]= 702,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedMinionDamageNode.png"]= {
                    ["x"]= 728,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedNonDamageAilmentNode.png"]= {
                    ["x"]= 754,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedProjectileSpeedNode.png"]= {
                    ["x"]= 780,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedSpellDamageNode.png"]= {
                    ["x"]= 806,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedWarcryNode.png"]= {
                    ["x"]= 832,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/IncreasedElementalDamageAttackCasteSpeed.png"]= {
                    ["x"]= 858,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/IncreasedElementalDamageAvoidElementalStatusEffects.png"]= {
                    ["x"]= 884,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/IncreasedElementalDamageCasteSpeed.png"]= {
                    ["x"]= 910,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/IncreasedElementalDamageElementalPenetration.png"]= {
                    ["x"]= 936,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/IncreasedArmourAttackDamage.png"]= {
                    ["x"]= 962,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/IncreasedArmourAttackSpeed.png"]= {
                    ["x"]= 0,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/IncreasedArmourLifeRegeneration.png"]= {
                    ["x"]= 26,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/IncreasedArmourMovementSpeed.png"]= {
                    ["x"]= 52,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/IncreasedArmourStunDuration.png"]= {
                    ["x"]= 78,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/JuggernautArmourNotable.png"]= {
                    ["x"]= 104,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneArmourMaster.png"]= {
                    ["x"]= 130,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LifeAndEnergyShield.png"]= {
                    ["x"]= 156,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LifeAndReducedManaCost.png"]= {
                    ["x"]= 182,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LifeManaFlasksrecoverynode.png"]= {
                    ["x"]= 208,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LifeRecoupNode.png"]= {
                    ["x"]= 234,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LifeandCurses.png"]= {
                    ["x"]= 260,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LifeandMana.png"]= {
                    ["x"]= 286,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LightningDamagenode.png"]= {
                    ["x"]= 312,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LightningResistNode.png"]= {
                    ["x"]= 338,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LivingBlade.png"]= {
                    ["x"]= 364,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNode.png"]= {
                    ["x"]= 390,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable9.png"]= {
                    ["x"]= 416,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable10.png"]= {
                    ["x"]= 442,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable11.png"]= {
                    ["x"]= 468,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable12.png"]= {
                    ["x"]= 494,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable13.png"]= {
                    ["x"]= 520,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable14.png"]= {
                    ["x"]= 546,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MaceElemental.png"]= {
                    ["x"]= 572,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ManaAndEnergyShield.png"]= {
                    ["x"]= 598,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ManaLeechThemedNode.png"]= {
                    ["x"]= 624,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ManaandCurses2.png"]= {
                    ["x"]= 650,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MarkNode.png"]= {
                    ["x"]= 676,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MasteryBlank.png"]= {
                    ["x"]= 702,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MaxManaNode.png"]= {
                    ["x"]= 728,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MeleeAoENode.png"]= {
                    ["x"]= 754,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MeleeCriticalStrikeChanceNode.png"]= {
                    ["x"]= 780,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MeleeCriticalStrikeMultiplierNode.png"]= {
                    ["x"]= 806,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MeleeFireNode.png"]= {
                    ["x"]= 832,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MineAreaOfEffectNode.png"]= {
                    ["x"]= 858,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MineManaReservationNode.png"]= {
                    ["x"]= 884,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MinionAccuracyDamage.png"]= {
                    ["x"]= 910,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MinionChaosResistanceNode.png"]= {
                    ["x"]= 936,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MinionDmgHeraldSkillsNode.png"]= {
                    ["x"]= 962,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MinionElementalResistancesNode.png"]= {
                    ["x"]= 0,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MonasteryBell.png"]= {
                    ["x"]= 26,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MovementSpeedandEvasionPassive.png"]= {
                    ["x"]= 52,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NaturalHeirachy.png"]= {
                    ["x"]= 78,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/CorpseConsumptionNode.png"]= {
                    ["x"]= 104,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/IncreasedMinionDamageIncreasedMinionLife.png"]= {
                    ["x"]= 130,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/IncreasedMinionDamageIncreasedSkillDuration.png"]= {
                    ["x"]= 156,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/ManaNode.png"]= {
                    ["x"]= 182,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NodeAxeandSwordDamage.png"]= {
                    ["x"]= 208,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NodeBowDamage.png"]= {
                    ["x"]= 234,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NodeDaggerandClawDamage.png"]= {
                    ["x"]= 260,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NodeDualWieldingDamage.png"]= {
                    ["x"]= 286,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NodeHoldingShieldDamage.png"]= {
                    ["x"]= 312,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NodeMaceandStaffDamage.png"]= {
                    ["x"]= 338,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NodeTwoHandedMeleeDamage.png"]= {
                    ["x"]= 364,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NodeWandDamage.png"]= {
                    ["x"]= 390,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/EnergyShieldChaos.png"]= {
                    ["x"]= 416,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/EnergyShieldCold.png"]= {
                    ["x"]= 442,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/IncreasedEnergyShieldAttackAndCastSpeed.png"]= {
                    ["x"]= 468,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/IncreasedEnergyShieldCriticalStrikeChance.png"]= {
                    ["x"]= 494,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/IncreasedEnergyShieldManaReservation.png"]= {
                    ["x"]= 520,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/IncreasedEnergyShieldMaximumMana.png"]= {
                    ["x"]= 546,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/OneHandedPhysicalAndLeechNode.png"]= {
                    ["x"]= 572,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/OneHandedPhysicalAndLeechNotable.png"]= {
                    ["x"]= 598,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/FlaskEffectDamageOverTime.png"]= {
                    ["x"]= 624,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/FlaskEffectElementalResistance.png"]= {
                    ["x"]= 650,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/FlaskEffectFlaskDuration.png"]= {
                    ["x"]= 676,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageNode.png"]= {
                    ["x"]= 702,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageOverTimeNode.png"]= {
                    ["x"]= 728,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageOverTimenode3.png"]= {
                    ["x"]= 754,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamagenode2.png"]= {
                    ["x"]= 780,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalandChaosDamage.png"]= {
                    ["x"]= 806,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Poison.png"]= {
                    ["x"]= 832,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PoisonSpellsNode.png"]= {
                    ["x"]= 858,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Praxis.png"]= {
                    ["x"]= 884,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Primalist/PrimalistNode.png"]= {
                    ["x"]= 910,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ProjectileDmgNode.png"]= {
                    ["x"]= 936,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ProjectilesNode.png"]= {
                    ["x"]= 962,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ProjectilesNode2.png"]= {
                    ["x"]= 0,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Rage.png"]= {
                    ["x"]= 26,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Raider/IncreasedElementalDamage.png"]= {
                    ["x"]= 52,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RangedTotemAttackSpeed.png"]= {
                    ["x"]= 78,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RangedTotemDamage.png"]= {
                    ["x"]= 104,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RedAttackSmallPassive.png"]= {
                    ["x"]= 130,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ReducedManaCostNode.png"]= {
                    ["x"]= 156,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ReducedSkillEffectDurationNode.png"]= {
                    ["x"]= 182,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationNode1.png"]= {
                    ["x"]= 208,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationNode2.png"]= {
                    ["x"]= 234,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationNode3.png"]= {
                    ["x"]= 260,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationNode4.png"]= {
                    ["x"]= 286,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationNode5.png"]= {
                    ["x"]= 312,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RigwaldsQuills.png"]= {
                    ["x"]= 338,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/ElementalDamageElementalResistance.png"]= {
                    ["x"]= 364,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/ElementalDamageMines.png"]= {
                    ["x"]= 390,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/ElementalDamageMovementSpeed.png"]= {
                    ["x"]= 416,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SareshBloodlineNode.png"]= {
                    ["x"]= 442,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ShadowStitch.png"]= {
                    ["x"]= 468,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SharpandBrittle.png"]= {
                    ["x"]= 494,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ShieldAttackDamage.png"]= {
                    ["x"]= 520,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ShieldNodeOffensive.png"]= {
                    ["x"]= 546,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/2HdmgAOE.png"]= {
                    ["x"]= 572,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/2HdmgCritStrikeMultiplier.png"]= {
                    ["x"]= 598,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/2HdmgFrenzyEnduranceCharge.png"]= {
                    ["x"]= 624,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/2HdmgLeech.png"]= {
                    ["x"]= 650,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/2HdmgSpeed.png"]= {
                    ["x"]= 676,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SolarisWand.png"]= {
                    ["x"]= 702,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SpeedWarcryNode1.png"]= {
                    ["x"]= 728,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SpellMultiplyer2.png"]= {
                    ["x"]= 754,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SpellSuppresionNode.png"]= {
                    ["x"]= 780,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SpellSuppressionEnergyShield.png"]= {
                    ["x"]= 806,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SpellSuppressionLifeFlasks.png"]= {
                    ["x"]= 832,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/StaffNodeDefensive.png"]= {
                    ["x"]= 858,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/StaffNodeOffensive.png"]= {
                    ["x"]= 884,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/StanceSmallPassive.png"]= {
                    ["x"]= 910,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/StancesNode.png"]= {
                    ["x"]= 936,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Starfell.png"]= {
                    ["x"]= 962,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/StrikeRangeNode.png"]= {
                    ["x"]= 0,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Tidebreaker.png"]= {
                    ["x"]= 26,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/TinctureFlaskNode1.png"]= {
                    ["x"]= 52,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/TinctureNode1.png"]= {
                    ["x"]= 78,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/TinctureNode2.png"]= {
                    ["x"]= 104,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/TinctureNode3.png"]= {
                    ["x"]= 130,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/TotemDmgNode.png"]= {
                    ["x"]= 156,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/TrapAndMineDmgNode.png"]= {
                    ["x"]= 182,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/TremorRod.png"]= {
                    ["x"]= 208,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/DefensiveNodeTrickster.png"]= {
                    ["x"]= 234,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/OffensiveNodeTrickster.png"]= {
                    ["x"]= 260,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/UnitedinDream.png"]= {
                    ["x"]= 286,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanCurses2.png"]= {
                    ["x"]= 312,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanNode.png"]= {
                    ["x"]= 338,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanSpecialCurse1.png"]= {
                    ["x"]= 364,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanSpecialCurse2.png"]= {
                    ["x"]= 390,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanSpecialCurse3.png"]= {
                    ["x"]= 416,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/WandCritical.png"]= {
                    ["x"]= 442,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/WandSpeedAccuracyNode.png"]= {
                    ["x"]= 468,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/WarCryCooldown.png"]= {
                    ["x"]= 494,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/WarcryBuffEffectNotable.png"]= {
                    ["x"]= 520,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Warden/SpellSuppressionEvasion.png"]= {
                    ["x"]= 546,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Warden/TincturesNode.png"]= {
                    ["x"]= 572,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenNode.png"]= {
                    ["x"]= 598,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenTracking.png"]= {
                    ["x"]= 624,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/accuracy.png"]= {
                    ["x"]= 650,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/accuracy2h.png"]= {
                    ["x"]= 676,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/accuracydex.png"]= {
                    ["x"]= 702,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/accuracysword.png"]= {
                    ["x"]= 728,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/arcaneradience.png"]= {
                    ["x"]= 754,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/areaofeffect.png"]= {
                    ["x"]= 780,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeed.png"]= {
                    ["x"]= 806,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeed2h.png"]= {
                    ["x"]= 832,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeedaxe.png"]= {
                    ["x"]= 858,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeedbow.png"]= {
                    ["x"]= 884,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeedclaw.png"]= {
                    ["x"]= 910,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeeddagger.png"]= {
                    ["x"]= 936,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeeddual.png"]= {
                    ["x"]= 962,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeedmace.png"]= {
                    ["x"]= 0,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeedsworddex.png"]= {
                    ["x"]= 26,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/auraareaofeffect.png"]= {
                    ["x"]= 52,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/auraeffect.png"]= {
                    ["x"]= 78,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/avoidburning.png"]= {
                    ["x"]= 104,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/avoidchilling.png"]= {
                    ["x"]= 130,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/axedmgspeed.png"]= {
                    ["x"]= 156,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/blankDex.png"]= {
                    ["x"]= 182,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/blankInt.png"]= {
                    ["x"]= 208,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/blankStr.png"]= {
                    ["x"]= 234,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/blastradius.png"]= {
                    ["x"]= 260,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/blockstaff.png"]= {
                    ["x"]= 286,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/blockstr.png"]= {
                    ["x"]= 312,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/castavoidinterruption.png"]= {
                    ["x"]= 338,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/castspeed.png"]= {
                    ["x"]= 364,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/chargedex.png"]= {
                    ["x"]= 390,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/chargeint.png"]= {
                    ["x"]= 416,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/chargestr.png"]= {
                    ["x"]= 442,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/clawmasterydex.png"]= {
                    ["x"]= 468,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/clustersLinknode1.png"]= {
                    ["x"]= 494,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/clustersLinknode2.png"]= {
                    ["x"]= 520,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/colddamage.png"]= {
                    ["x"]= 546,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/coldresist.png"]= {
                    ["x"]= 572,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/criticalbow.png"]= {
                    ["x"]= 598,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/criticalclaw.png"]= {
                    ["x"]= 624,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/criticaldaggerdex.png"]= {
                    ["x"]= 650,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/criticaldaggerint.png"]= {
                    ["x"]= 676,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/criticalstrikechance.png"]= {
                    ["x"]= 702,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/criticalstrikechance2.png"]= {
                    ["x"]= 728,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/criticalstrikemultiplier.png"]= {
                    ["x"]= 754,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/criticalstrikemultiplier2.png"]= {
                    ["x"]= 780,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/critstrchnc.png"]= {
                    ["x"]= 806,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/crystalskin.png"]= {
                    ["x"]= 832,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damage.png"]= {
                    ["x"]= 858,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damage_blue.png"]= {
                    ["x"]= 884,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damageaxe.png"]= {
                    ["x"]= 910,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damagedualwield.png"]= {
                    ["x"]= 936,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damagedualwieldgreen.png"]= {
                    ["x"]= 962,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damagemelee.png"]= {
                    ["x"]= 0,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damagespells.png"]= {
                    ["x"]= 26,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damagestaff.png"]= {
                    ["x"]= 52,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damagesword.png"]= {
                    ["x"]= 78,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/dmgreduction.png"]= {
                    ["x"]= 104,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/dualwieldaccuracy.png"]= {
                    ["x"]= 130,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/dualwieldblock.png"]= {
                    ["x"]= 156,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/elementaldamage.png"]= {
                    ["x"]= 182,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/energyshield.png"]= {
                    ["x"]= 208,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/evade.png"]= {
                    ["x"]= 234,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/evadepercentage.png"]= {
                    ["x"]= 260,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/evasion.png"]= {
                    ["x"]= 286,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/firedamage.png"]= {
                    ["x"]= 312,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/firedamageint.png"]= {
                    ["x"]= 338,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/firedamagestr.png"]= {
                    ["x"]= 364,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/fireresist.png"]= {
                    ["x"]= 390,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/flaskdex.png"]= {
                    ["x"]= 416,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/flaskint.png"]= {
                    ["x"]= 442,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/flaskstr.png"]= {
                    ["x"]= 468,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/increased armor.png"]= {
                    ["x"]= 494,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/increasedarmorandlife.png"]= {
                    ["x"]= 520,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/increasedrunspeeddex.png"]= {
                    ["x"]= 546,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/innerforce.png"]= {
                    ["x"]= 572,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/knockback.png"]= {
                    ["x"]= 598,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/life1.png"]= {
                    ["x"]= 624,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/lifegainpertarget.png"]= {
                    ["x"]= 650,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/lifeleech.png"]= {
                    ["x"]= 676,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/lifemana.png"]= {
                    ["x"]= 702,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/lifepercentage.png"]= {
                    ["x"]= 728,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/lightningdex.png"]= {
                    ["x"]= 754,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/lightningint.png"]= {
                    ["x"]= 780,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/lightningstr.png"]= {
                    ["x"]= 806,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/macecritdmgspeed.png"]= {
                    ["x"]= 832,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/macedmg.png"]= {
                    ["x"]= 858,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/mana.png"]= {
                    ["x"]= 884,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/manaregeneration.png"]= {
                    ["x"]= 910,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/manareservationreduction.png"]= {
                    ["x"]= 936,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/manastr.png"]= {
                    ["x"]= 962,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/masterydaggerdex.png"]= {
                    ["x"]= 0,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/masterysword.png"]= {
                    ["x"]= 26,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/masterywand.png"]= {
                    ["x"]= 52,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/meleeattackspeed.png"]= {
                    ["x"]= 78,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/minionattackspeed.png"]= {
                    ["x"]= 104,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/minionblockchance.png"]= {
                    ["x"]= 130,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/miniondamage.png"]= {
                    ["x"]= 156,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/miniondamageBlue.png"]= {
                    ["x"]= 182,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/minionlife.png"]= {
                    ["x"]= 208,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/onehanddamage.png"]= {
                    ["x"]= 234,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/onehandspeed.png"]= {
                    ["x"]= 260,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/plusdexterity.png"]= {
                    ["x"]= 286,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/plusintelligence.png"]= {
                    ["x"]= 312,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/plusintelligencedexterity.png"]= {
                    ["x"]= 338,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/plusstrength.png"]= {
                    ["x"]= 364,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/plusstrengthdexterity.png"]= {
                    ["x"]= 390,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/plusstrengthintelligence.png"]= {
                    ["x"]= 416,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/projectilespeed.png"]= {
                    ["x"]= 442,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/shieldblock.png"]= {
                    ["x"]= 468,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/skillduration.png"]= {
                    ["x"]= 494,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/spellcritical.png"]= {
                    ["x"]= 520,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/staffaccuracy.png"]= {
                    ["x"]= 546,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/staffspeed.png"]= {
                    ["x"]= 572,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/stundex.png"]= {
                    ["x"]= 598,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/stunmace.png"]= {
                    ["x"]= 624,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/stunstr.png"]= {
                    ["x"]= 650,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/tempdex.png"]= {
                    ["x"]= 676,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/tempint.png"]= {
                    ["x"]= 702,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/totemandbrandattackspeed.png"]= {
                    ["x"]= 728,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/totemandbranddamage.png"]= {
                    ["x"]= 754,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/totemandbrandrange.png"]= {
                    ["x"]= 780,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/totemattackspeed.png"]= {
                    ["x"]= 806,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/totemlife.png"]= {
                    ["x"]= 832,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/trapcriticalstrike.png"]= {
                    ["x"]= 858,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/trapdamage.png"]= {
                    ["x"]= 884,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/trapsduration.png"]= {
                    ["x"]= 910,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/trapsradius.png"]= {
                    ["x"]= 936,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/trapsspeed.png"]= {
                    ["x"]= 962,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/weaponelementaldamagepercentage.png"]= {
                    ["x"]= 0,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/ArohonguiTribeSkill.png"]= {
                    ["x"]= 26,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/HinekoraTribeSkill.png"]= {
                    ["x"]= 52,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/KitavaTribeSkill.png"]= {
                    ["x"]= 78,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/NgamahuTribeSkill.png"]= {
                    ["x"]= 104,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/RamakoTribeSkill.png"]= {
                    ["x"]= 130,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/RongokuraiTribeSkill.png"]= {
                    ["x"]= 156,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/TasalioTribeSkill.png"]= {
                    ["x"]= 182,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/TawhoaTribeSkill.png"]= {
                    ["x"]= 208,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/TukohamaTribeSkill.png"]= {
                    ["x"]= 234,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/ValakoTribeSkill.png"]= {
                    ["x"]= 260,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/HinekoraPassiveIcon1.png"]= {
                    ["x"]= 286,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/HinekoraPassiveIcon2.png"]= {
                    ["x"]= 312,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/HinekoraPassiveIcon3.png"]= {
                    ["x"]= 338,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SkillscostingLifenode.png"]= {
                    ["x"]= 364,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/accuracyint.png"]= {
                    ["x"]= 390,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/totemandbrandlife.png"]= {
                    ["x"]= 416,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                }
            }
        },
        ["notableActive"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/skills-3.jpg?bdc2a0fd",
            ["w"]= 999,
            ["h"]= 1496,
            ["coords"]= {
                ["Art/2DArt/SkillIcons/passives/2handeddamage.png"]= {
                    ["x"]= 0,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AbyssRevampAbyssalFiends.png"]= {
                    ["x"]= 37,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AbyssRevampGazeoftheLich.png"]= {
                    ["x"]= 74,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AbyssRevampStygianSpires.png"]= {
                    ["x"]= 111,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AccuracyTemplar1.png"]= {
                    ["x"]= 148,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AccuracyTemplar2.png"]= {
                    ["x"]= 185,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Additionalprojectile.png"]= {
                    ["x"]= 222,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AdmonisherNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Annihilation.png"]= {
                    ["x"]= 296,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AntiStunNotable.png"]= {
                    ["x"]= 333,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ArcaneChemistry.png"]= {
                    ["x"]= 370,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ArcaneReaping.png"]= {
                    ["x"]= 407,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AreaDmgNotable.png"]= {
                    ["x"]= 444,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AreaofEffectofMinionsNotable.png"]= {
                    ["x"]= 481,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ArmourChargeNotable.png"]= {
                    ["x"]= 518,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ArmourGuardsNotable.png"]= {
                    ["x"]= 555,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ArmourNotable.png"]= {
                    ["x"]= 592,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ArmourandEvasion2.png"]= {
                    ["x"]= 629,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Ascendancy.png"]= {
                    ["x"]= 666,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Dex.png"]= {
                    ["x"]= 703,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/DexInt.png"]= {
                    ["x"]= 740,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Int.png"]= {
                    ["x"]= 777,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/ReliquarianAscendancyCenter.png"]= {
                    ["x"]= 814,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Str.png"]= {
                    ["x"]= 851,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/StrDex.png"]= {
                    ["x"]= 888,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/StrInt.png"]= {
                    ["x"]= 925,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AspectOfTheLynx.png"]= {
                    ["x"]= 962,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AspectoftheEagle.png"]= {
                    ["x"]= 0,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/Assassinate.png"]= {
                    ["x"]= 37,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/DeadlyInfusion.png"]= {
                    ["x"]= 74,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/Elusive.png"]= {
                    ["x"]= 111,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/NoxiousStrike.png"]= {
                    ["x"]= 148,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/ToxicDelivery.png"]= {
                    ["x"]= 185,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/UnstableInfusion.png"]= {
                    ["x"]= 222,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AssassinAnointNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/AulBloodlineNotable.png"]= {
                    ["x"]= 296,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BestiaryNotable4.png"]= {
                    ["x"]= 333,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BloodLineOlrothNotable.png"]= {
                    ["x"]= 370,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BoldUndertaking.png"]= {
                    ["x"]= 407,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BreachNotable4.png"]= {
                    ["x"]= 444,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/DeliriumNotable1.png"]= {
                    ["x"]= 481,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/FarrulNotable1.png"]= {
                    ["x"]= 518,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/HarbingerNode1.png"]= {
                    ["x"]= 555,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/LyciaNotable1.png"]= {
                    ["x"]= 592,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/MorePrimalWisps.png"]= {
                    ["x"]= 629,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/MoreVividWisps.png"]= {
                    ["x"]= 666,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/MoreWildWisps.png"]= {
                    ["x"]= 703,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/TempestNotable1.png"]= {
                    ["x"]= 740,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/UltimatumNotable3.png"]= {
                    ["x"]= 777,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/UltimatumNotable4.png"]= {
                    ["x"]= 814,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AttackBlindNotable.png"]= {
                    ["x"]= 851,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AttackDamangeAndEvasionNotableIcon.png"]= {
                    ["x"]= 888,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AttackPoisonNotable.png"]= {
                    ["x"]= 925,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AuraEffectNotable.png"]= {
                    ["x"]= 962,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AuraReservationNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AvataroftheHunt2.png"]= {
                    ["x"]= 37,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AvoidInterruptionFromCastingNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AxeNotable1.png"]= {
                    ["x"]= 111,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AxeNotable2.png"]= {
                    ["x"]= 148,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AxeandSwordDamage.png"]= {
                    ["x"]= 185,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AxesandAttackSpeed.png"]= {
                    ["x"]= 222,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BannerAreaNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BannerDurationNotable.png"]= {
                    ["x"]= 296,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BannerEffectNotable.png"]= {
                    ["x"]= 333,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BannerResourceAreaNotable.png"]= {
                    ["x"]= 370,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BannersNotable.png"]= {
                    ["x"]= 407,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BarragingProjectilesNotable.png"]= {
                    ["x"]= 444,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BattleRouse.png"]= {
                    ["x"]= 481,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/AspectOfCarnage.png"]= {
                    ["x"]= 518,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/Blitz.png"]= {
                    ["x"]= 555,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/CloakedAgony.png"]= {
                    ["x"]= 592,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/CombatFrenzy.png"]= {
                    ["x"]= 629,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/DefyPain.png"]= {
                    ["x"]= 666,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/RiteOfRuin.png"]= {
                    ["x"]= 703,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/WarBringer.png"]= {
                    ["x"]= 740,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BeserkerAnointNotable.png"]= {
                    ["x"]= 777,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BladeBarrierNotable.png"]= {
                    ["x"]= 814,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BleedPoison.png"]= {
                    ["x"]= 851,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BleedPoisonMitigateNotable.png"]= {
                    ["x"]= 888,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BleedingNotable1.png"]= {
                    ["x"]= 925,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BleedingNotable2.png"]= {
                    ["x"]= 962,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BlockAttackDmgNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BlockSpellDmgNotable.png"]= {
                    ["x"]= 37,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Blood2.png"]= {
                    ["x"]= 74,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BloodPact.png"]= {
                    ["x"]= 111,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BloodSiphon.png"]= {
                    ["x"]= 148,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BloodyBludgeon.png"]= {
                    ["x"]= 185,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Boomerang.png"]= {
                    ["x"]= 222,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BowDamage.png"]= {
                    ["x"]= 259,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Brand2.png"]= {
                    ["x"]= 296,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Brand3.png"]= {
                    ["x"]= 333,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Brand4.png"]= {
                    ["x"]= 370,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BrandDmgNotable.png"]= {
                    ["x"]= 407,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BreathofFlames2.png"]= {
                    ["x"]= 444,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BreathofLightening2.png"]= {
                    ["x"]= 481,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BreathofRime2.png"]= {
                    ["x"]= 518,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BrineRot.png"]= {
                    ["x"]= 555,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ByTheBlade.png"]= {
                    ["x"]= 592,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CelestialPunishment.png"]= {
                    ["x"]= 629,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ChainingProjectiles.png"]= {
                    ["x"]= 666,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Champion.png"]= {
                    ["x"]= 703,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Champion/FirstStrikeLastFall.png"]= {
                    ["x"]= 740,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Champion/Fortitude.png"]= {
                    ["x"]= 777,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Champion/ImpalePassiveNotable.png"]= {
                    ["x"]= 814,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Champion/Inpirational.png"]= {
                    ["x"]= 851,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Champion/Unstopable.png"]= {
                    ["x"]= 888,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Champion/WorthyCauses.png"]= {
                    ["x"]= 925,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Champion/WorthyFoe.png"]= {
                    ["x"]= 962,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ChampionAnointNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ChaosDamage2.png"]= {
                    ["x"]= 37,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ChaosDamageOverTimeNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ChaosDamageOverTimeNotable2.png"]= {
                    ["x"]= 111,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ChaosResistNotable.png"]= {
                    ["x"]= 148,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ChaoticPotential.png"]= {
                    ["x"]= 185,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CheiftainAnointNotable.png"]= {
                    ["x"]= 222,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/ArohunguiMoonsPresenceWarcry.png"]= {
                    ["x"]= 259,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/HinekoraDeathsFury.png"]= {
                    ["x"]= 296,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/NgamahuFlamesAdvance.png"]= {
                    ["x"]= 333,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/RamakoSunsLight.png"]= {
                    ["x"]= 370,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/TasalioCleansingWater.png"]= {
                    ["x"]= 407,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/TukomahaWarsHerald.png"]= {
                    ["x"]= 444,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/ValakoStormsEmbrace.png"]= {
                    ["x"]= 481,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ChillThemedNotable.png"]= {
                    ["x"]= 518,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ClawNotable1.png"]= {
                    ["x"]= 555,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ClawNotable2.png"]= {
                    ["x"]= 592,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ClawsOfTheMagpie.png"]= {
                    ["x"]= 629,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CleverThief.png"]= {
                    ["x"]= 666,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ColdAndFireHybridNotable.png"]= {
                    ["x"]= 703,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ColdDamageEnemyNotable.png"]= {
                    ["x"]= 740,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ColdDamageOverTimeNotable.png"]= {
                    ["x"]= 777,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ColdResistNotable.png"]= {
                    ["x"]= 814,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ColdWeaponDmg.png"]= {
                    ["x"]= 851,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ColdheartedCalculation2.png"]= {
                    ["x"]= 888,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CombatFocusNotable.png"]= {
                    ["x"]= 925,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CombatStamina.png"]= {
                    ["x"]= 962,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CommandofSteel.png"]= {
                    ["x"]= 0,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Constitution.png"]= {
                    ["x"]= 37,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Coordination.png"]= {
                    ["x"]= 74,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CorpsesNotable.png"]= {
                    ["x"]= 111,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Corruption.png"]= {
                    ["x"]= 148,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CritStrikeBleedingNotable.png"]= {
                    ["x"]= 185,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CrustaceousGrowth2.png"]= {
                    ["x"]= 222,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CurseAreaOfEffectNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CurseEffectNotable.png"]= {
                    ["x"]= 296,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CurseNotable.png"]= {
                    ["x"]= 333,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CurseNotable2.png"]= {
                    ["x"]= 370,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CursemitigationclusterNotable.png"]= {
                    ["x"]= 407,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DaggerNotable1.png"]= {
                    ["x"]= 444,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DaggerandClawDamage.png"]= {
                    ["x"]= 481,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DamageOverTimeNotable.png"]= {
                    ["x"]= 518,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DamageofMinionsNotable.png"]= {
                    ["x"]= 555,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DarkestHour.png"]= {
                    ["x"]= 592,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DeadEye/DeadeyeFrenzyChargeNotable.png"]= {
                    ["x"]= 629,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DeadEye/FarShot.png"]= {
                    ["x"]= 666,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DeadEye/GatherWinds.png"]= {
                    ["x"]= 703,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DeadEye/Ricochet.png"]= {
                    ["x"]= 740,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DeadeyeAnointNotable.png"]= {
                    ["x"]= 777,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DeepBreathsNotable.png"]= {
                    ["x"]= 814,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DiamondSkin2.png"]= {
                    ["x"]= 851,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DireTorment.png"]= {
                    ["x"]= 888,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DivineFury.png"]= {
                    ["x"]= 925,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DivineWrath.png"]= {
                    ["x"]= 962,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DmgHeraldSkillsNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DmgWhenChannelSkillsNotable.png"]= {
                    ["x"]= 37,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DodgeAtksNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Dreamer.png"]= {
                    ["x"]= 111,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DruidicRite.png"]= {
                    ["x"]= 148,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DualWieldNotable.png"]= {
                    ["x"]= 185,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DualWieldingBlockNotable.png"]= {
                    ["x"]= 222,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DualWieldingDamage.png"]= {
                    ["x"]= 259,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DurationofMinionsNotable.png"]= {
                    ["x"]= 296,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ElementalAilmentResistance.png"]= {
                    ["x"]= 333,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ElementalDamagewithAttacks2.png"]= {
                    ["x"]= 370,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ElementalDominion2.png"]= {
                    ["x"]= 407,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ElementalFocus.png"]= {
                    ["x"]= 444,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/ChillSpecialisation.png"]= {
                    ["x"]= 481,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/ElemancerIcon.png"]= {
                    ["x"]= 518,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/IgniteSpecialisation.png"]= {
                    ["x"]= 555,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/IridescentFlesh.png"]= {
                    ["x"]= 592,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/LiegeOfThePrimordial.png"]= {
                    ["x"]= 629,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/PendulumOfDestruction.png"]= {
                    ["x"]= 666,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/PrimevalForce.png"]= {
                    ["x"]= 703,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/ShockSpecialisation.png"]= {
                    ["x"]= 740,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ElementalistAnointNotable.png"]= {
                    ["x"]= 777,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EnduranceChargeNotable.png"]= {
                    ["x"]= 814,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EnergyShieldNotable.png"]= {
                    ["x"]= 851,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Entropy.png"]= {
                    ["x"]= 888,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EscalationNotable.png"]= {
                    ["x"]= 925,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EssenceSurge.png"]= {
                    ["x"]= 962,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EvasionAndBlindNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EvasionAndPhasingNotable.png"]= {
                    ["x"]= 37,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EvasionNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ExceptionalPerformance.png"]= {
                    ["x"]= 111,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ExplosiveRunes.png"]= {
                    ["x"]= 148,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EyesOfTheDeadly.png"]= {
                    ["x"]= 185,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EyesOfThePowerful.png"]= {
                    ["x"]= 222,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EyesOfTheSavant.png"]= {
                    ["x"]= 259,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FasterBleeding2.png"]= {
                    ["x"]= 296,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FatalBlade.png"]= {
                    ["x"]= 333,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FireAilment.png"]= {
                    ["x"]= 370,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FireDamageOverTimeNotable.png"]= {
                    ["x"]= 407,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FireResistNotable.png"]= {
                    ["x"]= 444,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FlaskDuration.png"]= {
                    ["x"]= 481,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FlaskNotableCritStrikeRecharge.png"]= {
                    ["x"]= 518,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FlaskNotableFlasksLastLonger.png"]= {
                    ["x"]= 555,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ForceOfNature.png"]= {
                    ["x"]= 592,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ForkingProjectilesNotable.png"]= {
                    ["x"]= 629,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FortifyNotable1.png"]= {
                    ["x"]= 666,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FortifyNotable2.png"]= {
                    ["x"]= 703,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FrenzyChargeNotable.png"]= {
                    ["x"]= 740,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/GenericBlockNotable1.png"]= {
                    ["x"]= 777,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/GenericBlockNotable2.png"]= {
                    ["x"]= 814,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/GenericSpellBlockNotable.png"]= {
                    ["x"]= 851,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GLADBloodAndSand.png"]= {
                    ["x"]= 888,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GLADBloodInEyes.png"]= {
                    ["x"]= 925,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GLADPainForged.png"]= {
                    ["x"]= 962,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GLADVersitileCombatant.png"]= {
                    ["x"]= 0,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GLADViolence.png"]= {
                    ["x"]= 37,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GLADViolentRetaliation.png"]= {
                    ["x"]= 74,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GladiatorDualWiledSwordAxeNotable.png"]= {
                    ["x"]= 111,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/GladiatorAnointNotable.png"]= {
                    ["x"]= 148,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/GolemsNotable.png"]= {
                    ["x"]= 185,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/GreenProjectileAttackNotable.png"]= {
                    ["x"]= 222,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/GrowthandDecay.png"]= {
                    ["x"]= 259,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/GuardianHallowingFlameNotable.png"]= {
                    ["x"]= 296,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/HarmonyOfPurpose.png"]= {
                    ["x"]= 333,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/Radient Crusade.png"]= {
                    ["x"]= 370,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/RadientFaith.png"]= {
                    ["x"]= 407,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/ShieldMastery.png"]= {
                    ["x"]= 444,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/TimeOfNeed.png"]= {
                    ["x"]= 481,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/Unwavering Crusade.png"]= {
                    ["x"]= 518,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/UnwaveringFaith.png"]= {
                    ["x"]= 555,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/GuardianAnointNotable.png"]= {
                    ["x"]= 592,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Harrier.png"]= {
                    ["x"]= 629,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HeartandSoul.png"]= {
                    ["x"]= 666,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HeartofChaos.png"]= {
                    ["x"]= 703,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HeartoftheOak.png"]= {
                    ["x"]= 740,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hearty.png"]= {
                    ["x"]= 777,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HeirophantAnointNotable.png"]= {
                    ["x"]= 814,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HeraldBuffEffectNode2.png"]= {
                    ["x"]= 851,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HeraldDamageNotable.png"]= {
                    ["x"]= 888,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HeraldReservation.png"]= {
                    ["x"]= 925,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/AncestralZeal.png"]= {
                    ["x"]= 962,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/ArcaneSurge.png"]= {
                    ["x"]= 0,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/DiscipleOfRuin.png"]= {
                    ["x"]= 37,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/ItemAugment.png"]= {
                    ["x"]= 74,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/MindOverBeing.png"]= {
                    ["x"]= 111,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/MindOverBody.png"]= {
                    ["x"]= 148,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/SignOfPurpose.png"]= {
                    ["x"]= 185,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/SpiritualEmpowerment.png"]= {
                    ["x"]= 222,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HiredKiller2.png"]= {
                    ["x"]= 259,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HoldingShieldDamage.png"]= {
                    ["x"]= 296,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hunter.png"]= {
                    ["x"]= 333,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IgniteAshNotable.png"]= {
                    ["x"]= 370,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IgniteAttackNotable.png"]= {
                    ["x"]= 407,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IgniteBleedNotable.png"]= {
                    ["x"]= 444,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IgniteStunNotable.png"]= {
                    ["x"]= 481,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IgnorePain.png"]= {
                    ["x"]= 518,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Impale1HandNotable.png"]= {
                    ["x"]= 555,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ImpaleEffectNotable.png"]= {
                    ["x"]= 592,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ImpaleNotable1.png"]= {
                    ["x"]= 629,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ImpaleNotable2.png"]= {
                    ["x"]= 666,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreaseCritChanceNotable.png"]= {
                    ["x"]= 703,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreaseMinionLifeNotable.png"]= {
                    ["x"]= 740,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedAttackDamageNotable.png"]= {
                    ["x"]= 777,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedChaosDamage.png"]= {
                    ["x"]= 814,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedColdDamage.png"]= {
                    ["x"]= 851,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedElementalDamage.png"]= {
                    ["x"]= 888,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedFireDamage.png"]= {
                    ["x"]= 925,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedLightningDamage.png"]= {
                    ["x"]= 962,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedManaCostNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedMaximumLifeNotable.png"]= {
                    ["x"]= 37,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedMinionDamageNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedNonDamageAilmentNotable.png"]= {
                    ["x"]= 111,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedPhysicalDamage.png"]= {
                    ["x"]= 148,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedSpellDamageNode.png"]= {
                    ["x"]= 185,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedSpellDamageNotable.png"]= {
                    ["x"]= 222,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedWarcryNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/InfusedFlesh.png"]= {
                    ["x"]= 296,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/InquisitorAnointNotable.png"]= {
                    ["x"]= 333,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/CriticalStrikeChance.png"]= {
                    ["x"]= 370,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/ElementalDomination.png"]= {
                    ["x"]= 407,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/ElementalForce.png"]= {
                    ["x"]= 444,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/ElementalMastery.png"]= {
                    ["x"]= 481,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/GloryOfTheSavant.png"]= {
                    ["x"]= 518,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/InstrumentsOfVirtue.png"]= {
                    ["x"]= 555,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/InstrumentsofZeal.png"]= {
                    ["x"]= 592,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/Sanctify.png"]= {
                    ["x"]= 629,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inspiration.png"]= {
                    ["x"]= 666,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IntensifyNotable.png"]= {
                    ["x"]= 703,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/JuggernautArmourNotable.png"]= {
                    ["x"]= 740,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/Unbreakable.png"]= {
                    ["x"]= 777,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/Undeniable.png"]= {
                    ["x"]= 814,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/Unflinching.png"]= {
                    ["x"]= 851,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/Unrelenting.png"]= {
                    ["x"]= 888,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/Unstoppable.png"]= {
                    ["x"]= 925,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/Unyielding.png"]= {
                    ["x"]= 962,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/JuggernautAnointNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneArmourMaster.png"]= {
                    ["x"]= 37,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneWhispersOfDoom.png"]= {
                    ["x"]= 74,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeArmourAndEvasion.png"]= {
                    ["x"]= 111,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeFlasks.png"]= {
                    ["x"]= 148,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeGainOnHitNotable.png"]= {
                    ["x"]= 185,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeManaFlasksrecovery.png"]= {
                    ["x"]= 222,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeRecoupNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeRegenerationGainRegenNotable.png"]= {
                    ["x"]= 296,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeRegenerationLowlifeBonusNotable.png"]= {
                    ["x"]= 333,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeandCursesN.png"]= {
                    ["x"]= 370,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeandManaFlasks.png"]= {
                    ["x"]= 407,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeandResistancesofMinions.png"]= {
                    ["x"]= 444,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LightOfDivinity.png"]= {
                    ["x"]= 481,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LightningResistNotable.png"]= {
                    ["x"]= 518,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LinkNotable3.png"]= {
                    ["x"]= 555,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LinkNotable4.png"]= {
                    ["x"]= 592,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable1.png"]= {
                    ["x"]= 629,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable2.png"]= {
                    ["x"]= 666,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable3.png"]= {
                    ["x"]= 703,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable4.png"]= {
                    ["x"]= 740,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable5.png"]= {
                    ["x"]= 777,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable6.png"]= {
                    ["x"]= 814,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LustforCarnage.png"]= {
                    ["x"]= 851,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MaceNotable1.png"]= {
                    ["x"]= 888,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MaceNotable2.png"]= {
                    ["x"]= 925,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MaceandStaffDamage.png"]= {
                    ["x"]= 962,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ManaDamageKeystone.png"]= {
                    ["x"]= 0,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ManaFlasksOften.png"]= {
                    ["x"]= 37,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ManaGuardNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ManaNotable.png"]= {
                    ["x"]= 111,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ManaandArcaneSurge.png"]= {
                    ["x"]= 148,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ManaandSpellBlock.png"]= {
                    ["x"]= 185,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ManaandSpellDamage.png"]= {
                    ["x"]= 222,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Mark.png"]= {
                    ["x"]= 259,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MarkNotable1.png"]= {
                    ["x"]= 296,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MarkNotable2.png"]= {
                    ["x"]= 333,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MarkNotableIncreasedEffect.png"]= {
                    ["x"]= 370,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MarkNotableMarkSpellRecently.png"]= {
                    ["x"]= 407,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MartialExperience.png"]= {
                    ["x"]= 444,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MasterofForce.png"]= {
                    ["x"]= 481,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MaxElementalResistNotable.png"]= {
                    ["x"]= 518,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MaxManaNotable.png"]= {
                    ["x"]= 555,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MaximumElementalResistances2.png"]= {
                    ["x"]= 592,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MeasuredFuryNotable.png"]= {
                    ["x"]= 629,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MeleeAoENode.png"]= {
                    ["x"]= 666,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MeleeAoENotable.png"]= {
                    ["x"]= 703,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MeleeCriticalStrikesNotable.png"]= {
                    ["x"]= 740,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MeleeFireNotable.png"]= {
                    ["x"]= 777,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MeleeRange2.png"]= {
                    ["x"]= 814,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MeleeUtility.png"]= {
                    ["x"]= 851,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Meleerange.png"]= {
                    ["x"]= 888,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MentalRapidity.png"]= {
                    ["x"]= 925,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MindPact.png"]= {
                    ["x"]= 962,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MineAreaOfEffectNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MineCriticalStrikesNotable.png"]= {
                    ["x"]= 37,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MineManaReservationNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MineTrap.png"]= {
                    ["x"]= 111,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MinionDmgHeraldSkillsNotable.png"]= {
                    ["x"]= 148,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Mirage.png"]= {
                    ["x"]= 185,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/NaturalAuthorityNotable.png"]= {
                    ["x"]= 222,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/CommandingTheDarkness.png"]= {
                    ["x"]= 259,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/CorpseConsumptionNotable2.png"]= {
                    ["x"]= 296,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/DefensiveMinionNotable.png"]= {
                    ["x"]= 333,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/EssenceGlutton.png"]= {
                    ["x"]= 370,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/GenericMinionNotable.png"]= {
                    ["x"]= 407,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/GiftsOfTheDamned.png"]= {
                    ["x"]= 444,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/OffensiveMinionNotable.png"]= {
                    ["x"]= 481,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/PlagueBringer.png"]= {
                    ["x"]= 518,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/NecromancerAnointNotable.png"]= {
                    ["x"]= 555,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/EldrichBarrier.png"]= {
                    ["x"]= 592,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/FatefulEchoes.png"]= {
                    ["x"]= 629,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/FrigidWake.png"]= {
                    ["x"]= 666,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/LotusExtract.png"]= {
                    ["x"]= 703,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/SoulCatalyst.png"]= {
                    ["x"]= 740,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/VoidBeacon.png"]= {
                    ["x"]= 777,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/VowOfDamnation.png"]= {
                    ["x"]= 814,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/WitheringPresence.png"]= {
                    ["x"]= 851,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/OccultistAnointNotable.png"]= {
                    ["x"]= 888,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/OneHandedPhysicalAndLeechNotable.png"]= {
                    ["x"]= 925,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/AlchemistGift.png"]= {
                    ["x"]= 962,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/MasterAlchemist.png"]= {
                    ["x"]= 0,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/MasterHerbalist.png"]= {
                    ["x"]= 37,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/MasterSurgeon.png"]= {
                    ["x"]= 74,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/Master Toxicist.png"]= {
                    ["x"]= 111,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/NaturesAdrenaline.png"]= {
                    ["x"]= 148,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/VeteranBowyer.png"]= {
                    ["x"]= 185,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PathfinderAnointNotable.png"]= {
                    ["x"]= 222,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageNotableGreen.png"]= {
                    ["x"]= 296,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageOverTimeHybrid.png"]= {
                    ["x"]= 333,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageOverTimeNotable.png"]= {
                    ["x"]= 370,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageOverTimenotable1.png"]= {
                    ["x"]= 407,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageOverTimenotable2.png"]= {
                    ["x"]= 444,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Poison.png"]= {
                    ["x"]= 481,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PoisonSpellsNotable.png"]= {
                    ["x"]= 518,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PowerChargeNotable.png"]= {
                    ["x"]= 555,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Primalist/PrimalistCorpseLoot.png"]= {
                    ["x"]= 592,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Primalist/PrimalistInventoryExpansion.png"]= {
                    ["x"]= 629,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ProfaneChemistry.png"]= {
                    ["x"]= 666,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ProjectileDmgNotable.png"]= {
                    ["x"]= 703,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ProjectilesNotable.png"]= {
                    ["x"]= 740,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ProtectiveWinds.png"]= {
                    ["x"]= 777,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/QuickRecovery.png"]= {
                    ["x"]= 814,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RageNotable.png"]= {
                    ["x"]= 851,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RageNotable1.png"]= {
                    ["x"]= 888,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RageNotable2.png"]= {
                    ["x"]= 925,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RageNotable3.png"]= {
                    ["x"]= 962,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RangedTotemCriticalStrikes.png"]= {
                    ["x"]= 0,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RangedTotemOffensive.png"]= {
                    ["x"]= 37,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RedHolyAttackNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Redemption.png"]= {
                    ["x"]= 111,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ReducedManaNotable.png"]= {
                    ["x"]= 148,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ReducedProjectileSpeedNotable.png"]= {
                    ["x"]= 185,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ReducedSkillEffectDurationNotable.png"]= {
                    ["x"]= 222,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Resourcefulness.png"]= {
                    ["x"]= 259,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Retaliation.png"]= {
                    ["x"]= 296,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationAoE.png"]= {
                    ["x"]= 333,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationAttackBlock.png"]= {
                    ["x"]= 370,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationDurationCooldown.png"]= {
                    ["x"]= 407,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationSkillDamage.png"]= {
                    ["x"]= 444,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationSpellBlock.png"]= {
                    ["x"]= 481,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationStun.png"]= {
                    ["x"]= 518,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Retribution.png"]= {
                    ["x"]= 555,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Revelry.png"]= {
                    ["x"]= 592,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RighteousArmy.png"]= {
                    ["x"]= 629,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Righteous Decree.png"]= {
                    ["x"]= 666,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RitualBloodLineNotable.png"]= {
                    ["x"]= 703,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Robust.png"]= {
                    ["x"]= 740,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/BlindedAssult.png"]= {
                    ["x"]= 777,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/BombSpecialist.png"]= {
                    ["x"]= 814,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/ChainReaction.png"]= {
                    ["x"]= 851,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/DemolitionSpecialist.png"]= {
                    ["x"]= 888,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/ExplosivesExpert.png"]= {
                    ["x"]= 925,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/LikeClockworkNotable.png"]= {
                    ["x"]= 962,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/PerfectCrime.png"]= {
                    ["x"]= 0,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/ShadowsDarknessBlind.png"]= {
                    ["x"]= 37,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/ShrapnelSpecialist.png"]= {
                    ["x"]= 74,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SaboteurAnointNotable.png"]= {
                    ["x"]= 111,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Sanctuary.png"]= {
                    ["x"]= 148,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SareshBloodlineNotable1.png"]= {
                    ["x"]= 185,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SareshBloodlineNotable3.png"]= {
                    ["x"]= 222,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SareshBloodlineNoteble2.png"]= {
                    ["x"]= 259,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SavantPath.png"]= {
                    ["x"]= 296,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SearingHeat.png"]= {
                    ["x"]= 333,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Sentinel.png"]= {
                    ["x"]= 370,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Shaper.png"]= {
                    ["x"]= 407,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ShieldAttackDamage.png"]= {
                    ["x"]= 444,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ShieldNotable.png"]= {
                    ["x"]= 481,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ShrugOff.png"]= {
                    ["x"]= 518,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SkitteringRunes.png"]= {
                    ["x"]= 555,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/BaneOfLegends.png"]= {
                    ["x"]= 592,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/BrutalFervor.png"]= {
                    ["x"]= 629,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/Charges.png"]= {
                    ["x"]= 666,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/CriticalAttacks.png"]= {
                    ["x"]= 703,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/EndlessHunger.png"]= {
                    ["x"]= 740,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/Headman.png"]= {
                    ["x"]= 777,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/Impact.png"]= {
                    ["x"]= 814,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SlayerAnointNotable.png"]= {
                    ["x"]= 851,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SoulPact.png"]= {
                    ["x"]= 888,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SoulSiphoning.png"]= {
                    ["x"]= 925,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SpellSuppressionLifeFlasksN.png"]= {
                    ["x"]= 962,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SpellSupressionAndEnergyShieldNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SpellSupressionNotable1.png"]= {
                    ["x"]= 37,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SpellSupressionNotable2.png"]= {
                    ["x"]= 74,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SpikedBulwark.png"]= {
                    ["x"]= 111,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SpiritualAid.png"]= {
                    ["x"]= 148,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SpiritualCommand.png"]= {
                    ["x"]= 185,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StaffCrit.png"]= {
                    ["x"]= 222,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StaffNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StaffNotable2.png"]= {
                    ["x"]= 296,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StaffNotable3.png"]= {
                    ["x"]= 333,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StanceNotableReservation.png"]= {
                    ["x"]= 370,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StanceNotableSwitching.png"]= {
                    ["x"]= 407,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Storm Weaver.png"]= {
                    ["x"]= 444,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StrengthOfBlood.png"]= {
                    ["x"]= 481,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StrikeSkillsNotable.png"]= {
                    ["x"]= 518,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StunAvoidNotable.png"]= {
                    ["x"]= 555,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StunMastery.png"]= {
                    ["x"]= 592,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SupremeProdigy.png"]= {
                    ["x"]= 629,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Survivalist.png"]= {
                    ["x"]= 666,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SwordNotable1.png"]= {
                    ["x"]= 703,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TasteforBlood.png"]= {
                    ["x"]= 740,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TempestBlast.png"]= {
                    ["x"]= 777,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ThrillKiller.png"]= {
                    ["x"]= 814,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TideCaller.png"]= {
                    ["x"]= 851,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TinctureFlaskNotable1.png"]= {
                    ["x"]= 888,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TinctureManaNotable1.png"]= {
                    ["x"]= 925,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TinctureNotable1.png"]= {
                    ["x"]= 962,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TinctureNotable2.png"]= {
                    ["x"]= 0,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TinctureNotable3.png"]= {
                    ["x"]= 37,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TotemDmgNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trap.png"]= {
                    ["x"]= 111,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trap2.png"]= {
                    ["x"]= 148,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TrapAndMineDmgNotable.png"]= {
                    ["x"]= 185,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/DamageOverTime.png"]= {
                    ["x"]= 222,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/HeedfulRecovery.png"]= {
                    ["x"]= 259,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/ImmuneToDoT.png"]= {
                    ["x"]= 296,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/OneStepAheadTrickster.png"]= {
                    ["x"]= 333,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/PolymathTrickster.png"]= {
                    ["x"]= 370,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/SoulThiefTrickster.png"]= {
                    ["x"]= 407,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/SupressionEnergyShieldTrickster.png"]= {
                    ["x"]= 444,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/UncontrolledVigour.png"]= {
                    ["x"]= 481,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TricksterAnointNotable.png"]= {
                    ["x"]= 518,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TrueStriker.png"]= {
                    ["x"]= 555,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TwoHandedMeleeDamage.png"]= {
                    ["x"]= 592,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TwoHandedweaponImpalesNotable.png"]= {
                    ["x"]= 629,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Unfaltering.png"]= {
                    ["x"]= 666,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Unrelenting.png"]= {
                    ["x"]= 703,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Unwavering.png"]= {
                    ["x"]= 740,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/UpwardsFiringProjectilesNotable.png"]= {
                    ["x"]= 777,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Vampirism.png"]= {
                    ["x"]= 814,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/VoidBarrier.png"]= {
                    ["x"]= 851,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanBloodMagic1.png"]= {
                    ["x"]= 888,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanBloodMagic2.png"]= {
                    ["x"]= 925,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanBloodMagic3.png"]= {
                    ["x"]= 962,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanCorpses.png"]= {
                    ["x"]= 0,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanCurses2.png"]= {
                    ["x"]= 37,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanCursesChoice.png"]= {
                    ["x"]= 74,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanVoodooDoll.png"]= {
                    ["x"]= 111,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/WandDamage.png"]= {
                    ["x"]= 148,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/WarcryBuffEffectNotable.png"]= {
                    ["x"]= 185,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/WarcryGainDamageNotable.png"]= {
                    ["x"]= 222,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/TinctureRangedNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenAllAilments.png"]= {
                    ["x"]= 296,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenBarkskin1.png"]= {
                    ["x"]= 333,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenBarkskin2.png"]= {
                    ["x"]= 370,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenColdAilments.png"]= {
                    ["x"]= 407,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenFireAilments.png"]= {
                    ["x"]= 444,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenLightningAilments.png"]= {
                    ["x"]= 481,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenPrimitivism.png"]= {
                    ["x"]= 518,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenSaps1.png"]= {
                    ["x"]= 555,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenSaps2.png"]= {
                    ["x"]= 592,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenSaps3.png"]= {
                    ["x"]= 629,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenTracking.png"]= {
                    ["x"]= 666,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/WardenAnointNotable.png"]= {
                    ["x"]= 703,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warrior.png"]= {
                    ["x"]= 740,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/WeaponElementalNotable.png"]= {
                    ["x"]= 777,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/WritteninBlood.png"]= {
                    ["x"]= 814,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/accuracydex.png"]= {
                    ["x"]= 851,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/adderstouch.png"]= {
                    ["x"]= 888,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ambidexterity.png"]= {
                    ["x"]= 925,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/amplify.png"]= {
                    ["x"]= 962,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/animalspirit.png"]= {
                    ["x"]= 0,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/arcaneefficiency.png"]= {
                    ["x"]= 37,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/arcane focus.png"]= {
                    ["x"]= 74,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/arcanepotency.png"]= {
                    ["x"]= 111,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/arcaneradience.png"]= {
                    ["x"]= 148,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/armourmastery.png"]= {
                    ["x"]= 185,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/arsonist.png"]= {
                    ["x"]= 222,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ashfrostandstorm.png"]= {
                    ["x"]= 259,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/attackspeedbow.png"]= {
                    ["x"]= 296,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/authority.png"]= {
                    ["x"]= 333,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/barricade.png"]= {
                    ["x"]= 370,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/berserking.png"]= {
                    ["x"]= 407,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/bladebarrier.png"]= {
                    ["x"]= 444,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/blademaster.png"]= {
                    ["x"]= 481,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/blademistress.png"]= {
                    ["x"]= 518,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/blastradius.png"]= {
                    ["x"]= 555,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/bodysoul.png"]= {
                    ["x"]= 592,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/borntofight.png"]= {
                    ["x"]= 629,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/breathofrime.png"]= {
                    ["x"]= 666,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/butchery.png"]= {
                    ["x"]= 703,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/castavoidinterruption.png"]= {
                    ["x"]= 740,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/catalyse.png"]= {
                    ["x"]= 777,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/chargedex.png"]= {
                    ["x"]= 814,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/chargeint.png"]= {
                    ["x"]= 851,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/chargestr.png"]= {
                    ["x"]= 888,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/cleverconstruction.png"]= {
                    ["x"]= 925,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/clustersLink2.png"]= {
                    ["x"]= 962,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/clustersLink3.png"]= {
                    ["x"]= 0,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/criticalstrikemultiplier2.png"]= {
                    ["x"]= 37,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/cruelblade.png"]= {
                    ["x"]= 74,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/daggerpenetration.png"]= {
                    ["x"]= 111,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/deadlydraw.png"]= {
                    ["x"]= 148,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/deadlyprecision.png"]= {
                    ["x"]= 185,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/deathattunement.png"]= {
                    ["x"]= 222,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/deepthoughts.png"]= {
                    ["x"]= 259,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/deepwisdom.png"]= {
                    ["x"]= 296,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/diamondskin.png"]= {
                    ["x"]= 333,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/doomcast.png"]= {
                    ["x"]= 370,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/eagleeye.png"]= {
                    ["x"]= 407,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/eagletalons.png"]= {
                    ["x"]= 444,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/elderpower.png"]= {
                    ["x"]= 481,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/elementalist.png"]= {
                    ["x"]= 518,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/evasion.png"]= {
                    ["x"]= 555,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/executioner.png"]= {
                    ["x"]= 592,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/expeditiousmunitions.png"]= {
                    ["x"]= 629,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/fellingtheweak.png"]= {
                    ["x"]= 666,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/fending.png"]= {
                    ["x"]= 703,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/finesse.png"]= {
                    ["x"]= 740,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/firedamage.png"]= {
                    ["x"]= 777,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/flameborn.png"]= {
                    ["x"]= 814,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/flaying.png"]= {
                    ["x"]= 851,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/foresight.png"]= {
                    ["x"]= 888,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/frostborn.png"]= {
                    ["x"]= 925,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/furybolts.png"]= {
                    ["x"]= 962,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/fussilade.png"]= {
                    ["x"]= 0,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/galvanichammer.png"]= {
                    ["x"]= 37,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/golemsblood.png"]= {
                    ["x"]= 74,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/grace.png"]= {
                    ["x"]= 111,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/graveexpectations.png"]= {
                    ["x"]= 148,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/graveintentions.png"]= {
                    ["x"]= 185,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/gravepact.png"]= {
                    ["x"]= 222,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/hammerblows.png"]= {
                    ["x"]= 259,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/hatchetmaster.png"]= {
                    ["x"]= 296,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/heartofthegladiator.png"]= {
                    ["x"]= 333,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/heartpierce.png"]= {
                    ["x"]= 370,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/heartseeker.png"]= {
                    ["x"]= 407,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/heavydraw.png"]= {
                    ["x"]= 444,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/hellfire.png"]= {
                    ["x"]= 481,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/highexplosives.png"]= {
                    ["x"]= 518,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/icebite.png"]= {
                    ["x"]= 555,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/iceheart.png"]= {
                    ["x"]= 592,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/increased armor.png"]= {
                    ["x"]= 629,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/influence.png"]= {
                    ["x"]= 666,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/innerforce.png"]= {
                    ["x"]= 703,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ironwoodtotem.png"]= {
                    ["x"]= 740,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/kingofthehill.png"]= {
                    ["x"]= 777,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/lavalash.png"]= {
                    ["x"]= 814,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/leadership.png"]= {
                    ["x"]= 851,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/legendaryswordsman.png"]= {
                    ["x"]= 888,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/life1.png"]= {
                    ["x"]= 925,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/lifeleech.png"]= {
                    ["x"]= 962,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/lifeleechimmunity.png"]= {
                    ["x"]= 0,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/lightningint.png"]= {
                    ["x"]= 37,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/lordofthedead.png"]= {
                    ["x"]= 74,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/macedmg.png"]= {
                    ["x"]= 111,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/manaconduit.png"]= {
                    ["x"]= 148,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/masterfletcher.png"]= {
                    ["x"]= 185,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/mastersapper.png"]= {
                    ["x"]= 222,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/masterywand.png"]= {
                    ["x"]= 259,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/melding.png"]= {
                    ["x"]= 296,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/mentalacuity.png"]= {
                    ["x"]= 333,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/minddrinker.png"]= {
                    ["x"]= 370,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/minionblockchance.png"]= {
                    ["x"]= 407,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/newcolddamage.png"]= {
                    ["x"]= 444,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/newenergyshield.png"]= {
                    ["x"]= 481,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/newevadepercentage.png"]= {
                    ["x"]= 518,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/newincreasedcritical.png"]= {
                    ["x"]= 555,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/newnewattackspeed.png"]= {
                    ["x"]= 592,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/newtitanicmight.png"]= {
                    ["x"]= 629,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/nightstalker.png"]= {
                    ["x"]= 666,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/nimbleness.png"]= {
                    ["x"]= 703,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/oxblood.png"]= {
                    ["x"]= 740,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/perfectaim.png"]= {
                    ["x"]= 777,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/plusdexterity.png"]= {
                    ["x"]= 814,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/plusintelligence.png"]= {
                    ["x"]= 851,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/plusstrength.png"]= {
                    ["x"]= 888,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/potencyofwill.png"]= {
                    ["x"]= 925,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/precision.png"]= {
                    ["x"]= 962,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/pyromaniac.png"]= {
                    ["x"]= 0,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/quickstep.png"]= {
                    ["x"]= 37,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/razorsedge.png"]= {
                    ["x"]= 74,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/reaver.png"]= {
                    ["x"]= 111,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/revengeofthehunted.png"]= {
                    ["x"]= 148,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/saboteur.png"]= {
                    ["x"]= 185,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/savant.png"]= {
                    ["x"]= 222,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/scissorblades.png"]= {
                    ["x"]= 259,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/serpentstance.png"]= {
                    ["x"]= 296,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/shamsnisticfury.png"]= {
                    ["x"]= 333,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/shieldwall.png"]= {
                    ["x"]= 370,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/skullcracking.png"]= {
                    ["x"]= 407,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/soulsyphon.png"]= {
                    ["x"]= 444,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/sovereignty.png"]= {
                    ["x"]= 481,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/sparkingattacks.png"]= {
                    ["x"]= 518,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/stabbingcomeback.png"]= {
                    ["x"]= 555,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/staticshield.png"]= {
                    ["x"]= 592,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/stormborn.png"]= {
                    ["x"]= 629,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/strongarm.png"]= {
                    ["x"]= 666,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/stunmace.png"]= {
                    ["x"]= 703,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/stunstaff.png"]= {
                    ["x"]= 740,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/swagger.png"]= {
                    ["x"]= 777,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/swashbuckler.png"]= {
                    ["x"]= 814,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/talonsofmurder.png"]= {
                    ["x"]= 851,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/thickskin.png"]= {
                    ["x"]= 888,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/throatseeker.png"]= {
                    ["x"]= 925,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/titanicmight.png"]= {
                    ["x"]= 962,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/totemandbrandrange.png"]= {
                    ["x"]= 0,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/totemicmastery.png"]= {
                    ["x"]= 37,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/totemiczeal.png"]= {
                    ["x"]= 74,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/trapsradius.png"]= {
                    ["x"]= 111,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/trollblood.png"]= {
                    ["x"]= 148,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/volitilemines.png"]= {
                    ["x"]= 185,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/wandslingersprowess.png"]= {
                    ["x"]= 222,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/whirlingstaff.png"]= {
                    ["x"]= 259,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/wreckingball.png"]= {
                    ["x"]= 296,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Assassin.png"]= {
                    ["x"]= 333,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Berserker.png"]= {
                    ["x"]= 370,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Champion.png"]= {
                    ["x"]= 407,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Chieftain.png"]= {
                    ["x"]= 444,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Deadeye.png"]= {
                    ["x"]= 481,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Elementalist.png"]= {
                    ["x"]= 518,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Gladiator.png"]= {
                    ["x"]= 555,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Guardian.png"]= {
                    ["x"]= 592,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Hierophant.png"]= {
                    ["x"]= 629,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Inquisitor.png"]= {
                    ["x"]= 666,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Juggernaut.png"]= {
                    ["x"]= 703,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Necromancer.png"]= {
                    ["x"]= 740,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Occultist.png"]= {
                    ["x"]= 777,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Pathfinder.png"]= {
                    ["x"]= 814,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Raider.png"]= {
                    ["x"]= 851,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Saboteur.png"]= {
                    ["x"]= 888,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Slayer.png"]= {
                    ["x"]= 925,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Trickster.png"]= {
                    ["x"]= 962,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/Ambush.png"]= {
                    ["x"]= 0,
                    ["y"]= 1300,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/TawhoaForestsStrength.png"]= {
                    ["x"]= 37,
                    ["y"]= 1300,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HinekoraPassiveIcon1.png"]= {
                    ["x"]= 74,
                    ["y"]= 1300,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HinekoraPassiveIcon2.png"]= {
                    ["x"]= 111,
                    ["y"]= 1300,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HinekoraPassiveIcon3.png"]= {
                    ["x"]= 148,
                    ["y"]= 1300,
                    ["w"]= 37,
                    ["h"]= 37
                }
            }
        },
        ["keystoneActive"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/skills-3.jpg?bdc2a0fd",
            ["w"]= 999,
            ["h"]= 1496,
            ["coords"]= {
                ["Art/2DArt/SkillIcons/passives/AnointOnlyKeystone.png"]= {
                    ["x"]= 0,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/BrandKeystone.png"]= {
                    ["x"]= 52,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/CallToArms.png"]= {
                    ["x"]= 104,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/ColdPureElementalCasterKeystone.png"]= {
                    ["x"]= 156,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/CrimsonDance.png"]= {
                    ["x"]= 208,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/CritAilments.png"]= {
                    ["x"]= 260,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/Deaden.png"]= {
                    ["x"]= 312,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/DiscipleOfKitava.png"]= {
                    ["x"]= 364,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/DragonStyle.png"]= {
                    ["x"]= 416,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/EnergisedFortress.png"]= {
                    ["x"]= 468,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/EternalYouth.png"]= {
                    ["x"]= 520,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/FirePureElementalCasterKeystone.png"]= {
                    ["x"]= 572,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/GlancingBlows.png"]= {
                    ["x"]= 624,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/ImpaleKeystone.png"]= {
                    ["x"]= 676,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneAcrobatics.png"]= {
                    ["x"]= 728,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneArrowDodging.png"]= {
                    ["x"]= 780,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneAvatarOfFire.png"]= {
                    ["x"]= 832,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneBloodMagic.png"]= {
                    ["x"]= 884,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneChaosInoculation.png"]= {
                    ["x"]= 936,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneConduit.png"]= {
                    ["x"]= 0,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneEldritchBattery.png"]= {
                    ["x"]= 52,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneElementalEquilibrium.png"]= {
                    ["x"]= 104,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneElementalOverload.png"]= {
                    ["x"]= 156,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneHexMaster.png"]= {
                    ["x"]= 208,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneIronGrip.png"]= {
                    ["x"]= 260,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneIronReflexes.png"]= {
                    ["x"]= 312,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneIronWill.png"]= {
                    ["x"]= 364,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneMinionInstability.png"]= {
                    ["x"]= 416,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneNecromanticAegis.png"]= {
                    ["x"]= 468,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystonePainAttunement.png"]= {
                    ["x"]= 520,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystonePointBlankArcher.png"]= {
                    ["x"]= 572,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneResoluteTechnique.png"]= {
                    ["x"]= 624,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneUnwaveringStance.png"]= {
                    ["x"]= 676,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/Kineticism.png"]= {
                    ["x"]= 728,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/LightningPureElementalCasterKeystone.png"]= {
                    ["x"]= 780,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/LoneMessenger.png"]= {
                    ["x"]= 832,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/MiracleMaker.png"]= {
                    ["x"]= 884,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/MomentofRespite.png"]= {
                    ["x"]= 936,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/NaturesPatience.png"]= {
                    ["x"]= 0,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/EldrichBarrier.png"]= {
                    ["x"]= 52,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/Pitfighter.png"]= {
                    ["x"]= 104,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/PreciseTechnique.png"]= {
                    ["x"]= 156,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/Resilience.png"]= {
                    ["x"]= 208,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationKeystone.png"]= {
                    ["x"]= 260,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/SacredBastionKeystone.png"]= {
                    ["x"]= 312,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/SecretOfAgony.png"]= {
                    ["x"]= 364,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/SupremeEgo.png"]= {
                    ["x"]= 416,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/TinctureKeystone1.png"]= {
                    ["x"]= 468,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/AcrobaticWillpower.png"]= {
                    ["x"]= 520,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/VersatileCombatant.png"]= {
                    ["x"]= 572,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/VeteransAwareness.png"]= {
                    ["x"]= 624,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/WindDancer.png"]= {
                    ["x"]= 676,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/ghostreaver.png"]= {
                    ["x"]= 728,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/heroicspirit.png"]= {
                    ["x"]= 780,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/liferegentoenergyshield.png"]= {
                    ["x"]= 832,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/totemmax.png"]= {
                    ["x"]= 884,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/vaalpact.png"]= {
                    ["x"]= 936,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                }
            }
        },
        ["normalInactive"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/skills-disabled-3.jpg?137cafd9",
            ["w"]= 999,
            ["h"]= 1496,
            ["coords"]= {
                ["Art/2DArt/SkillIcons/passives/2handeddamage.png"]= {
                    ["x"]= 0,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/2handedspeed.png"]= {
                    ["x"]= 26,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AbyssRevampGazeoftheLichNode1.png"]= {
                    ["x"]= 52,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AbyssRevampGazeoftheLichNode2.png"]= {
                    ["x"]= 78,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AbyssRevampGazeoftheLichNode3.png"]= {
                    ["x"]= 104,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AbyssRevampGazeoftheLichNode4.png"]= {
                    ["x"]= 130,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AccuracyTemplarNode.png"]= {
                    ["x"]= 156,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AilmentDamageCritMultiplier.png"]= {
                    ["x"]= 182,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AreaDmgNode.png"]= {
                    ["x"]= 208,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AreaofEffectofMinionsNode.png"]= {
                    ["x"]= 234,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ArkhonsTools.png"]= {
                    ["x"]= 260,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ArmourAndEnergyShieldNode.png"]= {
                    ["x"]= 286,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ArmourAndEvasionNode.png"]= {
                    ["x"]= 312,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ArmourNode.png"]= {
                    ["x"]= 338,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Assassin.png"]= {
                    ["x"]= 364,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Berserker.png"]= {
                    ["x"]= 390,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Champion.png"]= {
                    ["x"]= 416,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Chieftain.png"]= {
                    ["x"]= 442,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Deadeye.png"]= {
                    ["x"]= 468,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Elementalist.png"]= {
                    ["x"]= 494,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Gladiator.png"]= {
                    ["x"]= 520,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Guardian.png"]= {
                    ["x"]= 546,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Hierophant.png"]= {
                    ["x"]= 572,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Inquisitor.png"]= {
                    ["x"]= 598,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Juggernaut.png"]= {
                    ["x"]= 624,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Necromancer.png"]= {
                    ["x"]= 650,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Occultist.png"]= {
                    ["x"]= 676,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Pathfinder.png"]= {
                    ["x"]= 702,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Raider.png"]= {
                    ["x"]= 728,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Saboteur.png"]= {
                    ["x"]= 754,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/SkillPoint.png"]= {
                    ["x"]= 780,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Slayer.png"]= {
                    ["x"]= 806,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Trickster.png"]= {
                    ["x"]= 832,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/Ambush.png"]= {
                    ["x"]= 858,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/SmallNode.png"]= {
                    ["x"]= 884,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/AbyssNode1.png"]= {
                    ["x"]= 910,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/AbyssNotable1.png"]= {
                    ["x"]= 936,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/AulBloodlineNode.png"]= {
                    ["x"]= 962,
                    ["y"]= 0,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/AulBloodlinechargedex.png"]= {
                    ["x"]= 0,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/AulBloodlinechargeint.png"]= {
                    ["x"]= 26,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/AulBloodlinechargestr.png"]= {
                    ["x"]= 52,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BestiaryNode1.png"]= {
                    ["x"]= 78,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BestiaryNotable4.png"]= {
                    ["x"]= 104,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BestiaryNotable5.png"]= {
                    ["x"]= 130,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BestiaryNotable6.png"]= {
                    ["x"]= 156,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BloodLineOlrothRune1.png"]= {
                    ["x"]= 182,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BloodLineOlrothRune2.png"]= {
                    ["x"]= 208,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BloodLineOlrothRune3.png"]= {
                    ["x"]= 234,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BoldUndertaking.png"]= {
                    ["x"]= 260,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BreachBossClaspedHands.png"]= {
                    ["x"]= 286,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/DeliriumNode1.png"]= {
                    ["x"]= 312,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/ExpeditionNode1.png"]= {
                    ["x"]= 338,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/HarbingerNotable3.png"]= {
                    ["x"]= 364,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/LichNode1.png"]= {
                    ["x"]= 390,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/LyciaNode1.png"]= {
                    ["x"]= 416,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/MorePrimalWispsSmall.png"]= {
                    ["x"]= 442,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/MoreVividWispsSmall.png"]= {
                    ["x"]= 468,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/MoreWildWispsSmall.png"]= {
                    ["x"]= 494,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/PerandusNotable2.png"]= {
                    ["x"]= 520,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RitualBloodlineNode.png"]= {
                    ["x"]= 546,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/UltimatumNode1.png"]= {
                    ["x"]= 572,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/UltimatumNotable6.png"]= {
                    ["x"]= 598,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/UltimatumNotableMonsters1.png"]= {
                    ["x"]= 624,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/UltimatumNotableMonsters2.png"]= {
                    ["x"]= 650,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/UltimatumNotableStoneCircle.png"]= {
                    ["x"]= 676,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AttackBlindNode.png"]= {
                    ["x"]= 702,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AttackDamangeAndEvasionNotableNode.png"]= {
                    ["x"]= 728,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AttackPoisonNode.png"]= {
                    ["x"]= 754,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/AuraEffectNode.png"]= {
                    ["x"]= 780,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BannerAreaNode.png"]= {
                    ["x"]= 806,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BannerDurationNode.png"]= {
                    ["x"]= 832,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BannerEffectNode.png"]= {
                    ["x"]= 858,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BannerResourceAreaNode.png"]= {
                    ["x"]= 884,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/DmgAttackSpeed.png"]= {
                    ["x"]= 910,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/DmgCrit.png"]= {
                    ["x"]= 936,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/DmgLeech.png"]= {
                    ["x"]= 962,
                    ["y"]= 26,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/DmgWarcry.png"]= {
                    ["x"]= 0,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BlackFlameFire.png"]= {
                    ["x"]= 26,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BleedAndPoisonMitigateNode.png"]= {
                    ["x"]= 52,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BlockAttackDmgNode.png"]= {
                    ["x"]= 78,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BlockSpellDmgNode.png"]= {
                    ["x"]= 104,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Blood2.png"]= {
                    ["x"]= 130,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BluntInstrument.png"]= {
                    ["x"]= 156,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BowDamage.png"]= {
                    ["x"]= 182,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BoxOfJewels.png"]= {
                    ["x"]= 208,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Brand1.png"]= {
                    ["x"]= 234,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Brand2.png"]= {
                    ["x"]= 260,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BrandDmgNode.png"]= {
                    ["x"]= 286,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/BrassDomeNode.png"]= {
                    ["x"]= 312,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Champion/AnEAttDamage.png"]= {
                    ["x"]= 338,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Champion/AnEAura.png"]= {
                    ["x"]= 364,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Champion/AnEFortify.png"]= {
                    ["x"]= 390,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Champion/AnETaunt.png"]= {
                    ["x"]= 416,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Champion/ImpalePassive.png"]= {
                    ["x"]= 442,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ChaosDamage.png"]= {
                    ["x"]= 468,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ChaosDamageOverTimeNode.png"]= {
                    ["x"]= 494,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ChaosDamagenode.png"]= {
                    ["x"]= 520,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ChaosResistNode.png"]= {
                    ["x"]= 546,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ChaosResistNotable.png"]= {
                    ["x"]= 572,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/LifeRegenFireDamage.png"]= {
                    ["x"]= 598,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/LifeRegenStrength.png"]= {
                    ["x"]= 624,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/LifeRegenTotemPlacementSpeed.png"]= {
                    ["x"]= 650,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ChoiroftheStorm.png"]= {
                    ["x"]= 676,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ClawCritStrikeChanceNode.png"]= {
                    ["x"]= 702,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ColdAndFireHybridNode.png"]= {
                    ["x"]= 728,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ColdDamageOverTimeNode.png"]= {
                    ["x"]= 754,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ColdDamagenode.png"]= {
                    ["x"]= 780,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ColdResistNode.png"]= {
                    ["x"]= 806,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CooldownWarcryNode1.png"]= {
                    ["x"]= 832,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CorpseDamage.png"]= {
                    ["x"]= 858,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CorpseLife.png"]= {
                    ["x"]= 884,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CrownOfTheInwardEye.png"]= {
                    ["x"]= 910,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CrustaceansCall.png"]= {
                    ["x"]= 936,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CrustaceousGrowth.png"]= {
                    ["x"]= 962,
                    ["y"]= 52,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CurseAreaofEffect.png"]= {
                    ["x"]= 0,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CurseCastSpeed.png"]= {
                    ["x"]= 26,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CurseDuration.png"]= {
                    ["x"]= 52,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CurseEffectNode.png"]= {
                    ["x"]= 78,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CurseManaCost.png"]= {
                    ["x"]= 104,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CurseManaReservation.png"]= {
                    ["x"]= 130,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/CursemitigationclusterNode.png"]= {
                    ["x"]= 156,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DamageOverTime.png"]= {
                    ["x"]= 182,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DamageOverTimeNode.png"]= {
                    ["x"]= 208,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DeadEye/ProjectileDamageAccuracy.png"]= {
                    ["x"]= 234,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DeadEye/ProjectileDamageAttackSpeed.png"]= {
                    ["x"]= 260,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Deathsdoor.png"]= {
                    ["x"]= 286,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DivineFury.png"]= {
                    ["x"]= 312,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DivineWrath.png"]= {
                    ["x"]= 338,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DmgHeraldSkillsNode.png"]= {
                    ["x"]= 364,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DmgWhenChannelSkillsNode.png"]= {
                    ["x"]= 390,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DodgeAtksNode.png"]= {
                    ["x"]= 416,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DraugursLantern.png"]= {
                    ["x"]= 442,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DualWieldNodeDefensive.png"]= {
                    ["x"]= 468,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DualWieldNodeOffensive.png"]= {
                    ["x"]= 494,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/DurationofMinionsNode.png"]= {
                    ["x"]= 520,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ElementalDamagenode.png"]= {
                    ["x"]= 546,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ElementalResistance2.png"]= {
                    ["x"]= 572,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/ElementalDamageAttackCasteSpeed.png"]= {
                    ["x"]= 598,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/ElementalDamageElementalResistances.png"]= {
                    ["x"]= 624,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/ElementalDamageFreezeShockIgnite.png"]= {
                    ["x"]= 650,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/EmpoweredAttackWarcryNode1.png"]= {
                    ["x"]= 676,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/EnergyShieldNode.png"]= {
                    ["x"]= 702,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/EnergyshieldLeechPassivessmall.png"]= {
                    ["x"]= 728,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/EssentiaSanguis.png"]= {
                    ["x"]= 754,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/EvasionNode.png"]= {
                    ["x"]= 780,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/EvasionandEnergyShieldNode.png"]= {
                    ["x"]= 806,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/FesteringResentment.png"]= {
                    ["x"]= 832,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/FireDamageOverTimeNode.png"]= {
                    ["x"]= 858,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/FireDamagenode.png"]= {
                    ["x"]= 884,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/FireResistNode.png"]= {
                    ["x"]= 910,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/FlaskDurationnode.png"]= {
                    ["x"]= 936,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/FortifyNode.png"]= {
                    ["x"]= 962,
                    ["y"]= 78,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/GenericWarcryNode1.png"]= {
                    ["x"]= 0,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/GenericWarcryNode2.png"]= {
                    ["x"]= 26,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/GenericWarcryNode3.png"]= {
                    ["x"]= 52,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GLADBlockChance.png"]= {
                    ["x"]= 78,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GLADOneHand.png"]= {
                    ["x"]= 104,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/GoddessScales.png"]= {
                    ["x"]= 130,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/GolemsNode.png"]= {
                    ["x"]= 156,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/GreenPhysicalDamageNode.png"]= {
                    ["x"]= 182,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/ArmourEnergyMeleeDamage.png"]= {
                    ["x"]= 208,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/ArmourEnergyShieldDefenseFromShields.png"]= {
                    ["x"]= 234,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/ArmourEnergyShieldManaPool.png"]= {
                    ["x"]= 260,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/ArmourEnergyShieldStaves.png"]= {
                    ["x"]= 286,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/GuardianHallowingFlameNode.png"]= {
                    ["x"]= 312,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/Minion Damage Armour and Energy Shield.png"]= {
                    ["x"]= 338,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/TimeOfNeed.png"]= {
                    ["x"]= 364,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/HalfColdHalfLightning.png"]= {
                    ["x"]= 390,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/HeraldBuffEffectNode2.png"]= {
                    ["x"]= 416,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/HeraldDamageNotable.png"]= {
                    ["x"]= 442,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/HeraldReservationNode.png"]= {
                    ["x"]= 468,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/ManaRegen.png"]= {
                    ["x"]= 494,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IgniteBleedNode.png"]= {
                    ["x"]= 520,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ImapleNode.png"]= {
                    ["x"]= 546,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ImpaleNode2.png"]= {
                    ["x"]= 572,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreaseCritChanceNode.png"]= {
                    ["x"]= 598,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreaseMinionLifeNode.png"]= {
                    ["x"]= 624,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedAttackDamageNode.png"]= {
                    ["x"]= 650,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedManaCostNode.png"]= {
                    ["x"]= 676,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedMaximumLifeNode.png"]= {
                    ["x"]= 702,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedMinionDamageNode.png"]= {
                    ["x"]= 728,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedNonDamageAilmentNode.png"]= {
                    ["x"]= 754,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedProjectileSpeedNode.png"]= {
                    ["x"]= 780,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedSpellDamageNode.png"]= {
                    ["x"]= 806,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedWarcryNode.png"]= {
                    ["x"]= 832,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/IncreasedElementalDamageAttackCasteSpeed.png"]= {
                    ["x"]= 858,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/IncreasedElementalDamageAvoidElementalStatusEffects.png"]= {
                    ["x"]= 884,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/IncreasedElementalDamageCasteSpeed.png"]= {
                    ["x"]= 910,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/IncreasedElementalDamageElementalPenetration.png"]= {
                    ["x"]= 936,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/IncreasedArmourAttackDamage.png"]= {
                    ["x"]= 962,
                    ["y"]= 104,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/IncreasedArmourAttackSpeed.png"]= {
                    ["x"]= 0,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/IncreasedArmourLifeRegeneration.png"]= {
                    ["x"]= 26,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/IncreasedArmourMovementSpeed.png"]= {
                    ["x"]= 52,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/IncreasedArmourStunDuration.png"]= {
                    ["x"]= 78,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/JuggernautArmourNotable.png"]= {
                    ["x"]= 104,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneArmourMaster.png"]= {
                    ["x"]= 130,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LifeAndEnergyShield.png"]= {
                    ["x"]= 156,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LifeAndReducedManaCost.png"]= {
                    ["x"]= 182,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LifeManaFlasksrecoverynode.png"]= {
                    ["x"]= 208,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LifeRecoupNode.png"]= {
                    ["x"]= 234,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LifeandCurses.png"]= {
                    ["x"]= 260,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LifeandMana.png"]= {
                    ["x"]= 286,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LightningDamagenode.png"]= {
                    ["x"]= 312,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LightningResistNode.png"]= {
                    ["x"]= 338,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/LivingBlade.png"]= {
                    ["x"]= 364,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNode.png"]= {
                    ["x"]= 390,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable9.png"]= {
                    ["x"]= 416,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable10.png"]= {
                    ["x"]= 442,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable11.png"]= {
                    ["x"]= 468,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable12.png"]= {
                    ["x"]= 494,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable13.png"]= {
                    ["x"]= 520,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable14.png"]= {
                    ["x"]= 546,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MaceElemental.png"]= {
                    ["x"]= 572,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ManaAndEnergyShield.png"]= {
                    ["x"]= 598,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ManaLeechThemedNode.png"]= {
                    ["x"]= 624,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ManaandCurses2.png"]= {
                    ["x"]= 650,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MarkNode.png"]= {
                    ["x"]= 676,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MasteryBlank.png"]= {
                    ["x"]= 702,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MaxManaNode.png"]= {
                    ["x"]= 728,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MeleeAoENode.png"]= {
                    ["x"]= 754,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MeleeCriticalStrikeChanceNode.png"]= {
                    ["x"]= 780,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MeleeCriticalStrikeMultiplierNode.png"]= {
                    ["x"]= 806,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MeleeFireNode.png"]= {
                    ["x"]= 832,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MineAreaOfEffectNode.png"]= {
                    ["x"]= 858,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MineManaReservationNode.png"]= {
                    ["x"]= 884,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MinionAccuracyDamage.png"]= {
                    ["x"]= 910,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MinionChaosResistanceNode.png"]= {
                    ["x"]= 936,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MinionDmgHeraldSkillsNode.png"]= {
                    ["x"]= 962,
                    ["y"]= 130,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MinionElementalResistancesNode.png"]= {
                    ["x"]= 0,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MonasteryBell.png"]= {
                    ["x"]= 26,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/MovementSpeedandEvasionPassive.png"]= {
                    ["x"]= 52,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NaturalHeirachy.png"]= {
                    ["x"]= 78,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/CorpseConsumptionNode.png"]= {
                    ["x"]= 104,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/IncreasedMinionDamageIncreasedMinionLife.png"]= {
                    ["x"]= 130,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/IncreasedMinionDamageIncreasedSkillDuration.png"]= {
                    ["x"]= 156,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/ManaNode.png"]= {
                    ["x"]= 182,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NodeAxeandSwordDamage.png"]= {
                    ["x"]= 208,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NodeBowDamage.png"]= {
                    ["x"]= 234,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NodeDaggerandClawDamage.png"]= {
                    ["x"]= 260,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NodeDualWieldingDamage.png"]= {
                    ["x"]= 286,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NodeHoldingShieldDamage.png"]= {
                    ["x"]= 312,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NodeMaceandStaffDamage.png"]= {
                    ["x"]= 338,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NodeTwoHandedMeleeDamage.png"]= {
                    ["x"]= 364,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/NodeWandDamage.png"]= {
                    ["x"]= 390,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/EnergyShieldChaos.png"]= {
                    ["x"]= 416,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/EnergyShieldCold.png"]= {
                    ["x"]= 442,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/IncreasedEnergyShieldAttackAndCastSpeed.png"]= {
                    ["x"]= 468,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/IncreasedEnergyShieldCriticalStrikeChance.png"]= {
                    ["x"]= 494,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/IncreasedEnergyShieldManaReservation.png"]= {
                    ["x"]= 520,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/IncreasedEnergyShieldMaximumMana.png"]= {
                    ["x"]= 546,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/OneHandedPhysicalAndLeechNode.png"]= {
                    ["x"]= 572,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/OneHandedPhysicalAndLeechNotable.png"]= {
                    ["x"]= 598,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/FlaskEffectDamageOverTime.png"]= {
                    ["x"]= 624,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/FlaskEffectElementalResistance.png"]= {
                    ["x"]= 650,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/FlaskEffectFlaskDuration.png"]= {
                    ["x"]= 676,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageNode.png"]= {
                    ["x"]= 702,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageOverTimeNode.png"]= {
                    ["x"]= 728,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageOverTimenode3.png"]= {
                    ["x"]= 754,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamagenode2.png"]= {
                    ["x"]= 780,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalandChaosDamage.png"]= {
                    ["x"]= 806,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Poison.png"]= {
                    ["x"]= 832,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/PoisonSpellsNode.png"]= {
                    ["x"]= 858,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Praxis.png"]= {
                    ["x"]= 884,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Primalist/PrimalistNode.png"]= {
                    ["x"]= 910,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ProjectileDmgNode.png"]= {
                    ["x"]= 936,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ProjectilesNode.png"]= {
                    ["x"]= 962,
                    ["y"]= 156,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ProjectilesNode2.png"]= {
                    ["x"]= 0,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Rage.png"]= {
                    ["x"]= 26,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Raider/IncreasedElementalDamage.png"]= {
                    ["x"]= 52,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RangedTotemAttackSpeed.png"]= {
                    ["x"]= 78,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RangedTotemDamage.png"]= {
                    ["x"]= 104,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RedAttackSmallPassive.png"]= {
                    ["x"]= 130,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ReducedManaCostNode.png"]= {
                    ["x"]= 156,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ReducedSkillEffectDurationNode.png"]= {
                    ["x"]= 182,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationNode1.png"]= {
                    ["x"]= 208,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationNode2.png"]= {
                    ["x"]= 234,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationNode3.png"]= {
                    ["x"]= 260,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationNode4.png"]= {
                    ["x"]= 286,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationNode5.png"]= {
                    ["x"]= 312,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/RigwaldsQuills.png"]= {
                    ["x"]= 338,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/ElementalDamageElementalResistance.png"]= {
                    ["x"]= 364,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/ElementalDamageMines.png"]= {
                    ["x"]= 390,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/ElementalDamageMovementSpeed.png"]= {
                    ["x"]= 416,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SareshBloodlineNode.png"]= {
                    ["x"]= 442,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ShadowStitch.png"]= {
                    ["x"]= 468,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SharpandBrittle.png"]= {
                    ["x"]= 494,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ShieldAttackDamage.png"]= {
                    ["x"]= 520,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/ShieldNodeOffensive.png"]= {
                    ["x"]= 546,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/2HdmgAOE.png"]= {
                    ["x"]= 572,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/2HdmgCritStrikeMultiplier.png"]= {
                    ["x"]= 598,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/2HdmgFrenzyEnduranceCharge.png"]= {
                    ["x"]= 624,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/2HdmgLeech.png"]= {
                    ["x"]= 650,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/2HdmgSpeed.png"]= {
                    ["x"]= 676,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SolarisWand.png"]= {
                    ["x"]= 702,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SpeedWarcryNode1.png"]= {
                    ["x"]= 728,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SpellMultiplyer2.png"]= {
                    ["x"]= 754,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SpellSuppresionNode.png"]= {
                    ["x"]= 780,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SpellSuppressionEnergyShield.png"]= {
                    ["x"]= 806,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SpellSuppressionLifeFlasks.png"]= {
                    ["x"]= 832,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/StaffNodeDefensive.png"]= {
                    ["x"]= 858,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/StaffNodeOffensive.png"]= {
                    ["x"]= 884,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/StanceSmallPassive.png"]= {
                    ["x"]= 910,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/StancesNode.png"]= {
                    ["x"]= 936,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Starfell.png"]= {
                    ["x"]= 962,
                    ["y"]= 182,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/StrikeRangeNode.png"]= {
                    ["x"]= 0,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Tidebreaker.png"]= {
                    ["x"]= 26,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/TinctureFlaskNode1.png"]= {
                    ["x"]= 52,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/TinctureNode1.png"]= {
                    ["x"]= 78,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/TinctureNode2.png"]= {
                    ["x"]= 104,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/TinctureNode3.png"]= {
                    ["x"]= 130,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/TotemDmgNode.png"]= {
                    ["x"]= 156,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/TrapAndMineDmgNode.png"]= {
                    ["x"]= 182,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/TremorRod.png"]= {
                    ["x"]= 208,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/DefensiveNodeTrickster.png"]= {
                    ["x"]= 234,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/OffensiveNodeTrickster.png"]= {
                    ["x"]= 260,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/UnitedinDream.png"]= {
                    ["x"]= 286,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanCurses2.png"]= {
                    ["x"]= 312,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanNode.png"]= {
                    ["x"]= 338,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanSpecialCurse1.png"]= {
                    ["x"]= 364,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanSpecialCurse2.png"]= {
                    ["x"]= 390,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanSpecialCurse3.png"]= {
                    ["x"]= 416,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/WandCritical.png"]= {
                    ["x"]= 442,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/WandSpeedAccuracyNode.png"]= {
                    ["x"]= 468,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/WarCryCooldown.png"]= {
                    ["x"]= 494,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/WarcryBuffEffectNotable.png"]= {
                    ["x"]= 520,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Warden/SpellSuppressionEvasion.png"]= {
                    ["x"]= 546,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Warden/TincturesNode.png"]= {
                    ["x"]= 572,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenNode.png"]= {
                    ["x"]= 598,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenTracking.png"]= {
                    ["x"]= 624,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/accuracy.png"]= {
                    ["x"]= 650,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/accuracy2h.png"]= {
                    ["x"]= 676,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/accuracydex.png"]= {
                    ["x"]= 702,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/accuracysword.png"]= {
                    ["x"]= 728,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/arcaneradience.png"]= {
                    ["x"]= 754,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/areaofeffect.png"]= {
                    ["x"]= 780,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeed.png"]= {
                    ["x"]= 806,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeed2h.png"]= {
                    ["x"]= 832,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeedaxe.png"]= {
                    ["x"]= 858,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeedbow.png"]= {
                    ["x"]= 884,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeedclaw.png"]= {
                    ["x"]= 910,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeeddagger.png"]= {
                    ["x"]= 936,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeeddual.png"]= {
                    ["x"]= 962,
                    ["y"]= 208,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeedmace.png"]= {
                    ["x"]= 0,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/attackspeedsworddex.png"]= {
                    ["x"]= 26,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/auraareaofeffect.png"]= {
                    ["x"]= 52,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/auraeffect.png"]= {
                    ["x"]= 78,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/avoidburning.png"]= {
                    ["x"]= 104,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/avoidchilling.png"]= {
                    ["x"]= 130,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/axedmgspeed.png"]= {
                    ["x"]= 156,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/blankDex.png"]= {
                    ["x"]= 182,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/blankInt.png"]= {
                    ["x"]= 208,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/blankStr.png"]= {
                    ["x"]= 234,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/blastradius.png"]= {
                    ["x"]= 260,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/blockstaff.png"]= {
                    ["x"]= 286,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/blockstr.png"]= {
                    ["x"]= 312,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/castavoidinterruption.png"]= {
                    ["x"]= 338,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/castspeed.png"]= {
                    ["x"]= 364,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/chargedex.png"]= {
                    ["x"]= 390,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/chargeint.png"]= {
                    ["x"]= 416,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/chargestr.png"]= {
                    ["x"]= 442,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/clawmasterydex.png"]= {
                    ["x"]= 468,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/clustersLinknode1.png"]= {
                    ["x"]= 494,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/clustersLinknode2.png"]= {
                    ["x"]= 520,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/colddamage.png"]= {
                    ["x"]= 546,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/coldresist.png"]= {
                    ["x"]= 572,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/criticalbow.png"]= {
                    ["x"]= 598,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/criticalclaw.png"]= {
                    ["x"]= 624,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/criticaldaggerdex.png"]= {
                    ["x"]= 650,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/criticaldaggerint.png"]= {
                    ["x"]= 676,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/criticalstrikechance.png"]= {
                    ["x"]= 702,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/criticalstrikechance2.png"]= {
                    ["x"]= 728,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/criticalstrikemultiplier.png"]= {
                    ["x"]= 754,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/criticalstrikemultiplier2.png"]= {
                    ["x"]= 780,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/critstrchnc.png"]= {
                    ["x"]= 806,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/crystalskin.png"]= {
                    ["x"]= 832,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damage.png"]= {
                    ["x"]= 858,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damage_blue.png"]= {
                    ["x"]= 884,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damageaxe.png"]= {
                    ["x"]= 910,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damagedualwield.png"]= {
                    ["x"]= 936,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damagedualwieldgreen.png"]= {
                    ["x"]= 962,
                    ["y"]= 234,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damagemelee.png"]= {
                    ["x"]= 0,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damagespells.png"]= {
                    ["x"]= 26,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damagestaff.png"]= {
                    ["x"]= 52,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/damagesword.png"]= {
                    ["x"]= 78,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/dmgreduction.png"]= {
                    ["x"]= 104,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/dualwieldaccuracy.png"]= {
                    ["x"]= 130,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/dualwieldblock.png"]= {
                    ["x"]= 156,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/elementaldamage.png"]= {
                    ["x"]= 182,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/energyshield.png"]= {
                    ["x"]= 208,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/evade.png"]= {
                    ["x"]= 234,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/evadepercentage.png"]= {
                    ["x"]= 260,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/evasion.png"]= {
                    ["x"]= 286,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/firedamage.png"]= {
                    ["x"]= 312,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/firedamageint.png"]= {
                    ["x"]= 338,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/firedamagestr.png"]= {
                    ["x"]= 364,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/fireresist.png"]= {
                    ["x"]= 390,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/flaskdex.png"]= {
                    ["x"]= 416,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/flaskint.png"]= {
                    ["x"]= 442,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/flaskstr.png"]= {
                    ["x"]= 468,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/increased armor.png"]= {
                    ["x"]= 494,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/increasedarmorandlife.png"]= {
                    ["x"]= 520,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/increasedrunspeeddex.png"]= {
                    ["x"]= 546,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/innerforce.png"]= {
                    ["x"]= 572,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/knockback.png"]= {
                    ["x"]= 598,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/life1.png"]= {
                    ["x"]= 624,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/lifegainpertarget.png"]= {
                    ["x"]= 650,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/lifeleech.png"]= {
                    ["x"]= 676,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/lifemana.png"]= {
                    ["x"]= 702,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/lifepercentage.png"]= {
                    ["x"]= 728,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/lightningdex.png"]= {
                    ["x"]= 754,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/lightningint.png"]= {
                    ["x"]= 780,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/lightningstr.png"]= {
                    ["x"]= 806,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/macecritdmgspeed.png"]= {
                    ["x"]= 832,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/macedmg.png"]= {
                    ["x"]= 858,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/mana.png"]= {
                    ["x"]= 884,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/manaregeneration.png"]= {
                    ["x"]= 910,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/manareservationreduction.png"]= {
                    ["x"]= 936,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/manastr.png"]= {
                    ["x"]= 962,
                    ["y"]= 260,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/masterydaggerdex.png"]= {
                    ["x"]= 0,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/masterysword.png"]= {
                    ["x"]= 26,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/masterywand.png"]= {
                    ["x"]= 52,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/meleeattackspeed.png"]= {
                    ["x"]= 78,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/minionattackspeed.png"]= {
                    ["x"]= 104,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/minionblockchance.png"]= {
                    ["x"]= 130,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/miniondamage.png"]= {
                    ["x"]= 156,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/miniondamageBlue.png"]= {
                    ["x"]= 182,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/minionlife.png"]= {
                    ["x"]= 208,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/onehanddamage.png"]= {
                    ["x"]= 234,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/onehandspeed.png"]= {
                    ["x"]= 260,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/plusdexterity.png"]= {
                    ["x"]= 286,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/plusintelligence.png"]= {
                    ["x"]= 312,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/plusintelligencedexterity.png"]= {
                    ["x"]= 338,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/plusstrength.png"]= {
                    ["x"]= 364,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/plusstrengthdexterity.png"]= {
                    ["x"]= 390,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/plusstrengthintelligence.png"]= {
                    ["x"]= 416,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/projectilespeed.png"]= {
                    ["x"]= 442,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/shieldblock.png"]= {
                    ["x"]= 468,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/skillduration.png"]= {
                    ["x"]= 494,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/spellcritical.png"]= {
                    ["x"]= 520,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/staffaccuracy.png"]= {
                    ["x"]= 546,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/staffspeed.png"]= {
                    ["x"]= 572,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/stundex.png"]= {
                    ["x"]= 598,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/stunmace.png"]= {
                    ["x"]= 624,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/stunstr.png"]= {
                    ["x"]= 650,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/tempdex.png"]= {
                    ["x"]= 676,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/tempint.png"]= {
                    ["x"]= 702,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/totemandbrandattackspeed.png"]= {
                    ["x"]= 728,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/totemandbranddamage.png"]= {
                    ["x"]= 754,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/totemandbrandrange.png"]= {
                    ["x"]= 780,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/totemattackspeed.png"]= {
                    ["x"]= 806,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/totemlife.png"]= {
                    ["x"]= 832,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/trapcriticalstrike.png"]= {
                    ["x"]= 858,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/trapdamage.png"]= {
                    ["x"]= 884,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/trapsduration.png"]= {
                    ["x"]= 910,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/trapsradius.png"]= {
                    ["x"]= 936,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/trapsspeed.png"]= {
                    ["x"]= 962,
                    ["y"]= 286,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/weaponelementaldamagepercentage.png"]= {
                    ["x"]= 0,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/ArohonguiTribeSkill.png"]= {
                    ["x"]= 26,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/HinekoraTribeSkill.png"]= {
                    ["x"]= 52,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/KitavaTribeSkill.png"]= {
                    ["x"]= 78,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/NgamahuTribeSkill.png"]= {
                    ["x"]= 104,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/RamakoTribeSkill.png"]= {
                    ["x"]= 130,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/RongokuraiTribeSkill.png"]= {
                    ["x"]= 156,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/TasalioTribeSkill.png"]= {
                    ["x"]= 182,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/TawhoaTribeSkill.png"]= {
                    ["x"]= 208,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/TukohamaTribeSkill.png"]= {
                    ["x"]= 234,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/ValakoTribeSkill.png"]= {
                    ["x"]= 260,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/HinekoraPassiveIcon1.png"]= {
                    ["x"]= 286,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/HinekoraPassiveIcon2.png"]= {
                    ["x"]= 312,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/HinekoraPassiveIcon3.png"]= {
                    ["x"]= 338,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/SkillscostingLifenode.png"]= {
                    ["x"]= 364,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/accuracyint.png"]= {
                    ["x"]= 390,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                },
                ["Art/2DArt/SkillIcons/passives/totemandbrandlife.png"]= {
                    ["x"]= 416,
                    ["y"]= 312,
                    ["w"]= 26,
                    ["h"]= 26
                }
            }
        },
        ["notableInactive"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/skills-disabled-3.jpg?137cafd9",
            ["w"]= 999,
            ["h"]= 1496,
            ["coords"]= {
                ["Art/2DArt/SkillIcons/passives/2handeddamage.png"]= {
                    ["x"]= 0,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AbyssRevampAbyssalFiends.png"]= {
                    ["x"]= 37,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AbyssRevampGazeoftheLich.png"]= {
                    ["x"]= 74,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AbyssRevampStygianSpires.png"]= {
                    ["x"]= 111,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AccuracyTemplar1.png"]= {
                    ["x"]= 148,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AccuracyTemplar2.png"]= {
                    ["x"]= 185,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Additionalprojectile.png"]= {
                    ["x"]= 222,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AdmonisherNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Annihilation.png"]= {
                    ["x"]= 296,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AntiStunNotable.png"]= {
                    ["x"]= 333,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ArcaneChemistry.png"]= {
                    ["x"]= 370,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ArcaneReaping.png"]= {
                    ["x"]= 407,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AreaDmgNotable.png"]= {
                    ["x"]= 444,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AreaofEffectofMinionsNotable.png"]= {
                    ["x"]= 481,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ArmourChargeNotable.png"]= {
                    ["x"]= 518,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ArmourGuardsNotable.png"]= {
                    ["x"]= 555,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ArmourNotable.png"]= {
                    ["x"]= 592,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ArmourandEvasion2.png"]= {
                    ["x"]= 629,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Ascendancy.png"]= {
                    ["x"]= 666,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Dex.png"]= {
                    ["x"]= 703,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/DexInt.png"]= {
                    ["x"]= 740,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Int.png"]= {
                    ["x"]= 777,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/ReliquarianAscendancyCenter.png"]= {
                    ["x"]= 814,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Str.png"]= {
                    ["x"]= 851,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/StrDex.png"]= {
                    ["x"]= 888,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/StrInt.png"]= {
                    ["x"]= 925,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AspectOfTheLynx.png"]= {
                    ["x"]= 962,
                    ["y"]= 338,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AspectoftheEagle.png"]= {
                    ["x"]= 0,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/Assassinate.png"]= {
                    ["x"]= 37,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/DeadlyInfusion.png"]= {
                    ["x"]= 74,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/Elusive.png"]= {
                    ["x"]= 111,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/NoxiousStrike.png"]= {
                    ["x"]= 148,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/ToxicDelivery.png"]= {
                    ["x"]= 185,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/UnstableInfusion.png"]= {
                    ["x"]= 222,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AssassinAnointNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/AulBloodlineNotable.png"]= {
                    ["x"]= 296,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BestiaryNotable4.png"]= {
                    ["x"]= 333,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BloodLineOlrothNotable.png"]= {
                    ["x"]= 370,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BoldUndertaking.png"]= {
                    ["x"]= 407,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/BreachNotable4.png"]= {
                    ["x"]= 444,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/DeliriumNotable1.png"]= {
                    ["x"]= 481,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/FarrulNotable1.png"]= {
                    ["x"]= 518,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/HarbingerNode1.png"]= {
                    ["x"]= 555,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/LyciaNotable1.png"]= {
                    ["x"]= 592,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/MorePrimalWisps.png"]= {
                    ["x"]= 629,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/MoreVividWisps.png"]= {
                    ["x"]= 666,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/MoreWildWisps.png"]= {
                    ["x"]= 703,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/TempestNotable1.png"]= {
                    ["x"]= 740,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/UltimatumNotable3.png"]= {
                    ["x"]= 777,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/UltimatumNotable4.png"]= {
                    ["x"]= 814,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AttackBlindNotable.png"]= {
                    ["x"]= 851,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AttackDamangeAndEvasionNotableIcon.png"]= {
                    ["x"]= 888,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AttackPoisonNotable.png"]= {
                    ["x"]= 925,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AuraEffectNotable.png"]= {
                    ["x"]= 962,
                    ["y"]= 375,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AuraReservationNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AvataroftheHunt2.png"]= {
                    ["x"]= 37,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AvoidInterruptionFromCastingNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AxeNotable1.png"]= {
                    ["x"]= 111,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AxeNotable2.png"]= {
                    ["x"]= 148,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AxeandSwordDamage.png"]= {
                    ["x"]= 185,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/AxesandAttackSpeed.png"]= {
                    ["x"]= 222,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BannerAreaNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BannerDurationNotable.png"]= {
                    ["x"]= 296,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BannerEffectNotable.png"]= {
                    ["x"]= 333,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BannerResourceAreaNotable.png"]= {
                    ["x"]= 370,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BannersNotable.png"]= {
                    ["x"]= 407,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BarragingProjectilesNotable.png"]= {
                    ["x"]= 444,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BattleRouse.png"]= {
                    ["x"]= 481,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/AspectOfCarnage.png"]= {
                    ["x"]= 518,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/Blitz.png"]= {
                    ["x"]= 555,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/CloakedAgony.png"]= {
                    ["x"]= 592,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/CombatFrenzy.png"]= {
                    ["x"]= 629,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/DefyPain.png"]= {
                    ["x"]= 666,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/RiteOfRuin.png"]= {
                    ["x"]= 703,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Berserker/WarBringer.png"]= {
                    ["x"]= 740,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BeserkerAnointNotable.png"]= {
                    ["x"]= 777,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BladeBarrierNotable.png"]= {
                    ["x"]= 814,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BleedPoison.png"]= {
                    ["x"]= 851,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BleedPoisonMitigateNotable.png"]= {
                    ["x"]= 888,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BleedingNotable1.png"]= {
                    ["x"]= 925,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BleedingNotable2.png"]= {
                    ["x"]= 962,
                    ["y"]= 412,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BlockAttackDmgNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BlockSpellDmgNotable.png"]= {
                    ["x"]= 37,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Blood2.png"]= {
                    ["x"]= 74,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BloodPact.png"]= {
                    ["x"]= 111,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BloodSiphon.png"]= {
                    ["x"]= 148,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BloodyBludgeon.png"]= {
                    ["x"]= 185,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Boomerang.png"]= {
                    ["x"]= 222,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BowDamage.png"]= {
                    ["x"]= 259,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Brand2.png"]= {
                    ["x"]= 296,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Brand3.png"]= {
                    ["x"]= 333,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Brand4.png"]= {
                    ["x"]= 370,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BrandDmgNotable.png"]= {
                    ["x"]= 407,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BreathofFlames2.png"]= {
                    ["x"]= 444,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BreathofLightening2.png"]= {
                    ["x"]= 481,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BreathofRime2.png"]= {
                    ["x"]= 518,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/BrineRot.png"]= {
                    ["x"]= 555,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ByTheBlade.png"]= {
                    ["x"]= 592,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CelestialPunishment.png"]= {
                    ["x"]= 629,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ChainingProjectiles.png"]= {
                    ["x"]= 666,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Champion.png"]= {
                    ["x"]= 703,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Champion/FirstStrikeLastFall.png"]= {
                    ["x"]= 740,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Champion/Fortitude.png"]= {
                    ["x"]= 777,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Champion/ImpalePassiveNotable.png"]= {
                    ["x"]= 814,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Champion/Inpirational.png"]= {
                    ["x"]= 851,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Champion/Unstopable.png"]= {
                    ["x"]= 888,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Champion/WorthyCauses.png"]= {
                    ["x"]= 925,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Champion/WorthyFoe.png"]= {
                    ["x"]= 962,
                    ["y"]= 449,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ChampionAnointNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ChaosDamage2.png"]= {
                    ["x"]= 37,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ChaosDamageOverTimeNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ChaosDamageOverTimeNotable2.png"]= {
                    ["x"]= 111,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ChaosResistNotable.png"]= {
                    ["x"]= 148,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ChaoticPotential.png"]= {
                    ["x"]= 185,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CheiftainAnointNotable.png"]= {
                    ["x"]= 222,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/ArohunguiMoonsPresenceWarcry.png"]= {
                    ["x"]= 259,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/HinekoraDeathsFury.png"]= {
                    ["x"]= 296,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/NgamahuFlamesAdvance.png"]= {
                    ["x"]= 333,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/RamakoSunsLight.png"]= {
                    ["x"]= 370,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/TasalioCleansingWater.png"]= {
                    ["x"]= 407,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/TukomahaWarsHerald.png"]= {
                    ["x"]= 444,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/ValakoStormsEmbrace.png"]= {
                    ["x"]= 481,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ChillThemedNotable.png"]= {
                    ["x"]= 518,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ClawNotable1.png"]= {
                    ["x"]= 555,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ClawNotable2.png"]= {
                    ["x"]= 592,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ClawsOfTheMagpie.png"]= {
                    ["x"]= 629,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CleverThief.png"]= {
                    ["x"]= 666,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ColdAndFireHybridNotable.png"]= {
                    ["x"]= 703,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ColdDamageEnemyNotable.png"]= {
                    ["x"]= 740,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ColdDamageOverTimeNotable.png"]= {
                    ["x"]= 777,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ColdResistNotable.png"]= {
                    ["x"]= 814,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ColdWeaponDmg.png"]= {
                    ["x"]= 851,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ColdheartedCalculation2.png"]= {
                    ["x"]= 888,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CombatFocusNotable.png"]= {
                    ["x"]= 925,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CombatStamina.png"]= {
                    ["x"]= 962,
                    ["y"]= 486,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CommandofSteel.png"]= {
                    ["x"]= 0,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Constitution.png"]= {
                    ["x"]= 37,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Coordination.png"]= {
                    ["x"]= 74,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CorpsesNotable.png"]= {
                    ["x"]= 111,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Corruption.png"]= {
                    ["x"]= 148,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CritStrikeBleedingNotable.png"]= {
                    ["x"]= 185,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CrustaceousGrowth2.png"]= {
                    ["x"]= 222,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CurseAreaOfEffectNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CurseEffectNotable.png"]= {
                    ["x"]= 296,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CurseNotable.png"]= {
                    ["x"]= 333,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CurseNotable2.png"]= {
                    ["x"]= 370,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/CursemitigationclusterNotable.png"]= {
                    ["x"]= 407,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DaggerNotable1.png"]= {
                    ["x"]= 444,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DaggerandClawDamage.png"]= {
                    ["x"]= 481,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DamageOverTimeNotable.png"]= {
                    ["x"]= 518,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DamageofMinionsNotable.png"]= {
                    ["x"]= 555,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DarkestHour.png"]= {
                    ["x"]= 592,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DeadEye/DeadeyeFrenzyChargeNotable.png"]= {
                    ["x"]= 629,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DeadEye/FarShot.png"]= {
                    ["x"]= 666,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DeadEye/GatherWinds.png"]= {
                    ["x"]= 703,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DeadEye/Ricochet.png"]= {
                    ["x"]= 740,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DeadeyeAnointNotable.png"]= {
                    ["x"]= 777,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DeepBreathsNotable.png"]= {
                    ["x"]= 814,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DiamondSkin2.png"]= {
                    ["x"]= 851,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DireTorment.png"]= {
                    ["x"]= 888,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DivineFury.png"]= {
                    ["x"]= 925,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DivineWrath.png"]= {
                    ["x"]= 962,
                    ["y"]= 523,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DmgHeraldSkillsNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DmgWhenChannelSkillsNotable.png"]= {
                    ["x"]= 37,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DodgeAtksNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Dreamer.png"]= {
                    ["x"]= 111,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DruidicRite.png"]= {
                    ["x"]= 148,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DualWieldNotable.png"]= {
                    ["x"]= 185,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DualWieldingBlockNotable.png"]= {
                    ["x"]= 222,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DualWieldingDamage.png"]= {
                    ["x"]= 259,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/DurationofMinionsNotable.png"]= {
                    ["x"]= 296,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ElementalAilmentResistance.png"]= {
                    ["x"]= 333,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ElementalDamagewithAttacks2.png"]= {
                    ["x"]= 370,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ElementalDominion2.png"]= {
                    ["x"]= 407,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ElementalFocus.png"]= {
                    ["x"]= 444,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/ChillSpecialisation.png"]= {
                    ["x"]= 481,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/ElemancerIcon.png"]= {
                    ["x"]= 518,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/IgniteSpecialisation.png"]= {
                    ["x"]= 555,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/IridescentFlesh.png"]= {
                    ["x"]= 592,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/LiegeOfThePrimordial.png"]= {
                    ["x"]= 629,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/PendulumOfDestruction.png"]= {
                    ["x"]= 666,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/PrimevalForce.png"]= {
                    ["x"]= 703,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Elementalist/ShockSpecialisation.png"]= {
                    ["x"]= 740,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ElementalistAnointNotable.png"]= {
                    ["x"]= 777,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EnduranceChargeNotable.png"]= {
                    ["x"]= 814,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EnergyShieldNotable.png"]= {
                    ["x"]= 851,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Entropy.png"]= {
                    ["x"]= 888,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EscalationNotable.png"]= {
                    ["x"]= 925,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EssenceSurge.png"]= {
                    ["x"]= 962,
                    ["y"]= 560,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EvasionAndBlindNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EvasionAndPhasingNotable.png"]= {
                    ["x"]= 37,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EvasionNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ExceptionalPerformance.png"]= {
                    ["x"]= 111,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ExplosiveRunes.png"]= {
                    ["x"]= 148,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EyesOfTheDeadly.png"]= {
                    ["x"]= 185,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EyesOfThePowerful.png"]= {
                    ["x"]= 222,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/EyesOfTheSavant.png"]= {
                    ["x"]= 259,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FasterBleeding2.png"]= {
                    ["x"]= 296,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FatalBlade.png"]= {
                    ["x"]= 333,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FireAilment.png"]= {
                    ["x"]= 370,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FireDamageOverTimeNotable.png"]= {
                    ["x"]= 407,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FireResistNotable.png"]= {
                    ["x"]= 444,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FlaskDuration.png"]= {
                    ["x"]= 481,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FlaskNotableCritStrikeRecharge.png"]= {
                    ["x"]= 518,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FlaskNotableFlasksLastLonger.png"]= {
                    ["x"]= 555,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ForceOfNature.png"]= {
                    ["x"]= 592,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ForkingProjectilesNotable.png"]= {
                    ["x"]= 629,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FortifyNotable1.png"]= {
                    ["x"]= 666,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FortifyNotable2.png"]= {
                    ["x"]= 703,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/FrenzyChargeNotable.png"]= {
                    ["x"]= 740,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/GenericBlockNotable1.png"]= {
                    ["x"]= 777,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/GenericBlockNotable2.png"]= {
                    ["x"]= 814,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/GenericSpellBlockNotable.png"]= {
                    ["x"]= 851,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GLADBloodAndSand.png"]= {
                    ["x"]= 888,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GLADBloodInEyes.png"]= {
                    ["x"]= 925,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GLADPainForged.png"]= {
                    ["x"]= 962,
                    ["y"]= 597,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GLADVersitileCombatant.png"]= {
                    ["x"]= 0,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GLADViolence.png"]= {
                    ["x"]= 37,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GLADViolentRetaliation.png"]= {
                    ["x"]= 74,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Gladiator/GladiatorDualWiledSwordAxeNotable.png"]= {
                    ["x"]= 111,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/GladiatorAnointNotable.png"]= {
                    ["x"]= 148,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/GolemsNotable.png"]= {
                    ["x"]= 185,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/GreenProjectileAttackNotable.png"]= {
                    ["x"]= 222,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/GrowthandDecay.png"]= {
                    ["x"]= 259,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/GuardianHallowingFlameNotable.png"]= {
                    ["x"]= 296,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/HarmonyOfPurpose.png"]= {
                    ["x"]= 333,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/Radient Crusade.png"]= {
                    ["x"]= 370,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/RadientFaith.png"]= {
                    ["x"]= 407,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/ShieldMastery.png"]= {
                    ["x"]= 444,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/TimeOfNeed.png"]= {
                    ["x"]= 481,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/Unwavering Crusade.png"]= {
                    ["x"]= 518,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Guardian/UnwaveringFaith.png"]= {
                    ["x"]= 555,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/GuardianAnointNotable.png"]= {
                    ["x"]= 592,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Harrier.png"]= {
                    ["x"]= 629,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HeartandSoul.png"]= {
                    ["x"]= 666,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HeartofChaos.png"]= {
                    ["x"]= 703,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HeartoftheOak.png"]= {
                    ["x"]= 740,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hearty.png"]= {
                    ["x"]= 777,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HeirophantAnointNotable.png"]= {
                    ["x"]= 814,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HeraldBuffEffectNode2.png"]= {
                    ["x"]= 851,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HeraldDamageNotable.png"]= {
                    ["x"]= 888,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HeraldReservation.png"]= {
                    ["x"]= 925,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/AncestralZeal.png"]= {
                    ["x"]= 962,
                    ["y"]= 634,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/ArcaneSurge.png"]= {
                    ["x"]= 0,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/DiscipleOfRuin.png"]= {
                    ["x"]= 37,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/ItemAugment.png"]= {
                    ["x"]= 74,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/MindOverBeing.png"]= {
                    ["x"]= 111,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/MindOverBody.png"]= {
                    ["x"]= 148,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/SignOfPurpose.png"]= {
                    ["x"]= 185,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hierophant/SpiritualEmpowerment.png"]= {
                    ["x"]= 222,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HiredKiller2.png"]= {
                    ["x"]= 259,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HoldingShieldDamage.png"]= {
                    ["x"]= 296,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Hunter.png"]= {
                    ["x"]= 333,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IgniteAshNotable.png"]= {
                    ["x"]= 370,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IgniteAttackNotable.png"]= {
                    ["x"]= 407,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IgniteBleedNotable.png"]= {
                    ["x"]= 444,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IgniteStunNotable.png"]= {
                    ["x"]= 481,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IgnorePain.png"]= {
                    ["x"]= 518,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Impale1HandNotable.png"]= {
                    ["x"]= 555,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ImpaleEffectNotable.png"]= {
                    ["x"]= 592,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ImpaleNotable1.png"]= {
                    ["x"]= 629,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ImpaleNotable2.png"]= {
                    ["x"]= 666,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreaseCritChanceNotable.png"]= {
                    ["x"]= 703,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreaseMinionLifeNotable.png"]= {
                    ["x"]= 740,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedAttackDamageNotable.png"]= {
                    ["x"]= 777,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedChaosDamage.png"]= {
                    ["x"]= 814,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedColdDamage.png"]= {
                    ["x"]= 851,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedElementalDamage.png"]= {
                    ["x"]= 888,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedFireDamage.png"]= {
                    ["x"]= 925,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedLightningDamage.png"]= {
                    ["x"]= 962,
                    ["y"]= 671,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedManaCostNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedMaximumLifeNotable.png"]= {
                    ["x"]= 37,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedMinionDamageNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedNonDamageAilmentNotable.png"]= {
                    ["x"]= 111,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedPhysicalDamage.png"]= {
                    ["x"]= 148,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedSpellDamageNode.png"]= {
                    ["x"]= 185,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedSpellDamageNotable.png"]= {
                    ["x"]= 222,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IncreasedWarcryNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/InfusedFlesh.png"]= {
                    ["x"]= 296,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/InquisitorAnointNotable.png"]= {
                    ["x"]= 333,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/CriticalStrikeChance.png"]= {
                    ["x"]= 370,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/ElementalDomination.png"]= {
                    ["x"]= 407,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/ElementalForce.png"]= {
                    ["x"]= 444,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/ElementalMastery.png"]= {
                    ["x"]= 481,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/GloryOfTheSavant.png"]= {
                    ["x"]= 518,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/InstrumentsOfVirtue.png"]= {
                    ["x"]= 555,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/InstrumentsofZeal.png"]= {
                    ["x"]= 592,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inquistitor/Sanctify.png"]= {
                    ["x"]= 629,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Inspiration.png"]= {
                    ["x"]= 666,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/IntensifyNotable.png"]= {
                    ["x"]= 703,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/JuggernautArmourNotable.png"]= {
                    ["x"]= 740,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/Unbreakable.png"]= {
                    ["x"]= 777,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/Undeniable.png"]= {
                    ["x"]= 814,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/Unflinching.png"]= {
                    ["x"]= 851,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/Unrelenting.png"]= {
                    ["x"]= 888,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/Unstoppable.png"]= {
                    ["x"]= 925,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Juggernaut/Unyielding.png"]= {
                    ["x"]= 962,
                    ["y"]= 708,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/JuggernautAnointNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneArmourMaster.png"]= {
                    ["x"]= 37,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneWhispersOfDoom.png"]= {
                    ["x"]= 74,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeArmourAndEvasion.png"]= {
                    ["x"]= 111,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeFlasks.png"]= {
                    ["x"]= 148,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeGainOnHitNotable.png"]= {
                    ["x"]= 185,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeManaFlasksrecovery.png"]= {
                    ["x"]= 222,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeRecoupNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeRegenerationGainRegenNotable.png"]= {
                    ["x"]= 296,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeRegenerationLowlifeBonusNotable.png"]= {
                    ["x"]= 333,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeandCursesN.png"]= {
                    ["x"]= 370,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeandManaFlasks.png"]= {
                    ["x"]= 407,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LifeandResistancesofMinions.png"]= {
                    ["x"]= 444,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LightOfDivinity.png"]= {
                    ["x"]= 481,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LightningResistNotable.png"]= {
                    ["x"]= 518,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LinkNotable3.png"]= {
                    ["x"]= 555,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LinkNotable4.png"]= {
                    ["x"]= 592,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable1.png"]= {
                    ["x"]= 629,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable2.png"]= {
                    ["x"]= 666,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable3.png"]= {
                    ["x"]= 703,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable4.png"]= {
                    ["x"]= 740,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable5.png"]= {
                    ["x"]= 777,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Luminary/LuminaryNotable6.png"]= {
                    ["x"]= 814,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/LustforCarnage.png"]= {
                    ["x"]= 851,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MaceNotable1.png"]= {
                    ["x"]= 888,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MaceNotable2.png"]= {
                    ["x"]= 925,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MaceandStaffDamage.png"]= {
                    ["x"]= 962,
                    ["y"]= 745,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ManaDamageKeystone.png"]= {
                    ["x"]= 0,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ManaFlasksOften.png"]= {
                    ["x"]= 37,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ManaGuardNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ManaNotable.png"]= {
                    ["x"]= 111,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ManaandArcaneSurge.png"]= {
                    ["x"]= 148,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ManaandSpellBlock.png"]= {
                    ["x"]= 185,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ManaandSpellDamage.png"]= {
                    ["x"]= 222,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Mark.png"]= {
                    ["x"]= 259,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MarkNotable1.png"]= {
                    ["x"]= 296,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MarkNotable2.png"]= {
                    ["x"]= 333,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MarkNotableIncreasedEffect.png"]= {
                    ["x"]= 370,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MarkNotableMarkSpellRecently.png"]= {
                    ["x"]= 407,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MartialExperience.png"]= {
                    ["x"]= 444,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MasterofForce.png"]= {
                    ["x"]= 481,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MaxElementalResistNotable.png"]= {
                    ["x"]= 518,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MaxManaNotable.png"]= {
                    ["x"]= 555,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MaximumElementalResistances2.png"]= {
                    ["x"]= 592,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MeasuredFuryNotable.png"]= {
                    ["x"]= 629,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MeleeAoENode.png"]= {
                    ["x"]= 666,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MeleeAoENotable.png"]= {
                    ["x"]= 703,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MeleeCriticalStrikesNotable.png"]= {
                    ["x"]= 740,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MeleeFireNotable.png"]= {
                    ["x"]= 777,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MeleeRange2.png"]= {
                    ["x"]= 814,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MeleeUtility.png"]= {
                    ["x"]= 851,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Meleerange.png"]= {
                    ["x"]= 888,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MentalRapidity.png"]= {
                    ["x"]= 925,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MindPact.png"]= {
                    ["x"]= 962,
                    ["y"]= 782,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MineAreaOfEffectNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MineCriticalStrikesNotable.png"]= {
                    ["x"]= 37,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MineManaReservationNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MineTrap.png"]= {
                    ["x"]= 111,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/MinionDmgHeraldSkillsNotable.png"]= {
                    ["x"]= 148,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Mirage.png"]= {
                    ["x"]= 185,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/NaturalAuthorityNotable.png"]= {
                    ["x"]= 222,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/CommandingTheDarkness.png"]= {
                    ["x"]= 259,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/CorpseConsumptionNotable2.png"]= {
                    ["x"]= 296,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/DefensiveMinionNotable.png"]= {
                    ["x"]= 333,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/EssenceGlutton.png"]= {
                    ["x"]= 370,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/GenericMinionNotable.png"]= {
                    ["x"]= 407,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/GiftsOfTheDamned.png"]= {
                    ["x"]= 444,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/OffensiveMinionNotable.png"]= {
                    ["x"]= 481,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Necromancer/PlagueBringer.png"]= {
                    ["x"]= 518,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/NecromancerAnointNotable.png"]= {
                    ["x"]= 555,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/EldrichBarrier.png"]= {
                    ["x"]= 592,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/FatefulEchoes.png"]= {
                    ["x"]= 629,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/FrigidWake.png"]= {
                    ["x"]= 666,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/LotusExtract.png"]= {
                    ["x"]= 703,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/SoulCatalyst.png"]= {
                    ["x"]= 740,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/VoidBeacon.png"]= {
                    ["x"]= 777,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/VowOfDamnation.png"]= {
                    ["x"]= 814,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/WitheringPresence.png"]= {
                    ["x"]= 851,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/OccultistAnointNotable.png"]= {
                    ["x"]= 888,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/OneHandedPhysicalAndLeechNotable.png"]= {
                    ["x"]= 925,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/AlchemistGift.png"]= {
                    ["x"]= 962,
                    ["y"]= 819,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/MasterAlchemist.png"]= {
                    ["x"]= 0,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/MasterHerbalist.png"]= {
                    ["x"]= 37,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/MasterSurgeon.png"]= {
                    ["x"]= 74,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/Master Toxicist.png"]= {
                    ["x"]= 111,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/NaturesAdrenaline.png"]= {
                    ["x"]= 148,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PathFinder/VeteranBowyer.png"]= {
                    ["x"]= 185,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PathfinderAnointNotable.png"]= {
                    ["x"]= 222,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageNotableGreen.png"]= {
                    ["x"]= 296,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageOverTimeHybrid.png"]= {
                    ["x"]= 333,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageOverTimeNotable.png"]= {
                    ["x"]= 370,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageOverTimenotable1.png"]= {
                    ["x"]= 407,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PhysicalDamageOverTimenotable2.png"]= {
                    ["x"]= 444,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Poison.png"]= {
                    ["x"]= 481,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PoisonSpellsNotable.png"]= {
                    ["x"]= 518,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/PowerChargeNotable.png"]= {
                    ["x"]= 555,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Primalist/PrimalistCorpseLoot.png"]= {
                    ["x"]= 592,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Primalist/PrimalistInventoryExpansion.png"]= {
                    ["x"]= 629,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ProfaneChemistry.png"]= {
                    ["x"]= 666,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ProjectileDmgNotable.png"]= {
                    ["x"]= 703,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ProjectilesNotable.png"]= {
                    ["x"]= 740,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ProtectiveWinds.png"]= {
                    ["x"]= 777,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/QuickRecovery.png"]= {
                    ["x"]= 814,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RageNotable.png"]= {
                    ["x"]= 851,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RageNotable1.png"]= {
                    ["x"]= 888,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RageNotable2.png"]= {
                    ["x"]= 925,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RageNotable3.png"]= {
                    ["x"]= 962,
                    ["y"]= 856,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RangedTotemCriticalStrikes.png"]= {
                    ["x"]= 0,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RangedTotemOffensive.png"]= {
                    ["x"]= 37,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RedHolyAttackNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Redemption.png"]= {
                    ["x"]= 111,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ReducedManaNotable.png"]= {
                    ["x"]= 148,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ReducedProjectileSpeedNotable.png"]= {
                    ["x"]= 185,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ReducedSkillEffectDurationNotable.png"]= {
                    ["x"]= 222,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Resourcefulness.png"]= {
                    ["x"]= 259,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Retaliation.png"]= {
                    ["x"]= 296,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationAoE.png"]= {
                    ["x"]= 333,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationAttackBlock.png"]= {
                    ["x"]= 370,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationDurationCooldown.png"]= {
                    ["x"]= 407,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationSkillDamage.png"]= {
                    ["x"]= 444,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationSpellBlock.png"]= {
                    ["x"]= 481,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationStun.png"]= {
                    ["x"]= 518,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Retribution.png"]= {
                    ["x"]= 555,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Revelry.png"]= {
                    ["x"]= 592,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RighteousArmy.png"]= {
                    ["x"]= 629,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Righteous Decree.png"]= {
                    ["x"]= 666,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/RitualBloodLineNotable.png"]= {
                    ["x"]= 703,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Robust.png"]= {
                    ["x"]= 740,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/BlindedAssult.png"]= {
                    ["x"]= 777,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/BombSpecialist.png"]= {
                    ["x"]= 814,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/ChainReaction.png"]= {
                    ["x"]= 851,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/DemolitionSpecialist.png"]= {
                    ["x"]= 888,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/ExplosivesExpert.png"]= {
                    ["x"]= 925,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/LikeClockworkNotable.png"]= {
                    ["x"]= 962,
                    ["y"]= 893,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/PerfectCrime.png"]= {
                    ["x"]= 0,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/ShadowsDarknessBlind.png"]= {
                    ["x"]= 37,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Saboteur/ShrapnelSpecialist.png"]= {
                    ["x"]= 74,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SaboteurAnointNotable.png"]= {
                    ["x"]= 111,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Sanctuary.png"]= {
                    ["x"]= 148,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SareshBloodlineNotable1.png"]= {
                    ["x"]= 185,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SareshBloodlineNotable3.png"]= {
                    ["x"]= 222,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SareshBloodlineNoteble2.png"]= {
                    ["x"]= 259,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SavantPath.png"]= {
                    ["x"]= 296,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SearingHeat.png"]= {
                    ["x"]= 333,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Sentinel.png"]= {
                    ["x"]= 370,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Shaper.png"]= {
                    ["x"]= 407,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ShieldAttackDamage.png"]= {
                    ["x"]= 444,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ShieldNotable.png"]= {
                    ["x"]= 481,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ShrugOff.png"]= {
                    ["x"]= 518,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SkitteringRunes.png"]= {
                    ["x"]= 555,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/BaneOfLegends.png"]= {
                    ["x"]= 592,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/BrutalFervor.png"]= {
                    ["x"]= 629,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/Charges.png"]= {
                    ["x"]= 666,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/CriticalAttacks.png"]= {
                    ["x"]= 703,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/EndlessHunger.png"]= {
                    ["x"]= 740,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/Headman.png"]= {
                    ["x"]= 777,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Slayer/Impact.png"]= {
                    ["x"]= 814,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SlayerAnointNotable.png"]= {
                    ["x"]= 851,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SoulPact.png"]= {
                    ["x"]= 888,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SoulSiphoning.png"]= {
                    ["x"]= 925,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SpellSuppressionLifeFlasksN.png"]= {
                    ["x"]= 962,
                    ["y"]= 930,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SpellSupressionAndEnergyShieldNotable.png"]= {
                    ["x"]= 0,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SpellSupressionNotable1.png"]= {
                    ["x"]= 37,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SpellSupressionNotable2.png"]= {
                    ["x"]= 74,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SpikedBulwark.png"]= {
                    ["x"]= 111,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SpiritualAid.png"]= {
                    ["x"]= 148,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SpiritualCommand.png"]= {
                    ["x"]= 185,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StaffCrit.png"]= {
                    ["x"]= 222,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StaffNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StaffNotable2.png"]= {
                    ["x"]= 296,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StaffNotable3.png"]= {
                    ["x"]= 333,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StanceNotableReservation.png"]= {
                    ["x"]= 370,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StanceNotableSwitching.png"]= {
                    ["x"]= 407,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Storm Weaver.png"]= {
                    ["x"]= 444,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StrengthOfBlood.png"]= {
                    ["x"]= 481,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StrikeSkillsNotable.png"]= {
                    ["x"]= 518,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StunAvoidNotable.png"]= {
                    ["x"]= 555,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/StunMastery.png"]= {
                    ["x"]= 592,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SupremeProdigy.png"]= {
                    ["x"]= 629,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Survivalist.png"]= {
                    ["x"]= 666,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/SwordNotable1.png"]= {
                    ["x"]= 703,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TasteforBlood.png"]= {
                    ["x"]= 740,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TempestBlast.png"]= {
                    ["x"]= 777,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ThrillKiller.png"]= {
                    ["x"]= 814,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TideCaller.png"]= {
                    ["x"]= 851,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TinctureFlaskNotable1.png"]= {
                    ["x"]= 888,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TinctureManaNotable1.png"]= {
                    ["x"]= 925,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TinctureNotable1.png"]= {
                    ["x"]= 962,
                    ["y"]= 967,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TinctureNotable2.png"]= {
                    ["x"]= 0,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TinctureNotable3.png"]= {
                    ["x"]= 37,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TotemDmgNotable.png"]= {
                    ["x"]= 74,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trap.png"]= {
                    ["x"]= 111,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trap2.png"]= {
                    ["x"]= 148,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TrapAndMineDmgNotable.png"]= {
                    ["x"]= 185,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/DamageOverTime.png"]= {
                    ["x"]= 222,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/HeedfulRecovery.png"]= {
                    ["x"]= 259,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/ImmuneToDoT.png"]= {
                    ["x"]= 296,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/OneStepAheadTrickster.png"]= {
                    ["x"]= 333,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/PolymathTrickster.png"]= {
                    ["x"]= 370,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/SoulThiefTrickster.png"]= {
                    ["x"]= 407,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/SupressionEnergyShieldTrickster.png"]= {
                    ["x"]= 444,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/UncontrolledVigour.png"]= {
                    ["x"]= 481,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TricksterAnointNotable.png"]= {
                    ["x"]= 518,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TrueStriker.png"]= {
                    ["x"]= 555,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TwoHandedMeleeDamage.png"]= {
                    ["x"]= 592,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/TwoHandedweaponImpalesNotable.png"]= {
                    ["x"]= 629,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Unfaltering.png"]= {
                    ["x"]= 666,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Unrelenting.png"]= {
                    ["x"]= 703,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Unwavering.png"]= {
                    ["x"]= 740,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/UpwardsFiringProjectilesNotable.png"]= {
                    ["x"]= 777,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Vampirism.png"]= {
                    ["x"]= 814,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/VoidBarrier.png"]= {
                    ["x"]= 851,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanBloodMagic1.png"]= {
                    ["x"]= 888,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanBloodMagic2.png"]= {
                    ["x"]= 925,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanBloodMagic3.png"]= {
                    ["x"]= 962,
                    ["y"]= 1004,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanCorpses.png"]= {
                    ["x"]= 0,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanCurses2.png"]= {
                    ["x"]= 37,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanCursesChoice.png"]= {
                    ["x"]= 74,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/VoodooShaman/VoodooShamanVoodooDoll.png"]= {
                    ["x"]= 111,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/WandDamage.png"]= {
                    ["x"]= 148,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/WarcryBuffEffectNotable.png"]= {
                    ["x"]= 185,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/WarcryGainDamageNotable.png"]= {
                    ["x"]= 222,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/TinctureRangedNotable.png"]= {
                    ["x"]= 259,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenAllAilments.png"]= {
                    ["x"]= 296,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenBarkskin1.png"]= {
                    ["x"]= 333,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenBarkskin2.png"]= {
                    ["x"]= 370,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenColdAilments.png"]= {
                    ["x"]= 407,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenFireAilments.png"]= {
                    ["x"]= 444,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenLightningAilments.png"]= {
                    ["x"]= 481,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenPrimitivism.png"]= {
                    ["x"]= 518,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenSaps1.png"]= {
                    ["x"]= 555,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenSaps2.png"]= {
                    ["x"]= 592,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenSaps3.png"]= {
                    ["x"]= 629,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warden/WardenTracking.png"]= {
                    ["x"]= 666,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/WardenAnointNotable.png"]= {
                    ["x"]= 703,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Warrior.png"]= {
                    ["x"]= 740,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/WeaponElementalNotable.png"]= {
                    ["x"]= 777,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/WritteninBlood.png"]= {
                    ["x"]= 814,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/accuracydex.png"]= {
                    ["x"]= 851,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/adderstouch.png"]= {
                    ["x"]= 888,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ambidexterity.png"]= {
                    ["x"]= 925,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/amplify.png"]= {
                    ["x"]= 962,
                    ["y"]= 1041,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/animalspirit.png"]= {
                    ["x"]= 0,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/arcaneefficiency.png"]= {
                    ["x"]= 37,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/arcane focus.png"]= {
                    ["x"]= 74,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/arcanepotency.png"]= {
                    ["x"]= 111,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/arcaneradience.png"]= {
                    ["x"]= 148,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/armourmastery.png"]= {
                    ["x"]= 185,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/arsonist.png"]= {
                    ["x"]= 222,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ashfrostandstorm.png"]= {
                    ["x"]= 259,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/attackspeedbow.png"]= {
                    ["x"]= 296,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/authority.png"]= {
                    ["x"]= 333,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/barricade.png"]= {
                    ["x"]= 370,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/berserking.png"]= {
                    ["x"]= 407,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/bladebarrier.png"]= {
                    ["x"]= 444,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/blademaster.png"]= {
                    ["x"]= 481,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/blademistress.png"]= {
                    ["x"]= 518,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/blastradius.png"]= {
                    ["x"]= 555,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/bodysoul.png"]= {
                    ["x"]= 592,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/borntofight.png"]= {
                    ["x"]= 629,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/breathofrime.png"]= {
                    ["x"]= 666,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/butchery.png"]= {
                    ["x"]= 703,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/castavoidinterruption.png"]= {
                    ["x"]= 740,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/catalyse.png"]= {
                    ["x"]= 777,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/chargedex.png"]= {
                    ["x"]= 814,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/chargeint.png"]= {
                    ["x"]= 851,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/chargestr.png"]= {
                    ["x"]= 888,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/cleverconstruction.png"]= {
                    ["x"]= 925,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/clustersLink2.png"]= {
                    ["x"]= 962,
                    ["y"]= 1078,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/clustersLink3.png"]= {
                    ["x"]= 0,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/criticalstrikemultiplier2.png"]= {
                    ["x"]= 37,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/cruelblade.png"]= {
                    ["x"]= 74,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/daggerpenetration.png"]= {
                    ["x"]= 111,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/deadlydraw.png"]= {
                    ["x"]= 148,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/deadlyprecision.png"]= {
                    ["x"]= 185,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/deathattunement.png"]= {
                    ["x"]= 222,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/deepthoughts.png"]= {
                    ["x"]= 259,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/deepwisdom.png"]= {
                    ["x"]= 296,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/diamondskin.png"]= {
                    ["x"]= 333,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/doomcast.png"]= {
                    ["x"]= 370,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/eagleeye.png"]= {
                    ["x"]= 407,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/eagletalons.png"]= {
                    ["x"]= 444,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/elderpower.png"]= {
                    ["x"]= 481,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/elementalist.png"]= {
                    ["x"]= 518,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/evasion.png"]= {
                    ["x"]= 555,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/executioner.png"]= {
                    ["x"]= 592,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/expeditiousmunitions.png"]= {
                    ["x"]= 629,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/fellingtheweak.png"]= {
                    ["x"]= 666,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/fending.png"]= {
                    ["x"]= 703,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/finesse.png"]= {
                    ["x"]= 740,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/firedamage.png"]= {
                    ["x"]= 777,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/flameborn.png"]= {
                    ["x"]= 814,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/flaying.png"]= {
                    ["x"]= 851,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/foresight.png"]= {
                    ["x"]= 888,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/frostborn.png"]= {
                    ["x"]= 925,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/furybolts.png"]= {
                    ["x"]= 962,
                    ["y"]= 1115,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/fussilade.png"]= {
                    ["x"]= 0,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/galvanichammer.png"]= {
                    ["x"]= 37,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/golemsblood.png"]= {
                    ["x"]= 74,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/grace.png"]= {
                    ["x"]= 111,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/graveexpectations.png"]= {
                    ["x"]= 148,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/graveintentions.png"]= {
                    ["x"]= 185,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/gravepact.png"]= {
                    ["x"]= 222,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/hammerblows.png"]= {
                    ["x"]= 259,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/hatchetmaster.png"]= {
                    ["x"]= 296,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/heartofthegladiator.png"]= {
                    ["x"]= 333,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/heartpierce.png"]= {
                    ["x"]= 370,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/heartseeker.png"]= {
                    ["x"]= 407,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/heavydraw.png"]= {
                    ["x"]= 444,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/hellfire.png"]= {
                    ["x"]= 481,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/highexplosives.png"]= {
                    ["x"]= 518,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/icebite.png"]= {
                    ["x"]= 555,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/iceheart.png"]= {
                    ["x"]= 592,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/increased armor.png"]= {
                    ["x"]= 629,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/influence.png"]= {
                    ["x"]= 666,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/innerforce.png"]= {
                    ["x"]= 703,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/ironwoodtotem.png"]= {
                    ["x"]= 740,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/kingofthehill.png"]= {
                    ["x"]= 777,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/lavalash.png"]= {
                    ["x"]= 814,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/leadership.png"]= {
                    ["x"]= 851,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/legendaryswordsman.png"]= {
                    ["x"]= 888,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/life1.png"]= {
                    ["x"]= 925,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/lifeleech.png"]= {
                    ["x"]= 962,
                    ["y"]= 1152,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/lifeleechimmunity.png"]= {
                    ["x"]= 0,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/lightningint.png"]= {
                    ["x"]= 37,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/lordofthedead.png"]= {
                    ["x"]= 74,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/macedmg.png"]= {
                    ["x"]= 111,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/manaconduit.png"]= {
                    ["x"]= 148,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/masterfletcher.png"]= {
                    ["x"]= 185,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/mastersapper.png"]= {
                    ["x"]= 222,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/masterywand.png"]= {
                    ["x"]= 259,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/melding.png"]= {
                    ["x"]= 296,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/mentalacuity.png"]= {
                    ["x"]= 333,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/minddrinker.png"]= {
                    ["x"]= 370,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/minionblockchance.png"]= {
                    ["x"]= 407,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/newcolddamage.png"]= {
                    ["x"]= 444,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/newenergyshield.png"]= {
                    ["x"]= 481,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/newevadepercentage.png"]= {
                    ["x"]= 518,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/newincreasedcritical.png"]= {
                    ["x"]= 555,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/newnewattackspeed.png"]= {
                    ["x"]= 592,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/newtitanicmight.png"]= {
                    ["x"]= 629,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/nightstalker.png"]= {
                    ["x"]= 666,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/nimbleness.png"]= {
                    ["x"]= 703,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/oxblood.png"]= {
                    ["x"]= 740,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/perfectaim.png"]= {
                    ["x"]= 777,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/plusdexterity.png"]= {
                    ["x"]= 814,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/plusintelligence.png"]= {
                    ["x"]= 851,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/plusstrength.png"]= {
                    ["x"]= 888,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/potencyofwill.png"]= {
                    ["x"]= 925,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/precision.png"]= {
                    ["x"]= 962,
                    ["y"]= 1189,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/pyromaniac.png"]= {
                    ["x"]= 0,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/quickstep.png"]= {
                    ["x"]= 37,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/razorsedge.png"]= {
                    ["x"]= 74,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/reaver.png"]= {
                    ["x"]= 111,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/revengeofthehunted.png"]= {
                    ["x"]= 148,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/saboteur.png"]= {
                    ["x"]= 185,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/savant.png"]= {
                    ["x"]= 222,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/scissorblades.png"]= {
                    ["x"]= 259,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/serpentstance.png"]= {
                    ["x"]= 296,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/shamsnisticfury.png"]= {
                    ["x"]= 333,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/shieldwall.png"]= {
                    ["x"]= 370,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/skullcracking.png"]= {
                    ["x"]= 407,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/soulsyphon.png"]= {
                    ["x"]= 444,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/sovereignty.png"]= {
                    ["x"]= 481,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/sparkingattacks.png"]= {
                    ["x"]= 518,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/stabbingcomeback.png"]= {
                    ["x"]= 555,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/staticshield.png"]= {
                    ["x"]= 592,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/stormborn.png"]= {
                    ["x"]= 629,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/strongarm.png"]= {
                    ["x"]= 666,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/stunmace.png"]= {
                    ["x"]= 703,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/stunstaff.png"]= {
                    ["x"]= 740,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/swagger.png"]= {
                    ["x"]= 777,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/swashbuckler.png"]= {
                    ["x"]= 814,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/talonsofmurder.png"]= {
                    ["x"]= 851,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/thickskin.png"]= {
                    ["x"]= 888,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/throatseeker.png"]= {
                    ["x"]= 925,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/titanicmight.png"]= {
                    ["x"]= 962,
                    ["y"]= 1226,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/totemandbrandrange.png"]= {
                    ["x"]= 0,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/totemicmastery.png"]= {
                    ["x"]= 37,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/totemiczeal.png"]= {
                    ["x"]= 74,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/trapsradius.png"]= {
                    ["x"]= 111,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/trollblood.png"]= {
                    ["x"]= 148,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/volitilemines.png"]= {
                    ["x"]= 185,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/wandslingersprowess.png"]= {
                    ["x"]= 222,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/whirlingstaff.png"]= {
                    ["x"]= 259,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/wreckingball.png"]= {
                    ["x"]= 296,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Assassin.png"]= {
                    ["x"]= 333,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Berserker.png"]= {
                    ["x"]= 370,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Champion.png"]= {
                    ["x"]= 407,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Chieftain.png"]= {
                    ["x"]= 444,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Deadeye.png"]= {
                    ["x"]= 481,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Elementalist.png"]= {
                    ["x"]= 518,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Gladiator.png"]= {
                    ["x"]= 555,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Guardian.png"]= {
                    ["x"]= 592,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Hierophant.png"]= {
                    ["x"]= 629,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Inquisitor.png"]= {
                    ["x"]= 666,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Juggernaut.png"]= {
                    ["x"]= 703,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Necromancer.png"]= {
                    ["x"]= 740,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Occultist.png"]= {
                    ["x"]= 777,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Pathfinder.png"]= {
                    ["x"]= 814,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Raider.png"]= {
                    ["x"]= 851,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Saboteur.png"]= {
                    ["x"]= 888,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Slayer.png"]= {
                    ["x"]= 925,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Ascendants/Trickster.png"]= {
                    ["x"]= 962,
                    ["y"]= 1263,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Assassin/Ambush.png"]= {
                    ["x"]= 0,
                    ["y"]= 1300,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/Chieftain/TawhoaForestsStrength.png"]= {
                    ["x"]= 37,
                    ["y"]= 1300,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HinekoraPassiveIcon1.png"]= {
                    ["x"]= 74,
                    ["y"]= 1300,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HinekoraPassiveIcon2.png"]= {
                    ["x"]= 111,
                    ["y"]= 1300,
                    ["w"]= 37,
                    ["h"]= 37
                },
                ["Art/2DArt/SkillIcons/passives/HinekoraPassiveIcon3.png"]= {
                    ["x"]= 148,
                    ["y"]= 1300,
                    ["w"]= 37,
                    ["h"]= 37
                }
            }
        },
        ["keystoneInactive"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/skills-disabled-3.jpg?137cafd9",
            ["w"]= 999,
            ["h"]= 1496,
            ["coords"]= {
                ["Art/2DArt/SkillIcons/passives/AnointOnlyKeystone.png"]= {
                    ["x"]= 0,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/BrandKeystone.png"]= {
                    ["x"]= 52,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/CallToArms.png"]= {
                    ["x"]= 104,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/ColdPureElementalCasterKeystone.png"]= {
                    ["x"]= 156,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/CrimsonDance.png"]= {
                    ["x"]= 208,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/CritAilments.png"]= {
                    ["x"]= 260,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/Deaden.png"]= {
                    ["x"]= 312,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/DiscipleOfKitava.png"]= {
                    ["x"]= 364,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/DragonStyle.png"]= {
                    ["x"]= 416,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/EnergisedFortress.png"]= {
                    ["x"]= 468,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/EternalYouth.png"]= {
                    ["x"]= 520,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/FirePureElementalCasterKeystone.png"]= {
                    ["x"]= 572,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/GlancingBlows.png"]= {
                    ["x"]= 624,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/ImpaleKeystone.png"]= {
                    ["x"]= 676,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneAcrobatics.png"]= {
                    ["x"]= 728,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneArrowDodging.png"]= {
                    ["x"]= 780,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneAvatarOfFire.png"]= {
                    ["x"]= 832,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneBloodMagic.png"]= {
                    ["x"]= 884,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneChaosInoculation.png"]= {
                    ["x"]= 936,
                    ["y"]= 1337,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneConduit.png"]= {
                    ["x"]= 0,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneEldritchBattery.png"]= {
                    ["x"]= 52,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneElementalEquilibrium.png"]= {
                    ["x"]= 104,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneElementalOverload.png"]= {
                    ["x"]= 156,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneHexMaster.png"]= {
                    ["x"]= 208,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneIronGrip.png"]= {
                    ["x"]= 260,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneIronReflexes.png"]= {
                    ["x"]= 312,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneIronWill.png"]= {
                    ["x"]= 364,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneMinionInstability.png"]= {
                    ["x"]= 416,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneNecromanticAegis.png"]= {
                    ["x"]= 468,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystonePainAttunement.png"]= {
                    ["x"]= 520,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystonePointBlankArcher.png"]= {
                    ["x"]= 572,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneResoluteTechnique.png"]= {
                    ["x"]= 624,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/KeystoneUnwaveringStance.png"]= {
                    ["x"]= 676,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/Kineticism.png"]= {
                    ["x"]= 728,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/LightningPureElementalCasterKeystone.png"]= {
                    ["x"]= 780,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/LoneMessenger.png"]= {
                    ["x"]= 832,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/MiracleMaker.png"]= {
                    ["x"]= 884,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/MomentofRespite.png"]= {
                    ["x"]= 936,
                    ["y"]= 1390,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/NaturesPatience.png"]= {
                    ["x"]= 0,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/Occultist/EldrichBarrier.png"]= {
                    ["x"]= 52,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/Pitfighter.png"]= {
                    ["x"]= 104,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/PreciseTechnique.png"]= {
                    ["x"]= 156,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/Resilience.png"]= {
                    ["x"]= 208,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/RetaliationKeystone.png"]= {
                    ["x"]= 260,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/SacredBastionKeystone.png"]= {
                    ["x"]= 312,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/SecretOfAgony.png"]= {
                    ["x"]= 364,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/SupremeEgo.png"]= {
                    ["x"]= 416,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/TinctureKeystone1.png"]= {
                    ["x"]= 468,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/Trickster/AcrobaticWillpower.png"]= {
                    ["x"]= 520,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/VersatileCombatant.png"]= {
                    ["x"]= 572,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/VeteransAwareness.png"]= {
                    ["x"]= 624,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/WindDancer.png"]= {
                    ["x"]= 676,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/ghostreaver.png"]= {
                    ["x"]= 728,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/heroicspirit.png"]= {
                    ["x"]= 780,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/liferegentoenergyshield.png"]= {
                    ["x"]= 832,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/totemmax.png"]= {
                    ["x"]= 884,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                },
                ["Art/2DArt/SkillIcons/passives/vaalpact.png"]= {
                    ["x"]= 936,
                    ["y"]= 1443,
                    ["w"]= 52,
                    ["h"]= 53
                }
            }
        },
        ["mastery"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/mastery-3.png?c17e5660",
            ["w"]= 946,
            ["h"]= 946,
            ["coords"]= {
                ["Art/2DArt/SkillIcons/passives/AltAreaDamageMastery.png"]= {
                    ["x"]= 0,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltAttackDamageMastery.png"]= {
                    ["x"]= 86,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltBloodMastery.png"]= {
                    ["x"]= 172,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltChaosDamageMastery.png"]= {
                    ["x"]= 258,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltColdDamageMastery.png"]= {
                    ["x"]= 344,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltDaggerClawDamageMastery.png"]= {
                    ["x"]= 430,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltDamageOverTimeMultiplierMastery.png"]= {
                    ["x"]= 516,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltDamageWithHeraldMastery.png"]= {
                    ["x"]= 602,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltFireDamageMastery.png"]= {
                    ["x"]= 688,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryAuras.png"]= {
                    ["x"]= 774,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryBrand.png"]= {
                    ["x"]= 860,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryChannelling.png"]= {
                    ["x"]= 0,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryChaos.png"]= {
                    ["x"]= 86,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryCurse.png"]= {
                    ["x"]= 172,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryElementalDamage.png"]= {
                    ["x"]= 258,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryFlasks.png"]= {
                    ["x"]= 344,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryGroupBow.png"]= {
                    ["x"]= 430,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryGroupCast.png"]= {
                    ["x"]= 516,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryGroupCold.png"]= {
                    ["x"]= 602,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryGroupCrit.png"]= {
                    ["x"]= 688,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryGroupDualWield.png"]= {
                    ["x"]= 774,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryGroupFire.png"]= {
                    ["x"]= 860,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryGroupLightning.png"]= {
                    ["x"]= 0,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryGroupMaceAndStaff.png"]= {
                    ["x"]= 86,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryGroupMinions.png"]= {
                    ["x"]= 172,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryGroupShield.png"]= {
                    ["x"]= 258,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryGroupSwordAndAxe.png"]= {
                    ["x"]= 344,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryGroupTwoHands.png"]= {
                    ["x"]= 430,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryGroupWand.png"]= {
                    ["x"]= 516,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryPhysicalDamage.png"]= {
                    ["x"]= 602,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryProjectiles.png"]= {
                    ["x"]= 688,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryTotem.png"]= {
                    ["x"]= 774,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMasteryTraps.png"]= {
                    ["x"]= 860,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltMinionDamageHeraldMastery.png"]= {
                    ["x"]= 0,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltNonDamagingAilmentsMastery.png"]= {
                    ["x"]= 86,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AltWarcryMastery.png"]= {
                    ["x"]= 172,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AreaofEffectSpellsMastery.png"]= {
                    ["x"]= 258,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AttackBlindMastery.png"]= {
                    ["x"]= 344,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AttackTotemMastery.png"]= {
                    ["x"]= 430,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/BloodMastery.png"]= {
                    ["x"]= 516,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/EnduranceFrenzyChargeMastery.png"]= {
                    ["x"]= 602,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/FortifyMasterySymbol.png"]= {
                    ["x"]= 688,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/ImpaleMasterySymbol.png"]= {
                    ["x"]= 774,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MarkMastery.png"]= {
                    ["x"]= 860,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryAuras.png"]= {
                    ["x"]= 0,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryBrand.png"]= {
                    ["x"]= 86,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryChaos.png"]= {
                    ["x"]= 172,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryCurse.png"]= {
                    ["x"]= 258,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryDuration.png"]= {
                    ["x"]= 344,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryElementalDamage.png"]= {
                    ["x"]= 430,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryFlasks.png"]= {
                    ["x"]= 516,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupAccuracy.png"]= {
                    ["x"]= 602,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupArmour.png"]= {
                    ["x"]= 688,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupAxe.png"]= {
                    ["x"]= 774,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupBow.png"]= {
                    ["x"]= 860,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupClaw.png"]= {
                    ["x"]= 0,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupCold.png"]= {
                    ["x"]= 86,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupCrit.png"]= {
                    ["x"]= 172,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupDagger.png"]= {
                    ["x"]= 258,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupDualWield.png"]= {
                    ["x"]= 344,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupEnergyShield.png"]= {
                    ["x"]= 430,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupEnergyShieldMana.png"]= {
                    ["x"]= 516,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupEvasion.png"]= {
                    ["x"]= 602,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupFire.png"]= {
                    ["x"]= 688,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupLife.png"]= {
                    ["x"]= 774,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupLifeMana.png"]= {
                    ["x"]= 860,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupLightning.png"]= {
                    ["x"]= 0,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupMace.png"]= {
                    ["x"]= 86,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupMana.png"]= {
                    ["x"]= 172,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupMinions.png"]= {
                    ["x"]= 258,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupShield.png"]= {
                    ["x"]= 344,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupStaff.png"]= {
                    ["x"]= 430,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupSword.png"]= {
                    ["x"]= 516,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupTwoHands.png"]= {
                    ["x"]= 602,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryGroupWand.png"]= {
                    ["x"]= 688,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPhysicalDamage.png"]= {
                    ["x"]= 774,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPoison.png"]= {
                    ["x"]= 860,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryProjectiles.png"]= {
                    ["x"]= 0,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryRecovery.png"]= {
                    ["x"]= 86,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryTraps.png"]= {
                    ["x"]= 172,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MineMastery.png"]= {
                    ["x"]= 258,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MinionMastery.png"]= {
                    ["x"]= 344,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/PassiveStunMastery.png"]= {
                    ["x"]= 430,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/RageMastery.png"]= {
                    ["x"]= 516,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/WarcryMastery.png"]= {
                    ["x"]= 602,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon1.png"]= {
                    ["x"]= 688,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon2.png"]= {
                    ["x"]= 774,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon3.png"]= {
                    ["x"]= 860,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon4.png"]= {
                    ["x"]= 0,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon5.png"]= {
                    ["x"]= 86,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon6.png"]= {
                    ["x"]= 172,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon7.png"]= {
                    ["x"]= 258,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon8.png"]= {
                    ["x"]= 344,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon9.png"]= {
                    ["x"]= 430,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon10.png"]= {
                    ["x"]= 516,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon11.png"]= {
                    ["x"]= 602,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon12.png"]= {
                    ["x"]= 688,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon13.png"]= {
                    ["x"]= 774,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon14.png"]= {
                    ["x"]= 860,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon15.png"]= {
                    ["x"]= 0,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon16.png"]= {
                    ["x"]= 86,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon17.png"]= {
                    ["x"]= 172,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon18.png"]= {
                    ["x"]= 258,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon19.png"]= {
                    ["x"]= 344,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon20.png"]= {
                    ["x"]= 430,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon21.png"]= {
                    ["x"]= 516,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon22.png"]= {
                    ["x"]= 602,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon23.png"]= {
                    ["x"]= 688,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon24.png"]= {
                    ["x"]= 774,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon25.png"]= {
                    ["x"]= 860,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon26.png"]= {
                    ["x"]= 0,
                    ["y"]= 860,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon27.png"]= {
                    ["x"]= 86,
                    ["y"]= 860,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon29.png"]= {
                    ["x"]= 172,
                    ["y"]= 860,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon30.png"]= {
                    ["x"]= 258,
                    ["y"]= 860,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon31.png"]= {
                    ["x"]= 344,
                    ["y"]= 860,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon32.png"]= {
                    ["x"]= 430,
                    ["y"]= 860,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon33.png"]= {
                    ["x"]= 516,
                    ["y"]= 860,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon34.png"]= {
                    ["x"]= 602,
                    ["y"]= 860,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon36.png"]= {
                    ["x"]= 688,
                    ["y"]= 860,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon37.png"]= {
                    ["x"]= 774,
                    ["y"]= 860,
                    ["w"]= 86,
                    ["h"]= 86
                }
            }
        },
        ["masteryConnected"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/mastery-connected-3.png?96461b88",
            ["w"]= 860,
            ["h"]= 860,
            ["coords"]= {
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryAccuracyInactive.png"]= {
                    ["x"]= 0,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryArmourAndEnergyShieldInactive.png"]= {
                    ["x"]= 86,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryArmourAndEvasionInactive.png"]= {
                    ["x"]= 172,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryArmourInactive.png"]= {
                    ["x"]= 258,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryAttackInactive.png"]= {
                    ["x"]= 344,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryAttributesInactive.png"]= {
                    ["x"]= 430,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryAxeInactive.png"]= {
                    ["x"]= 516,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryBannerInactive.png"]= {
                    ["x"]= 602,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryBleedingInactive.png"]= {
                    ["x"]= 688,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryBlindInactive.png"]= {
                    ["x"]= 774,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryBlockInactive.png"]= {
                    ["x"]= 0,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryBowInactive.png"]= {
                    ["x"]= 86,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryBrandInactive.png"]= {
                    ["x"]= 172,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryCasterInactive.png"]= {
                    ["x"]= 258,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryChaosInactive.png"]= {
                    ["x"]= 344,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryChargesInactive.png"]= {
                    ["x"]= 430,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryClawsInactive.png"]= {
                    ["x"]= 516,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryColdInactive.png"]= {
                    ["x"]= 602,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryCriticalInactive.png"]= {
                    ["x"]= 688,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryCurseInactive.png"]= {
                    ["x"]= 774,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryDaggerInactive.png"]= {
                    ["x"]= 0,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryDamageOverTimeInactive.png"]= {
                    ["x"]= 86,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryDualWieldInactive.png"]= {
                    ["x"]= 172,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryDurationInactive.png"]= {
                    ["x"]= 258,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryElementalInactive.png"]= {
                    ["x"]= 344,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryEnergyInactive.png"]= {
                    ["x"]= 430,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryEvasionAndEnergyShieldInactive.png"]= {
                    ["x"]= 516,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryEvasionInactive.png"]= {
                    ["x"]= 602,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryFireInactive.png"]= {
                    ["x"]= 688,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryFlaskInactive.png"]= {
                    ["x"]= 774,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryFortifyInactive.png"]= {
                    ["x"]= 0,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryImpaleInactive.png"]= {
                    ["x"]= 86,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryLeechInactive.png"]= {
                    ["x"]= 172,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryLifeInactive.png"]= {
                    ["x"]= 258,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryLightningInactive.png"]= {
                    ["x"]= 344,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryLinkInactive.png"]= {
                    ["x"]= 430,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryMaceInactive.png"]= {
                    ["x"]= 516,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryManaInactive.png"]= {
                    ["x"]= 602,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryMarkInactive.png"]= {
                    ["x"]= 688,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryMineInactive.png"]= {
                    ["x"]= 774,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryMinionDefenseInactive.png"]= {
                    ["x"]= 0,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryMinionOffenseInactive.png"]= {
                    ["x"]= 86,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryPhysicalInactive.png"]= {
                    ["x"]= 172,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryPoisonInactive.png"]= {
                    ["x"]= 258,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryProjectileInactive.png"]= {
                    ["x"]= 344,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryRageInactive.png"]= {
                    ["x"]= 430,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryRecoveryInactive.png"]= {
                    ["x"]= 516,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryReservationInactive.png"]= {
                    ["x"]= 602,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryResistancesAndAilmentProtectionInactive.png"]= {
                    ["x"]= 688,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryRetaliationInactive.png"]= {
                    ["x"]= 774,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryShieldInactive.png"]= {
                    ["x"]= 0,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasterySpellSuppressionInactive.png"]= {
                    ["x"]= 86,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryStaffInactive.png"]= {
                    ["x"]= 172,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryStunInactive.png"]= {
                    ["x"]= 258,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasterySwordInactive.png"]= {
                    ["x"]= 344,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryTinctureInactive.png"]= {
                    ["x"]= 430,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryTotemInactive.png"]= {
                    ["x"]= 516,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryTrapInactive.png"]= {
                    ["x"]= 602,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryTwoHandInactive.png"]= {
                    ["x"]= 688,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryWandInactive.png"]= {
                    ["x"]= 774,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryWarcryInactive.png"]= {
                    ["x"]= 0,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon1.png"]= {
                    ["x"]= 86,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon2.png"]= {
                    ["x"]= 172,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon3.png"]= {
                    ["x"]= 258,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon4.png"]= {
                    ["x"]= 344,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon5.png"]= {
                    ["x"]= 430,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon6.png"]= {
                    ["x"]= 516,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon7.png"]= {
                    ["x"]= 602,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon8.png"]= {
                    ["x"]= 688,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon9.png"]= {
                    ["x"]= 774,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon10.png"]= {
                    ["x"]= 0,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon11.png"]= {
                    ["x"]= 86,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon12.png"]= {
                    ["x"]= 172,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon13.png"]= {
                    ["x"]= 258,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon14.png"]= {
                    ["x"]= 344,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon15.png"]= {
                    ["x"]= 430,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon16.png"]= {
                    ["x"]= 516,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon17.png"]= {
                    ["x"]= 602,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon18.png"]= {
                    ["x"]= 688,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon19.png"]= {
                    ["x"]= 774,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon20.png"]= {
                    ["x"]= 0,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon21.png"]= {
                    ["x"]= 86,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon22.png"]= {
                    ["x"]= 172,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon23.png"]= {
                    ["x"]= 258,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon24.png"]= {
                    ["x"]= 344,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon25.png"]= {
                    ["x"]= 430,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon26.png"]= {
                    ["x"]= 516,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon27.png"]= {
                    ["x"]= 602,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon29.png"]= {
                    ["x"]= 688,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon30.png"]= {
                    ["x"]= 774,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon31.png"]= {
                    ["x"]= 0,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon32.png"]= {
                    ["x"]= 86,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon33.png"]= {
                    ["x"]= 172,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon34.png"]= {
                    ["x"]= 258,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon36.png"]= {
                    ["x"]= 344,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon37.png"]= {
                    ["x"]= 430,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                }
            }
        },
        ["masteryActiveSelected"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/mastery-active-selected-3.png?27c631e2",
            ["w"]= 860,
            ["h"]= 860,
            ["coords"]= {
                ["PassiveMasteryConnectedButton"]= {
                    ["x"]= 0,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveBannerRageActive.png"]= {
                    ["x"]= 86,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveBannerStunActive.png"]= {
                    ["x"]= 172,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveBannerTinctureActive.png"]= {
                    ["x"]= 258,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryAccuracyActive.png"]= {
                    ["x"]= 344,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryArmourActive.png"]= {
                    ["x"]= 430,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryArmourAndEnergyShieldActive.png"]= {
                    ["x"]= 516,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryArmourAndEvasionActive.png"]= {
                    ["x"]= 602,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryAttackActive.png"]= {
                    ["x"]= 688,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryAttributesActive.png"]= {
                    ["x"]= 774,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryAxeActive.png"]= {
                    ["x"]= 0,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryBleedingActive.png"]= {
                    ["x"]= 86,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryBlindActive.png"]= {
                    ["x"]= 172,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryBlockActive.png"]= {
                    ["x"]= 258,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryBowActive.png"]= {
                    ["x"]= 344,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryBrandActive.png"]= {
                    ["x"]= 430,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryCasterActive.png"]= {
                    ["x"]= 516,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryChaosActive.png"]= {
                    ["x"]= 602,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryChargesActive.png"]= {
                    ["x"]= 688,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryClawsActive.png"]= {
                    ["x"]= 774,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryColdActive.png"]= {
                    ["x"]= 0,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryCriticalActive.png"]= {
                    ["x"]= 86,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryCurseActive.png"]= {
                    ["x"]= 172,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryDaggerActive.png"]= {
                    ["x"]= 258,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryDamageOverTimeActive.png"]= {
                    ["x"]= 344,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryDualWieldActive.png"]= {
                    ["x"]= 430,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryDurationActive.png"]= {
                    ["x"]= 516,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryElementalActive.png"]= {
                    ["x"]= 602,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryEnergyActive.png"]= {
                    ["x"]= 688,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryEvasionActive.png"]= {
                    ["x"]= 774,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryEvasionAndEnergyShieldActive.png"]= {
                    ["x"]= 0,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryFireActive.png"]= {
                    ["x"]= 86,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryFlaskActive.png"]= {
                    ["x"]= 172,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryFortifyActive.png"]= {
                    ["x"]= 258,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryImpaleActive.png"]= {
                    ["x"]= 344,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryLeechActive.png"]= {
                    ["x"]= 430,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryLifeActive.png"]= {
                    ["x"]= 516,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryLightningActive.png"]= {
                    ["x"]= 602,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryLinkActive.png"]= {
                    ["x"]= 688,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryMaceActive.png"]= {
                    ["x"]= 774,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryManaActive.png"]= {
                    ["x"]= 0,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryMarkActive.png"]= {
                    ["x"]= 86,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryMineActive.png"]= {
                    ["x"]= 172,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryMinionDefenseActive.png"]= {
                    ["x"]= 258,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryMinionOffenseActive.png"]= {
                    ["x"]= 344,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryPhysicalActive.png"]= {
                    ["x"]= 430,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryPoisonActive.png"]= {
                    ["x"]= 516,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryProjectileActive.png"]= {
                    ["x"]= 602,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryRecoveryActive.png"]= {
                    ["x"]= 688,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryReservationActive.png"]= {
                    ["x"]= 774,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryResistancesAndAilmentProtectionActive.png"]= {
                    ["x"]= 0,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryShieldActive.png"]= {
                    ["x"]= 86,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasterySpellSuppressionActive.png"]= {
                    ["x"]= 172,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryStaffActive.png"]= {
                    ["x"]= 258,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryStunActive.png"]= {
                    ["x"]= 344,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasterySwordActive.png"]= {
                    ["x"]= 430,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryTotemActive.png"]= {
                    ["x"]= 516,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryTrapActive.png"]= {
                    ["x"]= 602,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryTwoHandActive.png"]= {
                    ["x"]= 688,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryWandActive.png"]= {
                    ["x"]= 774,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryWarcryActive.png"]= {
                    ["x"]= 0,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveRetaliationActive.png"]= {
                    ["x"]= 86,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon1.png"]= {
                    ["x"]= 172,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon2.png"]= {
                    ["x"]= 258,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon3.png"]= {
                    ["x"]= 344,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon4.png"]= {
                    ["x"]= 430,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon5.png"]= {
                    ["x"]= 516,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon6.png"]= {
                    ["x"]= 602,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon7.png"]= {
                    ["x"]= 688,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon8.png"]= {
                    ["x"]= 774,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon9.png"]= {
                    ["x"]= 0,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon10.png"]= {
                    ["x"]= 86,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon11.png"]= {
                    ["x"]= 172,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon12.png"]= {
                    ["x"]= 258,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon13.png"]= {
                    ["x"]= 344,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon14.png"]= {
                    ["x"]= 430,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon15.png"]= {
                    ["x"]= 516,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon16.png"]= {
                    ["x"]= 602,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon17.png"]= {
                    ["x"]= 688,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon18.png"]= {
                    ["x"]= 774,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon19.png"]= {
                    ["x"]= 0,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon20.png"]= {
                    ["x"]= 86,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon21.png"]= {
                    ["x"]= 172,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon22.png"]= {
                    ["x"]= 258,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon23.png"]= {
                    ["x"]= 344,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon24.png"]= {
                    ["x"]= 430,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon25.png"]= {
                    ["x"]= 516,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon26.png"]= {
                    ["x"]= 602,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon27.png"]= {
                    ["x"]= 688,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon29.png"]= {
                    ["x"]= 774,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon30.png"]= {
                    ["x"]= 0,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon31.png"]= {
                    ["x"]= 86,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon32.png"]= {
                    ["x"]= 172,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon33.png"]= {
                    ["x"]= 258,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon34.png"]= {
                    ["x"]= 344,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon36.png"]= {
                    ["x"]= 430,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon37.png"]= {
                    ["x"]= 516,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                }
            }
        },
        ["masteryInactive"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/mastery-disabled-3.png?a60c53c5",
            ["w"]= 860,
            ["h"]= 860,
            ["coords"]= {
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryAccuracyInactive.png"]= {
                    ["x"]= 0,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryArmourAndEnergyShieldInactive.png"]= {
                    ["x"]= 86,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryArmourAndEvasionInactive.png"]= {
                    ["x"]= 172,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryArmourInactive.png"]= {
                    ["x"]= 258,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryAttackInactive.png"]= {
                    ["x"]= 344,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryAttributesInactive.png"]= {
                    ["x"]= 430,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryAxeInactive.png"]= {
                    ["x"]= 516,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryBannerInactive.png"]= {
                    ["x"]= 602,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryBleedingInactive.png"]= {
                    ["x"]= 688,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryBlindInactive.png"]= {
                    ["x"]= 774,
                    ["y"]= 0,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryBlockInactive.png"]= {
                    ["x"]= 0,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryBowInactive.png"]= {
                    ["x"]= 86,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryBrandInactive.png"]= {
                    ["x"]= 172,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryCasterInactive.png"]= {
                    ["x"]= 258,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryChaosInactive.png"]= {
                    ["x"]= 344,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryChargesInactive.png"]= {
                    ["x"]= 430,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryClawsInactive.png"]= {
                    ["x"]= 516,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryColdInactive.png"]= {
                    ["x"]= 602,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryCriticalInactive.png"]= {
                    ["x"]= 688,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryCurseInactive.png"]= {
                    ["x"]= 774,
                    ["y"]= 86,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryDaggerInactive.png"]= {
                    ["x"]= 0,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryDamageOverTimeInactive.png"]= {
                    ["x"]= 86,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryDualWieldInactive.png"]= {
                    ["x"]= 172,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryDurationInactive.png"]= {
                    ["x"]= 258,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryElementalInactive.png"]= {
                    ["x"]= 344,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryEnergyInactive.png"]= {
                    ["x"]= 430,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryEvasionAndEnergyShieldInactive.png"]= {
                    ["x"]= 516,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryEvasionInactive.png"]= {
                    ["x"]= 602,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryFireInactive.png"]= {
                    ["x"]= 688,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryFlaskInactive.png"]= {
                    ["x"]= 774,
                    ["y"]= 172,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryFortifyInactive.png"]= {
                    ["x"]= 0,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryImpaleInactive.png"]= {
                    ["x"]= 86,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryLeechInactive.png"]= {
                    ["x"]= 172,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryLifeInactive.png"]= {
                    ["x"]= 258,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryLightningInactive.png"]= {
                    ["x"]= 344,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryLinkInactive.png"]= {
                    ["x"]= 430,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryMaceInactive.png"]= {
                    ["x"]= 516,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryManaInactive.png"]= {
                    ["x"]= 602,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryMarkInactive.png"]= {
                    ["x"]= 688,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryMineInactive.png"]= {
                    ["x"]= 774,
                    ["y"]= 258,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryMinionDefenseInactive.png"]= {
                    ["x"]= 0,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryMinionOffenseInactive.png"]= {
                    ["x"]= 86,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryPhysicalInactive.png"]= {
                    ["x"]= 172,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryPoisonInactive.png"]= {
                    ["x"]= 258,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryProjectileInactive.png"]= {
                    ["x"]= 344,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryRageInactive.png"]= {
                    ["x"]= 430,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryRecoveryInactive.png"]= {
                    ["x"]= 516,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryReservationInactive.png"]= {
                    ["x"]= 602,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryResistancesAndAilmentProtectionInactive.png"]= {
                    ["x"]= 688,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryRetaliationInactive.png"]= {
                    ["x"]= 774,
                    ["y"]= 344,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryShieldInactive.png"]= {
                    ["x"]= 0,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasterySpellSuppressionInactive.png"]= {
                    ["x"]= 86,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryStaffInactive.png"]= {
                    ["x"]= 172,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryStunInactive.png"]= {
                    ["x"]= 258,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasterySwordInactive.png"]= {
                    ["x"]= 344,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryTinctureInactive.png"]= {
                    ["x"]= 430,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryTotemInactive.png"]= {
                    ["x"]= 516,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryTrapInactive.png"]= {
                    ["x"]= 602,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryTwoHandInactive.png"]= {
                    ["x"]= 688,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryWandInactive.png"]= {
                    ["x"]= 774,
                    ["y"]= 430,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/MasteryPassiveIcons/PassiveMasteryWarcryInactive.png"]= {
                    ["x"]= 0,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon1.png"]= {
                    ["x"]= 86,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon2.png"]= {
                    ["x"]= 172,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon3.png"]= {
                    ["x"]= 258,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon4.png"]= {
                    ["x"]= 344,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon5.png"]= {
                    ["x"]= 430,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon6.png"]= {
                    ["x"]= 516,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon7.png"]= {
                    ["x"]= 602,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon8.png"]= {
                    ["x"]= 688,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon9.png"]= {
                    ["x"]= 774,
                    ["y"]= 516,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon10.png"]= {
                    ["x"]= 0,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon11.png"]= {
                    ["x"]= 86,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon12.png"]= {
                    ["x"]= 172,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon13.png"]= {
                    ["x"]= 258,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon14.png"]= {
                    ["x"]= 344,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon15.png"]= {
                    ["x"]= 430,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon16.png"]= {
                    ["x"]= 516,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon17.png"]= {
                    ["x"]= 602,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon18.png"]= {
                    ["x"]= 688,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon19.png"]= {
                    ["x"]= 774,
                    ["y"]= 602,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon20.png"]= {
                    ["x"]= 0,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon21.png"]= {
                    ["x"]= 86,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon22.png"]= {
                    ["x"]= 172,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon23.png"]= {
                    ["x"]= 258,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon24.png"]= {
                    ["x"]= 344,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon25.png"]= {
                    ["x"]= 430,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon26.png"]= {
                    ["x"]= 516,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon27.png"]= {
                    ["x"]= 602,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon29.png"]= {
                    ["x"]= 688,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon30.png"]= {
                    ["x"]= 774,
                    ["y"]= 688,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon31.png"]= {
                    ["x"]= 0,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon32.png"]= {
                    ["x"]= 86,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon33.png"]= {
                    ["x"]= 172,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon34.png"]= {
                    ["x"]= 258,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon36.png"]= {
                    ["x"]= 344,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                },
                ["Art/2DArt/SkillIcons/passives/AtlasTrees/RuneGraftingIcon37.png"]= {
                    ["x"]= 430,
                    ["y"]= 774,
                    ["w"]= 86,
                    ["h"]= 86
                }
            }
        },
        ["masteryActiveEffect"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/mastery-active-effect-3.png?0200e81a",
            ["w"]= 2376,
            ["h"]= 2352,
            ["coords"]= {
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryAccuracyPattern.png"]= {
                    ["x"]= 0,
                    ["y"]= 0,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryArmourAndEnergyShieldPattern.png"]= {
                    ["x"]= 297,
                    ["y"]= 0,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryArmourAndEvasionPattern.png"]= {
                    ["x"]= 594,
                    ["y"]= 0,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryArmourPattern.png"]= {
                    ["x"]= 891,
                    ["y"]= 0,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryAttackPattern.png"]= {
                    ["x"]= 1188,
                    ["y"]= 0,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryAttributesPattern.png"]= {
                    ["x"]= 1485,
                    ["y"]= 0,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryAxePattern.png"]= {
                    ["x"]= 1782,
                    ["y"]= 0,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryBannerPattern.png"]= {
                    ["x"]= 2079,
                    ["y"]= 0,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryBleedingPattern.png"]= {
                    ["x"]= 0,
                    ["y"]= 294,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryBlindPattern.png"]= {
                    ["x"]= 297,
                    ["y"]= 294,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryBlockPattern.png"]= {
                    ["x"]= 594,
                    ["y"]= 294,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryBowPattern.png"]= {
                    ["x"]= 891,
                    ["y"]= 294,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryBrandPattern.png"]= {
                    ["x"]= 1188,
                    ["y"]= 294,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryCasterPattern.png"]= {
                    ["x"]= 1485,
                    ["y"]= 294,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryChaosPattern.png"]= {
                    ["x"]= 1782,
                    ["y"]= 294,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryChargesPattern.png"]= {
                    ["x"]= 2079,
                    ["y"]= 294,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryClawsPattern.png"]= {
                    ["x"]= 0,
                    ["y"]= 588,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryColdPattern.png"]= {
                    ["x"]= 297,
                    ["y"]= 588,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryCriticalsPattern.png"]= {
                    ["x"]= 594,
                    ["y"]= 588,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryCursePattern.png"]= {
                    ["x"]= 891,
                    ["y"]= 588,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryDaggersPattern.png"]= {
                    ["x"]= 1188,
                    ["y"]= 588,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryDamageOverTimePattern.png"]= {
                    ["x"]= 1485,
                    ["y"]= 588,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryDualWieldPattern.png"]= {
                    ["x"]= 1782,
                    ["y"]= 588,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryDurationPattern.png"]= {
                    ["x"]= 2079,
                    ["y"]= 588,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryElementalPattern.png"]= {
                    ["x"]= 0,
                    ["y"]= 882,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryEnergyPattern.png"]= {
                    ["x"]= 297,
                    ["y"]= 882,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryEvasionAndEnergyShieldPattern.png"]= {
                    ["x"]= 594,
                    ["y"]= 882,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryEvasionPattern.png"]= {
                    ["x"]= 891,
                    ["y"]= 882,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryFirePattern.png"]= {
                    ["x"]= 1188,
                    ["y"]= 882,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryFlaskPattern.png"]= {
                    ["x"]= 1485,
                    ["y"]= 882,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryFortifyPattern.png"]= {
                    ["x"]= 1782,
                    ["y"]= 882,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryImpalePattern.png"]= {
                    ["x"]= 2079,
                    ["y"]= 882,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryLeechPattern.png"]= {
                    ["x"]= 0,
                    ["y"]= 1176,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryLifePattern.png"]= {
                    ["x"]= 297,
                    ["y"]= 1176,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryLightningPattern.png"]= {
                    ["x"]= 594,
                    ["y"]= 1176,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryLinkPattern.png"]= {
                    ["x"]= 891,
                    ["y"]= 1176,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryMacePattern.png"]= {
                    ["x"]= 1188,
                    ["y"]= 1176,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryManaPattern.png"]= {
                    ["x"]= 1485,
                    ["y"]= 1176,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryMarkPattern.png"]= {
                    ["x"]= 1782,
                    ["y"]= 1176,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryMinePattern.png"]= {
                    ["x"]= 2079,
                    ["y"]= 1176,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryMinionDefencePattern.png"]= {
                    ["x"]= 0,
                    ["y"]= 1470,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryMinionOffencePattern.png"]= {
                    ["x"]= 297,
                    ["y"]= 1470,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryPhysicalPattern.png"]= {
                    ["x"]= 594,
                    ["y"]= 1470,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryPoisonPattern.png"]= {
                    ["x"]= 891,
                    ["y"]= 1470,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryProjectilePattern.png"]= {
                    ["x"]= 1188,
                    ["y"]= 1470,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryRagePattern.png"]= {
                    ["x"]= 1485,
                    ["y"]= 1470,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryRecoveryPattern.png"]= {
                    ["x"]= 1782,
                    ["y"]= 1470,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryReservationPattern.png"]= {
                    ["x"]= 2079,
                    ["y"]= 1470,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryResistancesAndAilmentProtectionPattern.png"]= {
                    ["x"]= 0,
                    ["y"]= 1764,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryRetaliationPattern.png"]= {
                    ["x"]= 297,
                    ["y"]= 1764,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryShieldPattern.png"]= {
                    ["x"]= 594,
                    ["y"]= 1764,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasterySpellSuppressionPattern.png"]= {
                    ["x"]= 891,
                    ["y"]= 1764,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryStaffPattern.png"]= {
                    ["x"]= 1188,
                    ["y"]= 1764,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryStunPattern.png"]= {
                    ["x"]= 1485,
                    ["y"]= 1764,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasterySwordPattern.png"]= {
                    ["x"]= 1782,
                    ["y"]= 1764,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryTincturePattern.png"]= {
                    ["x"]= 2079,
                    ["y"]= 1764,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryTotemPattern.png"]= {
                    ["x"]= 0,
                    ["y"]= 2058,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryTrapsPattern.png"]= {
                    ["x"]= 297,
                    ["y"]= 2058,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryTwoHandsPattern.png"]= {
                    ["x"]= 594,
                    ["y"]= 2058,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryWandPattern.png"]= {
                    ["x"]= 891,
                    ["y"]= 2058,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/PassiveMastery/MasteryBackgroundGraphic/MasteryWarcryPattern.png"]= {
                    ["x"]= 1188,
                    ["y"]= 2058,
                    ["w"]= 297,
                    ["h"]= 294
                },
                ["Art/2DArt/UIImages/InGame/Village/RuneCraftingPassiveBG.png"]= {
                    ["x"]= 1485,
                    ["y"]= 2058,
                    ["w"]= 297,
                    ["h"]= 294
                }
            }
        },
        ["tattooActiveEffect"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/tattoo-active-effect-3.png?34fa8683",
            ["w"]= 576,
            ["h"]= 704,
            ["coords"]= {
                ["Art/2DArt/UIImages/InGame/AncestralTrial/PassiveTreeTattoos/ArohonguiTribePassiveBG.png"]= {
                    ["x"]= 0,
                    ["y"]= 0,
                    ["w"]= 139,
                    ["h"]= 138
                },
                ["Art/2DArt/UIImages/InGame/AncestralTrial/PassiveTreeTattoos/HinekoraPassiveBG.png"]= {
                    ["x"]= {
                        139,
                        0
                    },
                    ["y"]= {
                        0,
                        414
                    },
                    ["w"]= {
                        139,
                        288
                    },
                    ["h"]= {
                        138,
                        290
                    }
                },
                ["Art/2DArt/UIImages/InGame/AncestralTrial/PassiveTreeTattoos/HinekoraTribePassiveBG.png"]= {
                    ["x"]= 278,
                    ["y"]= 0,
                    ["w"]= 139,
                    ["h"]= 138
                },
                ["Art/2DArt/UIImages/InGame/AncestralTrial/PassiveTreeTattoos/KitavaTribePassiveBG.png"]= {
                    ["x"]= 417,
                    ["y"]= 0,
                    ["w"]= 139,
                    ["h"]= 138
                },
                ["Art/2DArt/UIImages/InGame/AncestralTrial/PassiveTreeTattoos/NgamahuTribePassiveBG.png"]= {
                    ["x"]= 0,
                    ["y"]= 138,
                    ["w"]= 139,
                    ["h"]= 138
                },
                ["Art/2DArt/UIImages/InGame/AncestralTrial/PassiveTreeTattoos/RamakoTribePassiveBG.png"]= {
                    ["x"]= 139,
                    ["y"]= 138,
                    ["w"]= 139,
                    ["h"]= 138
                },
                ["Art/2DArt/UIImages/InGame/AncestralTrial/PassiveTreeTattoos/RongokuraiTribePassiveBG.png"]= {
                    ["x"]= 278,
                    ["y"]= 138,
                    ["w"]= 139,
                    ["h"]= 138
                },
                ["Art/2DArt/UIImages/InGame/AncestralTrial/PassiveTreeTattoos/TasalioTribePassiveBG.png"]= {
                    ["x"]= 417,
                    ["y"]= 138,
                    ["w"]= 139,
                    ["h"]= 138
                },
                ["Art/2DArt/UIImages/InGame/AncestralTrial/PassiveTreeTattoos/TawhoaTribePassiveBG.png"]= {
                    ["x"]= 0,
                    ["y"]= 276,
                    ["w"]= 139,
                    ["h"]= 138
                },
                ["Art/2DArt/UIImages/InGame/AncestralTrial/PassiveTreeTattoos/TukohamaTribePassiveBG.png"]= {
                    ["x"]= 139,
                    ["y"]= 276,
                    ["w"]= 139,
                    ["h"]= 138
                },
                ["Art/2DArt/UIImages/InGame/AncestralTrial/PassiveTreeTattoos/ValakoTribePassiveBG.png"]= {
                    ["x"]= 278,
                    ["y"]= 276,
                    ["w"]= 139,
                    ["h"]= 138
                },
                ["Art/2DArt/UIImages/InGame/Village/RuneCraftingPassiveBG.png"]= {
                    ["x"]= 417,
                    ["y"]= 276,
                    ["w"]= 139,
                    ["h"]= 138
                },
                ["Art/2DArt/UIImages/InGame/AncestralTrial/PassiveTreeTattoos/KeystoneHinekoraPassiveBG.png"]= {
                    ["x"]= 288,
                    ["y"]= 414,
                    ["w"]= 288,
                    ["h"]= 290
                }
            }
        },
        ["ascendancy"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/ascendancy-3.webp?b2dbca88",
            ["w"]= 2668,
            ["h"]= 2668,
            ["coords"]= {
                ["ClassesReliquarian"]= {
                    ["x"]= 0,
                    ["y"]= 0,
                    ["w"]= 587,
                    ["h"]= 587
                },
                ["ClassesLuminary"]= {
                    ["x"]= 587,
                    ["y"]= 0,
                    ["w"]= 587,
                    ["h"]= 587
                },
                ["ClassesAscendant"]= {
                    ["x"]= 0,
                    ["y"]= 587,
                    ["w"]= 587,
                    ["h"]= 587
                },
                ["ClassesTrickster"]= {
                    ["x"]= 587,
                    ["y"]= 587,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesSlayer"]= {
                    ["x"]= 1174,
                    ["y"]= 0,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesSaboteur"]= {
                    ["x"]= 1174,
                    ["y"]= 498,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesRaider"]= {
                    ["x"]= 0,
                    ["y"]= 1174,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesPathfinder"]= {
                    ["x"]= 498,
                    ["y"]= 1174,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesOccultist"]= {
                    ["x"]= 996,
                    ["y"]= 1174,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesNecromancer"]= {
                    ["x"]= 1672,
                    ["y"]= 0,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesJuggernaut"]= {
                    ["x"]= 1672,
                    ["y"]= 498,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesInquisitor"]= {
                    ["x"]= 1672,
                    ["y"]= 996,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesHierophant"]= {
                    ["x"]= 0,
                    ["y"]= 1672,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesGuardian"]= {
                    ["x"]= 498,
                    ["y"]= 1672,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesGladiator"]= {
                    ["x"]= 996,
                    ["y"]= 1672,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesElementalist"]= {
                    ["x"]= 1494,
                    ["y"]= 1672,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesDeadeye"]= {
                    ["x"]= 2170,
                    ["y"]= 0,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesChieftain"]= {
                    ["x"]= 2170,
                    ["y"]= 498,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesChampion"]= {
                    ["x"]= 2170,
                    ["y"]= 996,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesBerserker"]= {
                    ["x"]= 2170,
                    ["y"]= 1494,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesAssassin"]= {
                    ["x"]= 0,
                    ["y"]= 2170,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["ClassesAlternate"]= {
                    ["x"]= 498,
                    ["y"]= 2170,
                    ["w"]= 498,
                    ["h"]= 498
                },
                ["AscendancyButtonPressed"]= {
                    ["x"]= 2170,
                    ["y"]= 1992,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButtonHighlight"]= {
                    ["x"]= 2258,
                    ["y"]= 1992,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButton"]= {
                    ["x"]= 2346,
                    ["y"]= 1992,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyFrameLargeNormal"]= {
                    ["x"]= 2170,
                    ["y"]= 2049,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["AscendancyFrameLargeCanAllocate"]= {
                    ["x"]= 2228,
                    ["y"]= 2049,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["AscendancyFrameLargeAllocated"]= {
                    ["x"]= 2286,
                    ["y"]= 2049,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["AscendancyFrameSmallNormal"]= {
                    ["x"]= 2434,
                    ["y"]= 1992,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallCanAllocate"]= {
                    ["x"]= 2473,
                    ["y"]= 1992,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallAllocated"]= {
                    ["x"]= 2512,
                    ["y"]= 1992,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyMiddle"]= {
                    ["x"]= 2551,
                    ["y"]= 1992,
                    ["w"]= 31,
                    ["h"]= 31
                }
            }
        },
        ["azmeriBloodline"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/bloodline-3.webp?c89491a1",
            ["w"]= 2329,
            ["h"]= 2329,
            ["coords"]= {
                ["ClassesWarlock"]= {
                    ["x"]= 0,
                    ["y"]= 0,
                    ["w"]= 567,
                    ["h"]= 537
                },
                ["ClassesWarden"]= {
                    ["x"]= 567,
                    ["y"]= 0,
                    ["w"]= 567,
                    ["h"]= 537
                },
                ["ClassesPrimalist"]= {
                    ["x"]= 567,
                    ["y"]= 537,
                    ["w"]= 567,
                    ["h"]= 537
                },
                ["AscendancyButtonPressed"]= {
                    ["x"]= 0,
                    ["y"]= 2148,
                    ["w"]= 151,
                    ["h"]= 63
                },
                ["AscendancyButtonHighlight"]= {
                    ["x"]= 151,
                    ["y"]= 2148,
                    ["w"]= 151,
                    ["h"]= 63
                },
                ["AscendancyButton"]= {
                    ["x"]= 302,
                    ["y"]= 2148,
                    ["w"]= 151,
                    ["h"]= 63
                },
                ["AscendancyFrameLargeNormal"]= {
                    ["x"]= 2268,
                    ["y"]= 0,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeCanAllocate"]= {
                    ["x"]= 2268,
                    ["y"]= 854,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeAllocated"]= {
                    ["x"]= 2268,
                    ["y"]= 1708,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["CharmSocketActiveStr"]= {
                    ["x"]= 305,
                    ["y"]= 2268,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["CharmSocketActiveInt"]= {
                    ["x"]= 363,
                    ["y"]= 2268,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["CharmSocketActiveDex"]= {
                    ["x"]= 421,
                    ["y"]= 2268,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["CharmFrameNormal"]= {
                    ["x"]= 479,
                    ["y"]= 2268,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["CharmFrameCanAllocate"]= {
                    ["x"]= 537,
                    ["y"]= 2268,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["CharmFrameAllocated"]= {
                    ["x"]= 595,
                    ["y"]= 2268,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["AscendancyFrameSmallNormal"]= {
                    ["x"]= 2213,
                    ["y"]= 2148,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallCanAllocate"]= {
                    ["x"]= 2179,
                    ["y"]= 2211,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallAllocated"]= {
                    ["x"]= 1121,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyMiddle"]= {
                    ["x"]= 1667,
                    ["y"]= 2268,
                    ["w"]= 31,
                    ["h"]= 31
                }
            }
        },
        ["trialmasterBloodline"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/bloodline-3.webp?c89491a1",
            ["w"]= 2329,
            ["h"]= 2329,
            ["coords"]= {
                ["ClassesTrialmaster"]= {
                    ["x"]= 0,
                    ["y"]= 537,
                    ["w"]= 567,
                    ["h"]= 537
                },
                ["AscendancyButtonPressed"]= {
                    ["x"]= 453,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButtonHighlight"]= {
                    ["x"]= 1597,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButton"]= {
                    ["x"]= 528,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyFrameLargeNormal"]= {
                    ["x"]= 2268,
                    ["y"]= 61,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeCanAllocate"]= {
                    ["x"]= 2268,
                    ["y"]= 915,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeAllocated"]= {
                    ["x"]= 2268,
                    ["y"]= 1769,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameSmallNormal"]= {
                    ["x"]= 1672,
                    ["y"]= 2211,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallCanAllocate"]= {
                    ["x"]= 2218,
                    ["y"]= 2211,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallAllocated"]= {
                    ["x"]= 1160,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyMiddle"]= {
                    ["x"]= 1698,
                    ["y"]= 2268,
                    ["w"]= 31,
                    ["h"]= 31
                }
            }
        },
        ["oshabiBloodline"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/bloodline-3.webp?c89491a1",
            ["w"]= 2329,
            ["h"]= 2329,
            ["coords"]= {
                ["ClassesOshabi"]= {
                    ["x"]= 1134,
                    ["y"]= 0,
                    ["w"]= 567,
                    ["h"]= 537
                },
                ["AscendancyButtonPressed"]= {
                    ["x"]= 541,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButtonHighlight"]= {
                    ["x"]= 1685,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButton"]= {
                    ["x"]= 616,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyFrameLargeNormal"]= {
                    ["x"]= 2268,
                    ["y"]= 122,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeCanAllocate"]= {
                    ["x"]= 2268,
                    ["y"]= 976,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeAllocated"]= {
                    ["x"]= 2268,
                    ["y"]= 1830,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameSmallNormal"]= {
                    ["x"]= 1711,
                    ["y"]= 2211,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallCanAllocate"]= {
                    ["x"]= 653,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallAllocated"]= {
                    ["x"]= 1199,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyMiddle"]= {
                    ["x"]= 1729,
                    ["y"]= 2268,
                    ["w"]= 31,
                    ["h"]= 31
                }
            }
        },
        ["olrothBloodline"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/bloodline-3.webp?c89491a1",
            ["w"]= 2329,
            ["h"]= 2329,
            ["coords"]= {
                ["ClassesOlroth"]= {
                    ["x"]= 1134,
                    ["y"]= 537,
                    ["w"]= 567,
                    ["h"]= 537
                },
                ["AscendancyButtonPressed"]= {
                    ["x"]= 981,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButtonHighlight"]= {
                    ["x"]= 2125,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButton"]= {
                    ["x"]= 1056,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyFrameLargeNormal"]= {
                    ["x"]= 2268,
                    ["y"]= 427,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeCanAllocate"]= {
                    ["x"]= 2268,
                    ["y"]= 1281,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeAllocated"]= {
                    ["x"]= 2268,
                    ["y"]= 2135,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameSmallNormal"]= {
                    ["x"]= 1906,
                    ["y"]= 2211,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallCanAllocate"]= {
                    ["x"]= 848,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallAllocated"]= {
                    ["x"]= 1394,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyMiddle"]= {
                    ["x"]= 1884,
                    ["y"]= 2268,
                    ["w"]= 31,
                    ["h"]= 31
                }
            }
        },
        ["necromanticBloodline"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/bloodline-3.webp?c89491a1",
            ["w"]= 2329,
            ["h"]= 2329,
            ["coords"]= {
                ["ClassesNecromantic"]= {
                    ["x"]= 0,
                    ["y"]= 1074,
                    ["w"]= 567,
                    ["h"]= 537
                },
                ["AscendancyButtonPressed"]= {
                    ["x"]= 1333,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButtonHighlight"]= {
                    ["x"]= 264,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButton"]= {
                    ["x"]= 1408,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyFrameLargeNormal"]= {
                    ["x"]= 2268,
                    ["y"]= 671,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeCanAllocate"]= {
                    ["x"]= 2268,
                    ["y"]= 1525,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeAllocated"]= {
                    ["x"]= 122,
                    ["y"]= 2268,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameSmallNormal"]= {
                    ["x"]= 2062,
                    ["y"]= 2211,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallCanAllocate"]= {
                    ["x"]= 1004,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallAllocated"]= {
                    ["x"]= 1550,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyMiddle"]= {
                    ["x"]= 2008,
                    ["y"]= 2268,
                    ["w"]= 31,
                    ["h"]= 31
                }
            }
        },
        ["lyciaBloodline"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/bloodline-3.webp?c89491a1",
            ["w"]= 2329,
            ["h"]= 2329,
            ["coords"]= {
                ["ClassesLycia"]= {
                    ["x"]= 567,
                    ["y"]= 1074,
                    ["w"]= 567,
                    ["h"]= 537
                },
                ["AscendancyButtonPressed"]= {
                    ["x"]= 893,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButtonHighlight"]= {
                    ["x"]= 2037,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButton"]= {
                    ["x"]= 968,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyFrameLargeNormal"]= {
                    ["x"]= 2268,
                    ["y"]= 366,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeCanAllocate"]= {
                    ["x"]= 2268,
                    ["y"]= 1220,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeAllocated"]= {
                    ["x"]= 2268,
                    ["y"]= 2074,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameSmallNormal"]= {
                    ["x"]= 1867,
                    ["y"]= 2211,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallCanAllocate"]= {
                    ["x"]= 809,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallAllocated"]= {
                    ["x"]= 1355,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyMiddle"]= {
                    ["x"]= 1853,
                    ["y"]= 2268,
                    ["w"]= 31,
                    ["h"]= 31
                }
            }
        },
        ["kingInTheMistsBloodline"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/bloodline-3.webp?c89491a1",
            ["w"]= 2329,
            ["h"]= 2329,
            ["coords"]= {
                ["ClassesKingInTheMists"]= {
                    ["x"]= 1134,
                    ["y"]= 1074,
                    ["w"]= 567,
                    ["h"]= 537
                },
                ["AscendancyButtonPressed"]= {
                    ["x"]= 629,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButtonHighlight"]= {
                    ["x"]= 1773,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButton"]= {
                    ["x"]= 704,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyFrameLargeNormal"]= {
                    ["x"]= 2268,
                    ["y"]= 183,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeCanAllocate"]= {
                    ["x"]= 2268,
                    ["y"]= 1037,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeAllocated"]= {
                    ["x"]= 2268,
                    ["y"]= 1891,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameSmallNormal"]= {
                    ["x"]= 1750,
                    ["y"]= 2211,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallCanAllocate"]= {
                    ["x"]= 692,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallAllocated"]= {
                    ["x"]= 1238,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyMiddle"]= {
                    ["x"]= 1760,
                    ["y"]= 2268,
                    ["w"]= 31,
                    ["h"]= 31
                }
            }
        },
        ["farrulBloodline"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/bloodline-3.webp?c89491a1",
            ["w"]= 2329,
            ["h"]= 2329,
            ["coords"]= {
                ["ClassesFarrul"]= {
                    ["x"]= 1701,
                    ["y"]= 0,
                    ["w"]= 567,
                    ["h"]= 537
                },
                ["AscendancyButtonPressed"]= {
                    ["x"]= 1069,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButtonHighlight"]= {
                    ["x"]= 0,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButton"]= {
                    ["x"]= 1144,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyFrameLargeNormal"]= {
                    ["x"]= 2268,
                    ["y"]= 488,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeCanAllocate"]= {
                    ["x"]= 2268,
                    ["y"]= 1342,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeAllocated"]= {
                    ["x"]= 2268,
                    ["y"]= 2196,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameSmallNormal"]= {
                    ["x"]= 1945,
                    ["y"]= 2211,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallCanAllocate"]= {
                    ["x"]= 887,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallAllocated"]= {
                    ["x"]= 1433,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyMiddle"]= {
                    ["x"]= 1915,
                    ["y"]= 2268,
                    ["w"]= 31,
                    ["h"]= 31
                }
            }
        },
        ["deliriousBloodline"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/bloodline-3.webp?c89491a1",
            ["w"]= 2329,
            ["h"]= 2329,
            ["coords"]= {
                ["ClassesDelirious"]= {
                    ["x"]= 1701,
                    ["y"]= 537,
                    ["w"]= 567,
                    ["h"]= 537
                },
                ["AscendancyButtonPressed"]= {
                    ["x"]= 1157,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButtonHighlight"]= {
                    ["x"]= 88,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButton"]= {
                    ["x"]= 1232,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyFrameLargeNormal"]= {
                    ["x"]= 2268,
                    ["y"]= 549,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeCanAllocate"]= {
                    ["x"]= 2268,
                    ["y"]= 1403,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeAllocated"]= {
                    ["x"]= 0,
                    ["y"]= 2268,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameSmallNormal"]= {
                    ["x"]= 1984,
                    ["y"]= 2211,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallCanAllocate"]= {
                    ["x"]= 926,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallAllocated"]= {
                    ["x"]= 1472,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyMiddle"]= {
                    ["x"]= 1946,
                    ["y"]= 2268,
                    ["w"]= 31,
                    ["h"]= 31
                }
            }
        },
        ["catarinaBloodline"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/bloodline-3.webp?c89491a1",
            ["w"]= 2329,
            ["h"]= 2329,
            ["coords"]= {
                ["ClassesCatarina"]= {
                    ["x"]= 1701,
                    ["y"]= 1074,
                    ["w"]= 567,
                    ["h"]= 537
                },
                ["AscendancyButtonPressed"]= {
                    ["x"]= 717,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButtonHighlight"]= {
                    ["x"]= 1861,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButton"]= {
                    ["x"]= 792,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyFrameLargeNormal"]= {
                    ["x"]= 2268,
                    ["y"]= 244,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeCanAllocate"]= {
                    ["x"]= 2268,
                    ["y"]= 1098,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeAllocated"]= {
                    ["x"]= 2268,
                    ["y"]= 1952,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameSmallNormal"]= {
                    ["x"]= 1789,
                    ["y"]= 2211,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallCanAllocate"]= {
                    ["x"]= 731,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallAllocated"]= {
                    ["x"]= 1277,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyMiddle"]= {
                    ["x"]= 1791,
                    ["y"]= 2268,
                    ["w"]= 31,
                    ["h"]= 31
                }
            }
        },
        ["brinerotBloodline"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/bloodline-3.webp?c89491a1",
            ["w"]= 2329,
            ["h"]= 2329,
            ["coords"]= {
                ["ClassesBrinerot"]= {
                    ["x"]= 0,
                    ["y"]= 1611,
                    ["w"]= 567,
                    ["h"]= 537
                },
                ["AscendancyButtonPressed"]= {
                    ["x"]= 1421,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButtonHighlight"]= {
                    ["x"]= 352,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButton"]= {
                    ["x"]= 1496,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyFrameLargeNormal"]= {
                    ["x"]= 2268,
                    ["y"]= 732,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeCanAllocate"]= {
                    ["x"]= 2268,
                    ["y"]= 1586,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeAllocated"]= {
                    ["x"]= 183,
                    ["y"]= 2268,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameSmallNormal"]= {
                    ["x"]= 2101,
                    ["y"]= 2211,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallCanAllocate"]= {
                    ["x"]= 1043,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallAllocated"]= {
                    ["x"]= 1589,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyMiddle"]= {
                    ["x"]= 2039,
                    ["y"]= 2268,
                    ["w"]= 31,
                    ["h"]= 31
                }
            }
        },
        ["breachlordBloodline"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/bloodline-3.webp?c89491a1",
            ["w"]= 2329,
            ["h"]= 2329,
            ["coords"]= {
                ["ClassesBreachlord"]= {
                    ["x"]= 567,
                    ["y"]= 1611,
                    ["w"]= 567,
                    ["h"]= 537
                },
                ["AscendancyButtonPressed"]= {
                    ["x"]= 1245,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButtonHighlight"]= {
                    ["x"]= 176,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButton"]= {
                    ["x"]= 1320,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyFrameLargeNormal"]= {
                    ["x"]= 2268,
                    ["y"]= 610,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeCanAllocate"]= {
                    ["x"]= 2268,
                    ["y"]= 1464,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeAllocated"]= {
                    ["x"]= 61,
                    ["y"]= 2268,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameSmallNormal"]= {
                    ["x"]= 2023,
                    ["y"]= 2211,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallCanAllocate"]= {
                    ["x"]= 965,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallAllocated"]= {
                    ["x"]= 1511,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyMiddle"]= {
                    ["x"]= 1977,
                    ["y"]= 2268,
                    ["w"]= 31,
                    ["h"]= 31
                }
            }
        },
        ["aulBloodline"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/bloodline-3.webp?c89491a1",
            ["w"]= 2329,
            ["h"]= 2329,
            ["coords"]= {
                ["ClassesAul"]= {
                    ["x"]= 1134,
                    ["y"]= 1611,
                    ["w"]= 567,
                    ["h"]= 537
                },
                ["AscendancyButtonPressed"]= {
                    ["x"]= 805,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButtonHighlight"]= {
                    ["x"]= 1949,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButton"]= {
                    ["x"]= 880,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyFrameLargeNormal"]= {
                    ["x"]= 2268,
                    ["y"]= 305,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeCanAllocate"]= {
                    ["x"]= 2268,
                    ["y"]= 1159,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeAllocated"]= {
                    ["x"]= 2268,
                    ["y"]= 2013,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameSmallNormal"]= {
                    ["x"]= 1828,
                    ["y"]= 2211,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallCanAllocate"]= {
                    ["x"]= 770,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallAllocated"]= {
                    ["x"]= 1316,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyMiddle"]= {
                    ["x"]= 1822,
                    ["y"]= 2268,
                    ["w"]= 31,
                    ["h"]= 31
                }
            }
        },
        ["abyssalBloodline"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/bloodline-3.webp?c89491a1",
            ["w"]= 2329,
            ["h"]= 2329,
            ["coords"]= {
                ["ClassesAbyssal"]= {
                    ["x"]= 1701,
                    ["y"]= 1611,
                    ["w"]= 567,
                    ["h"]= 537
                },
                ["AscendancyButtonPressed"]= {
                    ["x"]= 1509,
                    ["y"]= 2148,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButtonHighlight"]= {
                    ["x"]= 440,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyButton"]= {
                    ["x"]= 1584,
                    ["y"]= 2211,
                    ["w"]= 88,
                    ["h"]= 57
                },
                ["AscendancyFrameLargeNormal"]= {
                    ["x"]= 2268,
                    ["y"]= 793,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeCanAllocate"]= {
                    ["x"]= 2268,
                    ["y"]= 1647,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameLargeAllocated"]= {
                    ["x"]= 244,
                    ["y"]= 2268,
                    ["w"]= 61,
                    ["h"]= 61
                },
                ["AscendancyFrameSmallNormal"]= {
                    ["x"]= 2140,
                    ["y"]= 2211,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallCanAllocate"]= {
                    ["x"]= 1082,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyFrameSmallAllocated"]= {
                    ["x"]= 1628,
                    ["y"]= 2268,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["AscendancyMiddle"]= {
                    ["x"]= 2070,
                    ["y"]= 2268,
                    ["w"]= 31,
                    ["h"]= 31
                }
            }
        },
        ["startNode"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/group-background-3.png?95dbfa0a",
            ["w"]= 1006,
            ["h"]= 666,
            ["coords"]= {
                ["centerwitch"]= {
                    ["x"]= 0,
                    ["y"]= 0,
                    ["w"]= 241,
                    ["h"]= 222
                },
                ["centertemplar"]= {
                    ["x"]= 241,
                    ["y"]= 0,
                    ["w"]= 241,
                    ["h"]= 222
                },
                ["centershadow"]= {
                    ["x"]= 0,
                    ["y"]= 222,
                    ["w"]= 241,
                    ["h"]= 222
                },
                ["centerscion"]= {
                    ["x"]= 241,
                    ["y"]= 222,
                    ["w"]= 241,
                    ["h"]= 222
                },
                ["centerranger"]= {
                    ["x"]= 482,
                    ["y"]= 0,
                    ["w"]= 241,
                    ["h"]= 222
                },
                ["centermarauder"]= {
                    ["x"]= 482,
                    ["y"]= 222,
                    ["w"]= 241,
                    ["h"]= 222
                },
                ["centerduelist"]= {
                    ["x"]= 0,
                    ["y"]= 444,
                    ["w"]= 241,
                    ["h"]= 222
                },
                ["PSStartNodeBackgroundInactive"]= {
                    ["x"]= 241,
                    ["y"]= 444,
                    ["w"]= 202,
                    ["h"]= 202
                }
            }
        },
        ["groupBackground"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/group-background-3.png?95dbfa0a",
            ["w"]= 1006,
            ["h"]= 666,
            ["coords"]= {
                ["PSGroupBackground3"]= {
                    ["x"]= 723,
                    ["y"]= 0,
                    ["w"]= 283,
                    ["h"]= 143
                },
                ["GroupBackgroundLargeHalfAlt"]= {
                    ["x"]= 723,
                    ["y"]= 143,
                    ["w"]= 283,
                    ["h"]= 143
                },
                ["PSGroupBackground2"]= {
                    ["x"]= 723,
                    ["y"]= 286,
                    ["w"]= 178,
                    ["h"]= 178
                },
                ["GroupBackgroundMediumAlt"]= {
                    ["x"]= 723,
                    ["y"]= 464,
                    ["w"]= 178,
                    ["h"]= 178
                },
                ["PSGroupBackground1"]= {
                    ["x"]= 443,
                    ["y"]= 444,
                    ["w"]= 138,
                    ["h"]= 138
                },
                ["GroupBackgroundSmallAlt"]= {
                    ["x"]= 581,
                    ["y"]= 444,
                    ["w"]= 138,
                    ["h"]= 138
                }
            }
        },
        ["frame"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/frame-3.png?4eb7045b",
            ["w"]= 383,
            ["h"]= 334,
            ["coords"]= {
                ["KeystoneFrameUnallocated"]= {
                    ["x"]= 0,
                    ["y"]= 0,
                    ["w"]= 83,
                    ["h"]= 85
                },
                ["KeystoneFrameCanAllocate"]= {
                    ["x"]= 83,
                    ["y"]= 0,
                    ["w"]= 83,
                    ["h"]= 85
                },
                ["KeystoneFrameAllocated"]= {
                    ["x"]= 166,
                    ["y"]= 0,
                    ["w"]= 83,
                    ["h"]= 85
                },
                ["JewelSocketClusterAltNormal1Small"]= {
                    ["x"]= 0,
                    ["y"]= 85,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["JewelSocketClusterAltNormal1Medium"]= {
                    ["x"]= 76,
                    ["y"]= 85,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["JewelSocketClusterAltNormal1Large"]= {
                    ["x"]= 152,
                    ["y"]= 85,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["JewelSocketClusterAltCanAllocate1Small"]= {
                    ["x"]= 0,
                    ["y"]= 161,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["JewelSocketClusterAltCanAllocate1Medium"]= {
                    ["x"]= 76,
                    ["y"]= 161,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["JewelSocketClusterAltCanAllocate1Large"]= {
                    ["x"]= 152,
                    ["y"]= 161,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["JewelSocketAltNormal"]= {
                    ["x"]= 249,
                    ["y"]= 0,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["JewelSocketAltCanAllocate"]= {
                    ["x"]= 249,
                    ["y"]= 76,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["JewelSocketAltActive"]= {
                    ["x"]= 249,
                    ["y"]= 152,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["NotableFrameUnallocated"]= {
                    ["x"]= 0,
                    ["y"]= 237,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["NotableFrameCanAllocate"]= {
                    ["x"]= 58,
                    ["y"]= 237,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["NotableFrameAllocated"]= {
                    ["x"]= 116,
                    ["y"]= 237,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["JewelFrameUnallocated"]= {
                    ["x"]= 174,
                    ["y"]= 237,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["JewelFrameCanAllocate"]= {
                    ["x"]= 232,
                    ["y"]= 237,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["JewelFrameAllocated"]= {
                    ["x"]= 325,
                    ["y"]= 0,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["BlightedNotableFrameUnallocated"]= {
                    ["x"]= 325,
                    ["y"]= 58,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["BlightedNotableFrameCanAllocate"]= {
                    ["x"]= 325,
                    ["y"]= 116,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["BlightedNotableFrameAllocated"]= {
                    ["x"]= 325,
                    ["y"]= 174,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["PSSkillFrameHighlighted"]= {
                    ["x"]= 325,
                    ["y"]= 232,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["PSSkillFrameActive"]= {
                    ["x"]= 0,
                    ["y"]= 295,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["PSSkillFrame"]= {
                    ["x"]= 39,
                    ["y"]= 295,
                    ["w"]= 39,
                    ["h"]= 39
                }
            }
        },
        ["jewel"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/jewel-3.png?b4c992ca",
            ["w"]= 286,
            ["h"]= 286,
            ["coords"]= {
                ["JewelSocketActiveRedAlt"]= {
                    ["x"]= 0,
                    ["y"]= 0,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["JewelSocketActivePrismaticAlt"]= {
                    ["x"]= 76,
                    ["y"]= 0,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["JewelSocketActiveLegionAlt"]= {
                    ["x"]= 0,
                    ["y"]= 76,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["JewelSocketActiveGreenAlt"]= {
                    ["x"]= 76,
                    ["y"]= 76,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["JewelSocketActiveBlueAlt"]= {
                    ["x"]= 152,
                    ["y"]= 0,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["JewelSocketActiveAltRed"]= {
                    ["x"]= 152,
                    ["y"]= 76,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["JewelSocketActiveAltPurple"]= {
                    ["x"]= 0,
                    ["y"]= 152,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["JewelSocketActiveAltBlue"]= {
                    ["x"]= 76,
                    ["y"]= 152,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["JewelSocketActiveAbyssAlt"]= {
                    ["x"]= 152,
                    ["y"]= 152,
                    ["w"]= 76,
                    ["h"]= 76
                },
                ["JewelSocketActiveRed"]= {
                    ["x"]= 228,
                    ["y"]= 0,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["JewelSocketActivePrismatic"]= {
                    ["x"]= 228,
                    ["y"]= 58,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["JewelSocketActiveLegion"]= {
                    ["x"]= 228,
                    ["y"]= 116,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["JewelSocketActiveGreen"]= {
                    ["x"]= 0,
                    ["y"]= 228,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["JewelSocketActiveBlue"]= {
                    ["x"]= 58,
                    ["y"]= 228,
                    ["w"]= 58,
                    ["h"]= 58
                },
                ["JewelSocketActiveAbyss"]= {
                    ["x"]= 116,
                    ["y"]= 228,
                    ["w"]= 58,
                    ["h"]= 58
                }
            }
        },
        ["line"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/line-3.png?d92f8f13",
            ["w"]= 550,
            ["h"]= 1687,
            ["coords"]= {
                ["LineConnectorActive"]= {
                    ["x"]= 0,
                    ["y"]= 12,
                    ["w"]= 550,
                    ["h"]= 13
                },
                ["Orbit1Active"]= {
                    ["x"]= 510,
                    ["y"]= 510,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["Orbit2Active"]= {
                    ["x"]= 479,
                    ["y"]= 479,
                    ["w"]= 70,
                    ["h"]= 70
                },
                ["Orbit3Active"]= {
                    ["x"]= 413,
                    ["y"]= 413,
                    ["w"]= 136,
                    ["h"]= 136
                },
                ["Orbit4Active"]= {
                    ["x"]= 352,
                    ["y"]= 352,
                    ["w"]= 197,
                    ["h"]= 197
                },
                ["Orbit5Active"]= {
                    ["x"]= 287,
                    ["y"]= 287,
                    ["w"]= 262,
                    ["h"]= 262
                },
                ["Orbit6Active"]= {
                    ["x"]= 217,
                    ["y"]= 217,
                    ["w"]= 332,
                    ["h"]= 332
                },
                ["LineConnectorNormal"]= {
                    ["x"]= 0,
                    ["y"]= 562,
                    ["w"]= 550,
                    ["h"]= 13
                },
                ["Orbit1Normal"]= {
                    ["x"]= 510,
                    ["y"]= 1060,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["Orbit2Normal"]= {
                    ["x"]= 479,
                    ["y"]= 1029,
                    ["w"]= 70,
                    ["h"]= 70
                },
                ["Orbit3Normal"]= {
                    ["x"]= 413,
                    ["y"]= 963,
                    ["w"]= 136,
                    ["h"]= 136
                },
                ["Orbit4Normal"]= {
                    ["x"]= 352,
                    ["y"]= 902,
                    ["w"]= 197,
                    ["h"]= 197
                },
                ["Orbit5Normal"]= {
                    ["x"]= 287,
                    ["y"]= 837,
                    ["w"]= 262,
                    ["h"]= 262
                },
                ["Orbit6Normal"]= {
                    ["x"]= 217,
                    ["y"]= 767,
                    ["w"]= 332,
                    ["h"]= 332
                },
                ["LineConnectorIntermediate"]= {
                    ["x"]= 0,
                    ["y"]= 1112,
                    ["w"]= 550,
                    ["h"]= 13
                },
                ["Orbit1Intermediate"]= {
                    ["x"]= 510,
                    ["y"]= 1610,
                    ["w"]= 39,
                    ["h"]= 39
                },
                ["Orbit2Intermediate"]= {
                    ["x"]= 479,
                    ["y"]= 1580,
                    ["w"]= 70,
                    ["h"]= 70
                },
                ["Orbit3Intermediate"]= {
                    ["x"]= 413,
                    ["y"]= 1513,
                    ["w"]= 136,
                    ["h"]= 136
                },
                ["Orbit4Intermediate"]= {
                    ["x"]= 352,
                    ["y"]= 1453,
                    ["w"]= 197,
                    ["h"]= 197
                },
                ["Orbit5Intermediate"]= {
                    ["x"]= 287,
                    ["y"]= 1388,
                    ["w"]= 262,
                    ["h"]= 262
                },
                ["Orbit6Intermediate"]= {
                    ["x"]= 217,
                    ["y"]= 1317,
                    ["w"]= 332,
                    ["h"]= 332
                },
                ["PSLineDecoHighlighted"]= {
                    ["x"]= 0,
                    ["y"]= 1650,
                    ["w"]= 18,
                    ["h"]= 18
                },
                ["PSLineDeco"]= {
                    ["x"]= 0,
                    ["y"]= 1668,
                    ["w"]= 18,
                    ["h"]= 18
                }
            }
        },
        ["jewelRadius"]= {
            ["filename"]= "https://web.poecdn.com/image/passive-skill/jewel-radius.png?1011b076",
            ["w"]= 2252,
            ["h"]= 2201,
            ["coords"]= {
                ["VaalJewelCircle2"]= {
                    ["x"]= 0,
                    ["y"]= 0,
                    ["w"]= 563,
                    ["h"]= 563
                },
                ["VaalJewelCircle1"]= {
                    ["x"]= 563,
                    ["y"]= 0,
                    ["w"]= 563,
                    ["h"]= 563
                },
                ["TemplarJewelCircle2"]= {
                    ["x"]= 0,
                    ["y"]= 563,
                    ["w"]= 563,
                    ["h"]= 563
                },
                ["TemplarJewelCircle1"]= {
                    ["x"]= 563,
                    ["y"]= 563,
                    ["w"]= 563,
                    ["h"]= 563
                },
                ["MarakethJewelCircle2"]= {
                    ["x"]= 1126,
                    ["y"]= 0,
                    ["w"]= 563,
                    ["h"]= 563
                },
                ["MarakethJewelCircle1"]= {
                    ["x"]= 1126,
                    ["y"]= 563,
                    ["w"]= 563,
                    ["h"]= 563
                },
                ["KaruiJewelCircle2"]= {
                    ["x"]= 0,
                    ["y"]= 1126,
                    ["w"]= 563,
                    ["h"]= 563
                },
                ["KaruiJewelCircle1"]= {
                    ["x"]= 563,
                    ["y"]= 1126,
                    ["w"]= 563,
                    ["h"]= 563
                },
                ["KalguurJewelCircle2"]= {
                    ["x"]= 1126,
                    ["y"]= 1126,
                    ["w"]= 563,
                    ["h"]= 563
                },
                ["KalguurJewelCircle1"]= {
                    ["x"]= 1689,
                    ["y"]= 0,
                    ["w"]= 563,
                    ["h"]= 563
                },
                ["EternalEmpireJewelCircle2"]= {
                    ["x"]= 1689,
                    ["y"]= 563,
                    ["w"]= 563,
                    ["h"]= 563
                },
                ["EternalEmpireJewelCircle1"]= {
                    ["x"]= 1689,
                    ["y"]= 1126,
                    ["w"]= 563,
                    ["h"]= 563
                },
                ["JewelCircle1Inverse"]= {
                    ["x"]= 0,
                    ["y"]= 1689,
                    ["w"]= 512,
                    ["h"]= 512
                },
                ["JewelCircle1"]= {
                    ["x"]= 512,
                    ["y"]= 1689,
                    ["w"]= 512,
                    ["h"]= 512
                }
            }
        }
    }
}