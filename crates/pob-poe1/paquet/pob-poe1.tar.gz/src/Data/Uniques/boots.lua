-- Item data (c) Grinding Gear Games

return {
-- Boots: Armour
[[
Craiceann's Tracks
Goliath Greaves
League: Bestiary
Source: Drops from unique{Craiceann, First of the Deep}
(150-180)% increased Armour
+(50-70) to maximum Life
+(25-30)% to Cold Resistance
25% increased Movement Speed
Cannot be Stunned if you have at least 10 Crab Barriers
You only lose (5-7) Crab Barriers when you take Physical Damage from a Hit
]],[[
Doryani's Delusion
{variant:1,2,3,4,5,6,7,8,9}Titan Greaves
{variant:10,11,12,13,14,15,16,17,18}Leviathan Greaves
League: Delve
Source: Drops from unique{The Apex Assembly} in unique{Doryani's Machinarium}
Variant: Purity of Fire: Fire Pre 3.29.0
Variant: Purity of Fire: Cold Pre 3.29.0
Variant: Purity of Fire: Lightning Pre 3.29.0
Variant: Purity of Ice: Fire Pre 3.29.0
Variant: Purity of Ice: Cold Pre 3.29.0
Variant: Purity of Ice: Lightning Pre 3.29.0
Variant: Purity of Lightning: Fire Pre 3.29.0
Variant: Purity of Lightning: Cold Pre 3.29.0
Variant: Purity of Lightning: Lightning Pre 3.29.0
Variant: Purity of Fire: Fire
Variant: Purity of Fire: Cold
Variant: Purity of Fire: Lightning
Variant: Purity of Ice: Fire
Variant: Purity of Ice: Cold
Variant: Purity of Ice: Lightning
Variant: Purity of Lightning: Fire
Variant: Purity of Lightning: Cold
Variant: Purity of Lightning: Lightning
{variant:1,2,3,10,11,12}Grants Level 30 Purity of Fire
{variant:4,5,6,13,14,15}Grants Level 30 Purity of Ice
{variant:7,8,9,16,17,18}Grants Level 30 Purity of Lightning
{variant:1,4,7,10,13,16}Adds (25-30) to (40-45) Fire Damage to Spells and Attacks
{variant:2,5,8,11,14,17}Adds (25-30) to (40-45) Cold Damage to Spells and Attacks
{variant:3,6,9,12,15,18}Adds (1-3) to (68-72) Lightning Damage to Spells and Attacks
{variant:1,2,3,4,5,6,7,8,9}(100-120)% increased Armour
{variant:10,11,12,13,14,15,16,17,18}(0-200)% increased Armour
{variant:1,2,3,4,5,6,7,8,9}+(60-70) to maximum Life
{variant:10,11,12,13,14,15,16,17,18}+(0-100) to maximum Life
{variant:1,2,3,4,5,6,7,8,9}30% increased Movement Speed
{variant:10,11,12,13,14,15,16,17,18}(0-40)% increased Movement Speed
{variant:10,11,12,13,14,15,16,17,18}Corrupted
]],[[
The Infinite Pursuit
{variant:1}Goliath Greaves
{variant:2}Titan Greaves
Variant: Pre 3.21.0
Variant: Current
League: Breach
Source: Drops in Uul-Netol Breach or from unique{Uul-Netol, Unburdened Flesh}
Upgrade: Upgrades to unique{The Red Trail} using currency{Blessing of Uul-Netol}
{variant:1}+(30-60) to maximum Life
20% increased Movement Speed
Moving while Bleeding doesn't cause you to take extra Damage
{variant:2}Bleeding on you expires 75% slower while Moving
{variant:2}Cannot be Poisoned while Bleeding
{variant:2}Cannot be Stunned while Bleeding
{variant:1}15% increased Movement Speed while Bleeding
{variant:2}20% increased Movement Speed while Bleeding
50% chance to be inflicted with Bleeding when Hit by an Attack
]],[[
The Red Trail
Titan Greaves
Variant: Pre 3.21.0
Variant: Current
League: Breach
Source: Upgraded from unique{The Infinite Pursuit} using currency{Blessing of Uul-Netol}
{variant:1}(60-80)% increased Armour
{variant:2}(60-100)% increased Armour
{variant:1}+(50-70) to maximum Life
{variant:2}+(60-100) to maximum Life
{variant:1}25% increased Movement Speed
{variant:2}30% increased Movement Speed
10% additional Physical Damage Reduction while stationary
Gain a Frenzy Charge on Hit while Bleeding
{variant:1}15% increased Movement Speed while Bleeding
50% chance to be inflicted with Bleeding when Hit by an Attack
Gore Footprints
]],[[
Replica Red Trail
Titan Greaves
Variant: Pre 3.21.0
Variant: Current
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
{variant:1}(60-80)% increased Armour
{variant:2}(60-100)% increased Armour
{variant:1}+(50-70) to maximum Life
{variant:2}+(60-100) to maximum Life
{variant:1}25% increased Movement Speed
{variant:2}30% increased Movement Speed
Gain a Power Charge on Hit while Poisoned
+30% to Chaos Resistance while stationary
Necrotic Footprints
50% chance for Spell Hits against you to inflict Poison
{variant:1}15% increased Movement Speed while Poisoned
]],[[
Kahuturoa's Certainty
Ancient Greaves
(100-150)% increased Armour
5% reduced Movement Speed
(100-200)% increased Stun and Block Recovery
Unaffected by Damaging Ailments
]],[[
Kaom's Roots
Titan Greaves
Variant: Pre 2.6.0
Variant: Current
Has no Sockets
{variant:1}+(120-150) to maximum Life
{variant:2}+(150-200) to maximum Life
Cannot be Knocked Back
{variant:2}Action Speed cannot be modified to below Base Value
Unwavering Stance
]],[[
Redblade Tramplers
Ancient Greaves
League: Warbands
Source: Drops from Redblade Mercenary monsters
Variant: Pre 2.6.0
Variant: Current
Adds (2-5) to (7-10) Physical Damage to Attacks
(5-10)% reduced Enemy Stun Threshold
(150-200)% increased Armour
{variant:2}+(50-70) to maximum Life
+(20-30)% to Fire Resistance
{variant:1}20% increased Movement Speed
{variant:2}25% increased Movement Speed
Unaffected by Burning Ground
]],[[
Stormcharger
Plated Greaves
Variant: Pre 3.19.0
Variant: Current
+(1-50)% to Lightning Resistance
{variant:1}20% increased Movement Speed
{variant:2}(1-40)% increased Movement Speed
{variant:1}30% of Physical Damage Converted to Lightning Damage
{variant:1}50% increased Duration of Lightning Ailments
{variant:2}(1-100)% increased Duration of Lightning Ailments
{variant:1}(15-25)% increased Effect of Lightning Ailments
{variant:2}(1-50)% increased Effect of Lightning Ailments
{variant:2}Unaffected by Shocked Ground
]],[[
The Tempest Rising
Goliath Greaves
Source: Drops from unique{Sirus, Awakener of Worlds} (Uber)
(80-120)% increased Armour
30% increased Movement Speed
(5-25)% increased Duration of Ailments on Enemies
Damaging Ailments deal damage (5-25)% Faster
You and Enemies in your Presence count as moving while affected by Elemental Ailments
]],[[
Torchoak Step
Antique Greaves
Variant: Pre 3.16.0
Variant: Current
(80-120)% increased Armour
{variant:1}(30-50)% increased Totem Life
{variant:2}(20-30)% increased Totem Life
25% increased Movement Speed
(30-50)% increased Totem Placement speed
{variant:1}Totems Reflect 25% of their maximum Life as Fire Damage to Enemies within 1.8 metres when Hit
{variant:2}Totems Reflect 100% of their maximum Life as Fire Damage to Enemies within 1.8 metres when Hit
]],[[
Windscream
Reinforced Greaves
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
(50-80)% increased Armour
+(10-15)% to all Elemental Resistances
{variant:1}10% increased Movement Speed
{variant:2}15% increased Movement Speed
{variant:3}20% increased Movement Speed
{variant:1}10% increased Elemental Damage
{variant:2}(10-20)% increased Elemental Damage
{variant:1,2}You can apply an additional Curse
{variant:3}You can apply an additional Curse
{variant:3}50% increased Area of Effect of Hex Skills
]],[[
Windshriek
Reinforced Greaves
Source: No longer obtainable
Requires Level 60
(200-250)% increased Armour
+(10-15)% to all Elemental Resistances
25% increased Movement Speed
(10-20)% increased Elemental Damage
You can apply an additional Curse
60% increased Area of Effect of Hex Skills
]],[[
Dawnstrider
Vaal Greaves
Variant: Pre 3.25.0
Variant: Current
Source: Drops from unique{The Searing Exarch}
+(80-100) to maximum Life
30% increased Movement Speed
{variant:2}(3-5)% of Damage from Hits is taken from your nearest Totem's Life before you
Ancestral Bond
]],
-- Boots: Evasion
[[
Abberath's Hooves
Goathide Boots
Triggers Level 7 Abberath's Fury when Equipped
+(20-30) to Strength
15% increased Movement Speed
(6-10)% chance to Ignite
When you Kill an Ignited Enemy, inflict an equivalent Ignite on each Enemy within 2 metres
1% increased Fire Damage per 20 Strength
Burning Hoofprints
]],[[
Atziri's Step
Slink Boots
Source: Drops from unique{Atziri, Queen of the Vaal} in normal{The Apex of Sacrifice}
Variant: Pre 3.16.0
Variant: Current
{variant:1}+(21-24)% chance to Suppress Spell Damage
{variant:2}+(20-26)% chance to Suppress Spell Damage
180% increased Evasion Rating
+(55-75) to maximum Life
30% increased Movement Speed
]],[[
The Blood Dance
Sharkskin Boots
Variant: Pre 1.0.0
Variant: Pre 2.1.0
Variant: Pre 3.11.0
Variant: Current
+(30-40) to Dexterity
20% increased Movement Speed
2% increased Movement Speed per Frenzy Charge
{variant:1,2,3}3% reduced Attack and Cast Speed per Frenzy Charge
{variant:4}4% reduced Attack and Cast Speed per Frenzy Charge
{variant:1,2}Regenerate 1% of Life per second per Frenzy Charge
{variant:3}Regenerate 0.5% of Life per second per Frenzy Charge
{variant:4}Regenerate 0.8% of Life per second per Frenzy Charge
(20-30)% chance to gain a Frenzy Charge on Kill
{variant:1}3% increased Damage per Frenzy Charge with Hits against Enemies on Low Life
{variant:2,3}6% increased Damage per Frenzy Charge with Hits against Enemies on Low Life
{variant:4}(20-30)% increased Damage per Frenzy Charge with Hits against Enemies on Low Life
Gore Footprints
]],[[
Deerstalker
Deerskin Boots
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
{variant:1,2}Socketed Gems are Supported by Level 11 Trap Support
{variant:3}Socketed Gems are Supported by Level 15 Trap Support
(160-200)% increased Evasion Rating
{variant:1,2}+(35-45) to maximum Life
{variant:2,3}15% increased Movement Speed
(14-18)% increased Trap Throwing Speed
{variant:1}30% increased Movement Speed for 9 seconds on Throwing a Trap
{variant:2,3}15% increased Movement Speed for 9 seconds on Throwing a Trap
]],[[
Orbala's Stand
Eelskin Boots
(100-150)% increased Evasion Rating
(20-30)% increased Movement Speed
Cannot be Stunned by Suppressed Spell Damage
Debilitate Enemies for 4 Seconds when you Suppress their Spell Damage
]],[[
Doryani's Delusion
{variant:1,2,3,4,5,6,7,8,9}Slink Boots
{variant:10,11,12,13,14,15,16,17,18}Velour Boots
League: Delve
Source: Drops from unique{The Apex Assembly} in unique{Doryani's Machinarium}
Variant: Purity of Fire: Fire Pre 3.29.0
Variant: Purity of Fire: Cold Pre 3.29.0
Variant: Purity of Fire: Lightning Pre 3.29.0
Variant: Purity of Ice: Fire Pre 3.29.0
Variant: Purity of Ice: Cold Pre 3.29.0
Variant: Purity of Ice: Lightning Pre 3.29.0
Variant: Purity of Lightning: Fire Pre 3.29.0
Variant: Purity of Lightning: Cold Pre 3.29.0
Variant: Purity of Lightning: Lightning Pre 3.29.0
Variant: Purity of Fire: Fire
Variant: Purity of Fire: Cold
Variant: Purity of Fire: Lightning
Variant: Purity of Ice: Fire
Variant: Purity of Ice: Cold
Variant: Purity of Ice: Lightning
Variant: Purity of Lightning: Fire
Variant: Purity of Lightning: Cold
Variant: Purity of Lightning: Lightning
{variant:1,2,3,10,11,12}Grants Level 30 Purity of Fire
{variant:4,5,6,13,14,15}Grants Level 30 Purity of Ice
{variant:7,8,9,16,17,18}Grants Level 30 Purity of Lightning
{variant:1,4,7,10,13,16}Adds (25-30) to (40-45) Fire Damage to Spells and Attacks
{variant:2,5,8,11,14,17}Adds (25-30) to (40-45) Cold Damage to Spells and Attacks
{variant:3,6,9,12,15,18}Adds (1-3) to (68-72) Lightning Damage to Spells and Attacks
{variant:1,2,3,4,5,6,7,8,9}(100-120)% increased Evasion Rating
{variant:10,11,12,13,14,15,16,17,18}(0-200)% increased Evasion Rating
{variant:1,2,3,4,5,6,7,8,9}+(60-70) to maximum Life
{variant:10,11,12,13,14,15,16,17,18}+(0-100) to maximum Life
{variant:1,2,3,4,5,6,7,8,9}30% increased Movement Speed
{variant:10,11,12,13,14,15,16,17,18}(0-40)% increased Movement Speed
{variant:10,11,12,13,14,15,16,17,18}Corrupted
]],[[
Farrul's Chase
Slink Boots
League: Bestiary
Source: Drops from unique{Farrul, First of the Plains}
Trigger Level 20 Intimidating Cry when you lose Cat's Stealth
(110-150)% increased Evasion Rating
+(50-70) to maximum Life
20% increased Movement Speed
(40-50)% chance to Avoid Bleeding
20% increased Movement Speed while you have Cat's Stealth
]],[[
Goldwyrm
Nubuck Boots
Variant: Pre 1.1.0
Variant: Pre 3.25.0
Variant: Current
60% increased Mana Regeneration Rate
{variant:1}(20-30)% increased Quantity of Items found
{variant:2}(14-20)% increased Quantity of Items found
{variant:3}+(20-40)% to Item Rarity
+(40-50)% to Fire Resistance
10% increased Movement Speed
]],[[
Garukhan's Flight
Stealth Boots
Variant: Pre 3.5.0
Variant: Pre 3.16.0
Variant: Current
+(30-40) to Dexterity
{variant:1}(80-120)% increased Evasion Rating
{variant:2}(320-380)% increased Evasion Rating
{variant:3}(300-340)% increased Evasion Rating
30% increased Movement Speed
Immune to Burning Ground, Shocked Ground and Chilled Ground
Regenerate 100 Life per second while moving
{variant:1}+1 to Maximum Life per 10 Dexterity
{variant:2,3}+2 to Maximum Life per 10 Dexterity
]],[[
Seven-League Step
Rawhide Boots
League: Perandus
50% increased Movement Speed
]],[[
Sin Trek
Stealth Boots
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.5.0
Variant: Current
+(20-30) to Dexterity
+(20-30) to Intelligence
(80-100)% increased Evasion Rating
{variant:1}+(50-70) to maximum Energy Shield
{variant:2}+(70-100) to maximum Energy Shield
{variant:3}+(100-160) to maximum Energy Shield
{variant:4}+(100-150) to maximum Energy Shield
30% increased Movement Speed
Enemies Cannot Leech Life From you
]],[[
Temptation Step
Shagreen Boots
League: Ultimatum
Source: Drops from unique{The Trialmaster}
(170-250)% increased Evasion Rating
+(19-29)% to Chaos Resistance
15% increased Damage for each Poison on you up to a maximum of 75%
10% increased Movement Speed for each Poison on you up to a maximum of 50%
Poison you inflict with Travel Skills is Reflected to you if you
have fewer than 5 Poisons on you
]],[[
Three-step Assault
Shagreen Boots
Variant: Pre 2.6.0
Variant: Pre 3.16.0
Variant: Current
+(25-35) to Dexterity
(20-40)% increased Evasion Rating
{variant:1}40% increased Evasion Rating during Onslaught
{variant:2,3}100% increased Evasion Rating during Onslaught
{variant:1}+(30-60) to maximum Life
{variant:2,3}+(50-70) to maximum Life
{variant:1}20% increased Movement Speed
{variant:2,3}25% increased Movement Speed
{variant:1,2}10% chance to Avoid Elemental Ailments while Phasing
{variant:3}30% chance to Avoid Elemental Ailments while Phasing
]],[[
Replica Three-step Assault
Shagreen Boots
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
+(25-35) to Dexterity
(20-40)% increased Evasion Rating
+(50-70) to maximum Life
25% increased Movement Speed
(10-30)% increased Elusive Effect
10% increased Movement Speed if you've Hit an Enemy Recently
]],[[
Victario's Flight
Goathide Boots
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
+15 to Dexterity
+15 to Intelligence
(100-150)% increased Evasion Rating
{variant:2}15% increased Movement Speed
{variant:3}(10-20)% increased Movement Speed
{variant:1}30% increased Movement Speed when on Low Life
{variant:3}(10-20)% increased Movement Speed when on Low Life
{variant:1,2}(5-10)% of Damage taken Recouped as Mana
{variant:3}Quicksilver Flasks you Use also apply to Allies within 6 metres
{variant:2}10% increased Movement Speed for you and nearby Allies
]],
-- Boots: Energy Shield
[[
Bones of Ullr
Silk Slippers
(40-60)% increased Energy Shield
+20 to maximum Life
+20 to maximum Mana
+1 to Level of all Raise Zombie Gems
+1 to Level of all Raise Spectre Gems
(5-15)% increased Movement Speed
]],[[
Replica Bones of Ullr
Silk Slippers
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
(40-60)% increased Energy Shield
+20 to maximum Life
+20 to maximum Mana
(5-15)% increased Movement Speed
Summoned Phantasms have 10% chance to refresh their Duration when they Hit a Rare or Unique Enemy
Summoned Raging Spirits have 10% chance to refresh their Duration when they Hit a Rare or Unique Enemy
]],[[
Doryani's Delusion
{variant:1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18}Sorcerer Boots
{variant:19,20,21,22,23,24,25,26,27}Warlock Boots
League: Delve
Source: Drops from unique{The Apex Assembly} in unique{Doryani's Machinarium}
Variant: Purity of Fire: Fire Pre 3.16.0
Variant: Purity of Fire: Cold Pre 3.16.0
Variant: Purity of Fire: Lightning Pre 3.16.0
Variant: Purity of Ice: Fire Pre 3.16.0
Variant: Purity of Ice: Cold Pre 3.16.0
Variant: Purity of Ice: Lightning Pre 3.16.0
Variant: Purity of Lightning: Fire Pre 3.16.0
Variant: Purity of Lightning: Cold Pre 3.16.0
Variant: Purity of Lightning: Lightning Pre 3.16.0
Variant: Purity of Fire: Fire Pre 3.29.0
Variant: Purity of Fire: Cold Pre 3.29.0
Variant: Purity of Fire: Lightning Pre 3.29.0
Variant: Purity of Ice: Fire Pre 3.29.0
Variant: Purity of Ice: Cold Pre 3.29.0
Variant: Purity of Ice: Lightning Pre 3.29.0
Variant: Purity of Lightning: Fire Pre 3.29.0
Variant: Purity of Lightning: Cold Pre 3.29.0
Variant: Purity of Lightning: Lightning Pre 3.29.0
Variant: Purity of Fire: Fire
Variant: Purity of Fire: Cold
Variant: Purity of Fire: Lightning
Variant: Purity of Ice: Fire
Variant: Purity of Ice: Cold
Variant: Purity of Ice: Lightning
Variant: Purity of Lightning: Fire
Variant: Purity of Lightning: Cold
Variant: Purity of Lightning: Lightning
{variant:1,2,3,10,11,12,19,20,21}Grants Level 30 Purity of Fire
{variant:4,5,6,13,14,15,22,23,24}Grants Level 30 Purity of Ice
{variant:7,8,9,16,17,18,25,26,27}Grants Level 30 Purity of Lightning
{variant:1,4,7,10,13,16,19,22,25}Adds (25-30) to (40-45) Fire Damage to Spells and Attacks
{variant:2,5,8,11,14,17,20,23,26}Adds (25-30) to (40-45) Cold Damage to Spells and Attacks
{variant:3,6,9,12,15,18,21,24,27}Adds (1-3) to (68-72) Lightning Damage to Spells and Attacks
{variant:1,2,3,4,5,6,7,8,9}(180-220)% increased Energy Shield
{variant:10,11,12,13,14,15,16,17,18}(150-180)% increased Energy Shield
{variant:19,20,21,22,23,24,25,26,27}(0-200)% increased Energy Shield
{variant:1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18}+(60-70) to maximum Life
{variant:19,20,21,22,23,24,25,26,27}+(0-100) to maximum Life
{variant:1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18}30% increased Movement Speed
{variant:19,20,21,22,23,24,25,26,27}(0-40)% increased Movement Speed
{variant:19,20,21,22,23,24,25,26,27}Corrupted
]],[[
Inya's Epiphany
Arcanist Slippers
(5-8)% increased Intelligence
+(50-70) to maximum Life
25% increased Movement Speed
5% increased Damage per Power Charge
25% chance that if you would gain Power Charges, you instead gain up to
your maximum number of Power Charges
]],[[
Replica Inya's Epiphany
Arcanist Slippers
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
(5-8)% increased Intelligence
+(50-70) to maximum Life
5% increased Damage per Power Charge
Regenerate 0.5% of Life per second per Power Charge
5% increased Movement Speed per Power Charge
]],[[
Rainbowstride
Conjurer Boots
Variant: Pre 1.0.0
Variant: Pre 1.1.0
Variant: Pre 2.6.0
Variant: Pre 3.4.0
Variant: Pre 3.19.0
Variant: Current
{variant:1,2,3,4}(6-7)% Chance to Block Spell Damage
{variant:5}(4-6)% Chance to Block Spell Damage
{variant:6}(15-20)% Chance to Block Spell Damage
{variant:1,2}(150-200)% increased Energy Shield
{variant:3,4,5}(140-180)% increased Energy Shield
{variant:1,2}+(80-100) to maximum Mana
{variant:3,4,5,6}+(40-60) to maximum Mana
{variant:1,3,4,5,6}+20% to all Elemental Resistances
{variant:2}+8% to all Elemental Resistances
{variant:1,2,3,6}20% increased Movement Speed
{variant:4,5}25% increased Movement Speed
]],[[
Shavronne's Pace
Scholar Boots
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
{variant:1,2,3}+10 to Dexterity
{variant:1}+10 to Intelligence
{variant:2,3,4}+(20-30) to Intelligence
{variant:1}(50-70)% increased Energy Shield
{variant:1}(10-15)% increased Stun and Block Recovery
{variant:2,3}(100-140)% increased Energy Shield
{variant:2,3}(10-15)% increased Stun and Block Recovery
{variant:4}(100-140)% increased Energy Shield
{variant:4}(150-200)% increased Stun and Block Recovery
{variant:3,4}15% increased Movement Speed
{variant:1,2}35% increased Movement Speed when on Full Life
{variant:3,4}20% increased Movement Speed when on Full Life
]],[[
Shavronne's Gambit
Scholar Boots
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 36
+10 to Dexterity
+(20-30) to Intelligence
{variant:1,2}(100-140)% increased Energy Shield
{variant:1,2}(10-15)% increased Stun and Block Recovery
{variant:3}(100-140)% increased Energy Shield
{variant:3}(150-200)% increased Stun and Block Recovery
{variant:2,3}15% increased Movement Speed
{variant:1}35% increased Movement Speed when on Full Life
{variant:2,3}20% increased Movement Speed when on Full Life
{variant:1}Regenerate 2% of Energy Shield per second while on Low Life
{variant:2,3}Regenerate 1% of Energy Shield per second
]],[[
Skyforth
Sorcerer Boots
Energy Shield: 64
+(60-120) to maximum Mana
30% increased Movement Speed
25% chance to gain a Power Charge on Critical Strike
12% increased Reservation Efficiency of Skills
You have no Life Regeneration
Stun Threshold is based on 500% of your Mana instead of Life
]],[[
Steppan Eard
Sorcerer Boots
League: Warbands
Source: Drops from Renegade Warband monsters
Variant: Pre 3.0.0
Variant: Current
+(20-30) to maximum Energy Shield
{variant:1}(110-140)% increased Energy Shield
{variant:2}(50-80)% increased Energy Shield
30% increased Movement Speed
20% increased Movement Speed on Shocked Ground
50% increased Damage on Burning Ground
Regenerate 2% of Life per second on Chilled Ground
Unaffected by Desecrated Ground
]],[[
Wanderlust
Wool Shoes
+5 to Dexterity
+(10-20) to maximum Energy Shield
(20-40)% increased Mana Regeneration Rate
20% increased Movement Speed
Cannot be Frozen
]],[[
Wondertrap
Velvet Slippers
Variant: Pre 1.0.0
Variant: Pre 3.19.0
Variant: Current
{variant:1,2}+(5-10) to Strength
{variant:3}+(5-30) to Strength
{variant:1,2}+(5-10) to Dexterity
{variant:3}+(5-30) to Dexterity
{variant:1,2}+(5-10) to Intelligence
{variant:3}+(5-30) to Intelligence
{variant:1,2}+(10-16) to maximum Energy Shield
{variant:3}+(5-30) to maximum Energy Shield
+100% to Item Rarity when on Low Life
{variant:1}15% increased Movement Speed
{variant:2}10% increased Movement Speed
{variant:3}(10-25)% increased Movement Speed
]],[[
Greedtrap
Velvet Slippers
Source: No longer obtainable
Requires Level 52
+(5-10) to Strength
+(5-10) to Dexterity
+(5-10) to Intelligence
+(90-110) to maximum Energy Shield
(10-16)% increased Quantity of Items found when on Low Life
20% increased Movement Speed
]],[[
Scornflux
Satin Slippers
Source: Drops from unique{Mercenary} after winning a duel
League: Mercenaries of Trarthus
Requires Level 54
+(5-15) to Intelligence
+(40-70) to maximum Mana
+(5-15)% to all Elemental Resistances
Gain Arcane Surge when you use a Movement Skill
Increases to Cast Speed from Arcane Surge also applies to Movement Speed
]],
-- Boots: Armour/Evasion
[[
Beacon of Madness
{variant:1}Two-Toned Boots (Armour/Evasion)
{variant:2}Two-Toned Boots (Armour/Energy Shield)
{variant:3}Two-Toned Boots (Evasion/Energy Shield)
Variant: Two-Toned Boots (Armour/Evasion)
Variant: Two-Toned Boots (Armour/Energy Shield)
Variant: Two-Toned Boots (Evasion/Energy Shield)
League: Delirium
Implicits: 3
{variant:1}+(16-20)% to Fire and Cold Resistances
{variant:2}+(16-20)% to Fire and Lightning Resistances
{variant:3}+(16-20)% to Cold and Lightning Resistances
Grants Embrace Madness
{variant:3}(20-40)% increased Chaos Damage
{variant:1}(150-300)% increased Armour and Evasion
30% increased Movement Speed
{variant:2}(20-40)% increased Effect of Non-Damaging Ailments
{variant:3}All Damage inflicts Poison while affected by Glorious Madness
{variant:1}20% chance to deal Double Damage while affected by Glorious Madness
{variant:3}Enemies you Kill while affected by Glorious Madness have a 40% chance to Explode, dealing a quarter of their Life as Chaos Damage
{variant:2}You have Igniting, Chilling and Shocking Conflux while affected by Glorious Madness
{variant:2}Immune to Elemental Ailments while affected by Glorious Madness
{variant:1}+15 to maximum Fortification while affected by Glorious Madness
]],[[
Darkray Vectors
Dragonscale Boots
Variant: Pre 2.6.0
Variant: Pre 3.16.0
Variant: Current
{variant:2,3}(40-70)% increased Armour and Evasion
{variant:3}10% increased Evasion Rating per Frenzy Charge
+(20-40)% to Lightning Resistance
5% increased Movement Speed per Frenzy Charge
+1 to Maximum Frenzy Charges
{variant:1}50% reduced Frenzy Charge Duration
{variant:2,3}40% reduced Frenzy Charge Duration
25% reduced Light Radius
{variant:1,2}+2% chance to Suppress Spell Damage per Frenzy Charge
]],[[
Dusktoe
{variant:1}Leatherscale Boots
{variant:2,3,4}Ironscale Boots
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
{variant:1,2,3}(40-60)% increased Armour and Evasion
{variant:4}(60-100)% increased Armour and Evasion
{variant:1,2}+(10-20) to maximum Life
{variant:3}+(20-30) to maximum Life
{variant:1,2}+(10-20) to maximum Mana
{variant:1,2,3}15% increased Movement Speed
{variant:4}20% increased Movement Speed
{variant:1,2,3}50% increased Stun and Block Recovery
20% reduced Light Radius
+50% to Chaos Resistance during any Flask Effect
{variant:3}Adds (15-20) to (25-30) Chaos Damage to Spells and Attacks during any Flask Effect
{variant:4}Adds (30-40) to (50-60) Chaos Damage to Spells and Attacks during any Flask Effect
]],[[
Duskblight
Ironscale Boots
Source: No longer obtainable
Variant: Pre 3.11.0
Variant: Current
Requires Level 40
{variant:1}Socketed Gems are Supported by Level 15 Added Chaos Damage Support
{variant:2}Trigger Level 15 Stalking Pustule on Kill
(120-150)% increased Armour and Evasion
+(50-60) to maximum Life
20% increased Movement Speed
50% increased Stun and Block Recovery
20% reduced Light Radius
+50% to Chaos Resistance during any Flask Effect
{variant:2}Adds (30-40) to (50-60) Chaos Damage to Spells and Attacks during any Flask Effect
]],[[
Legacy of Fury
Wyrmscale Boots
Source: Drops from unique{The Maven}
Variant: Pre 3.17.0
Variant: Current
League: Ritual
Requires Level 69
(200-300)% increased Armour and Evasion
30% increased Movement Speed
{variant:2}Enemies within 3 metres are Scorched
{variant:1}Drops Scorched Ground while moving, lasting 4 seconds
(30-50)% increased Effect of Scorch
(30-40)% chance when you Kill a Scorched Enemy to Burn Each surrounding
Enemy for 4 seconds, dealing 8% of the Killed Enemy's Life as Fire Damage per second
{variant:1}-(15-10)% to all Elemental Resistances
]],[[
Annihilation's Approach
Dragonscale Boots
Variant: Pre 3.23.0
Variant: Current
Source: Drops from unique{The Searing Exarch} (Uber)
Grants Approaching Flames
(60-100)% increased Armour and Evasion
30% increased Movement Speed
Cannot be Chilled
Cannot be Frozen
{variant:1}Take 10000 Fire Damage per Second while Flame-Touched
{variant:2}Take 6000 Fire Damage per Second while Flame-Touched
Gain Adrenaline when you become Flame-Touched
Lose Adrenaline when you cease to be Flame-Touched
]],[[
Gamblesprint
Hydrascale Boots
League: Affliction
Source: Reward from Ultimatum encounters
+(30-40) to Dexterity
(100-150)% increased Armour and Evasion
+(20-40)% to Lightning Resistance
When Hit, gain a random Movement Speed modifier from 40% reduced to 100% increased, until Hit again
]],[[
Lioneye's Paws
Bronzescale Boots
League: Legion
Variant: Pre 3.7.0
Variant: Current
{variant:2}Trigger Level 5 Rain of Arrows when you Attack with a Bow
+(40-60) to Strength
+(40-60) to Dexterity
Adds 12 to 24 Fire Damage to Attacks
20% increased Movement Speed
40% reduced Movement Speed when on Low Life
{variant:1}20% increased Stun and Block Recovery
{variant:1}Cannot be Stunned when on Low Life
]],[[
Replica Lioneye's Paws
Bronzescale Boots
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Trigger Level 5 Toxic Rain when you Attack with a Bow
+(40-60) to Strength
+(40-60) to Dexterity
Adds 12 to 24 Chaos Damage to Attacks
20% increased Movement Speed
40% reduced Movement Speed when on Low Life
]],[[
Mutewind Whispersteps
Serpentscale Boots
League: Warbands
Variant: Pre 2.6.0
Variant: Current
{variant:1}Adds (15-19) to (28-35) Cold Damage to Spells
{variant:2}Adds (25-30) to (40-50) Cold Damage to Spells
{variant:1}(20-40)% increased Spell Critical Strike Chance
{variant:2}(50-70)% increased Spell Critical Strike Chance
(100-150)% increased Evasion Rating
+(20-30)% to Cold Resistance
{variant:1}20% increased Movement Speed
{variant:2}25% increased Movement Speed
Unaffected by Chilled Ground
]],[[
Saqawal's Talons
Hydrascale Boots
League: Bestiary
Source: Drops from unique{Saqawal, First of the Sky}
Grants Level 20 Aspect of the Avian
(100-150)% increased Armour and Evasion
(20-30)% increased Movement Speed
+(-2-2) seconds to Avian's Flight Duration
Regenerate 100 Life per Second while you have Avian's Flight
Regenerate 12 Mana per Second while you have Avian's Flight
]],
-- Boots: Armour/Energy Shield
[[
Alberon's Warpath
Soldier Boots
Variant: Pre 3.19.0
Variant: Current
(15-18)% increased Strength
Adds 1 to 80 Chaos Damage to Attacks
+(180-220) to Armour
{variant:1}+(9-12)% to Chaos Resistance
{variant:2}+(13-19)% to Chaos Resistance
{variant:1}20% increased Movement Speed
{variant:2}25% increased Movement Speed
{variant:1}+1 to maximum number of Skeletons
{variant:2}Summoned Skeleton Warriors are Permanent and Follow you
{variant:2}Summon Skeletons cannot Summon more than 1 Skeleton Warrior
]],[[
Replica Alberon's Warpath
Soldier Boots
Variant: Pre 3.19.0
Variant: Current
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
(15-18)% increased Strength
+(180-220) to Armour
{variant:1}+(9-12)% to Chaos Resistance
{variant:2}+(13-19)% to Chaos Resistance
{variant:1}20% increased Movement Speed
{variant:2}25% increased Movement Speed
Cannot deal non-Chaos Damage
Adds 1 to 80 Chaos Damage to Attacks per 80 Strength
]],[[
Death's Door
Crusader Boots
Source: Drops in The Eternal Labyrinth
+(20-40) to Strength
200% increased Armour and Energy Shield
+(10-15)% to all Elemental Resistances
25% increased Movement Speed
+1 to Maximum Endurance Charges
50% increased Elemental Ailment Duration on you
Bleeding cannot be inflicted on you
]],[[
Gang's Momentum
Legion Boots
Variant: Pre 2.6.0
Variant: Current
(160-180)% increased Armour and Energy Shield
+(50-60)% to Fire Resistance
25% increased Movement Speed
{variant:1}(5-7)% chance to Ignite
{variant:2}(10-15)% chance to Ignite
{variant:1}15% increased Damage with Hits and Ailments against Ignited Enemies
{variant:2}(25-40)% increased Damage with Hits and Ailments against Ignited Enemies
]],[[
March of the Legion
Legion Boots
Variant: Pre 3.17.0
Variant: Current
League: Synthesis
{variant:1}+2 to Level of Socketed Aura Gems
{variant:2}+(3-5) to Level of Socketed Aura Gems
Socketed Gems are Supported by Level 25 Divine Blessing Support
(250-300)% increased Armour and Energy Shield
+(12-18)% to all Elemental Resistances
(20-30)% increased Movement Speed
]],[[
Ralakesh's Impatience
Riveted Boots
Variant: Pre 3.19.0
Variant: Pre 3.26.0
Variant: Endurance Current
Variant: Frenzy Current
Variant: Power Current
+(15-25)% to Cold Resistance
+(15-25)% to Chaos Resistance
{variant:3,4,5}(15-25)% increased Movement Speed
{variant:3,4,5}Corrupted Blood cannot be inflicted on you
{variant:1,2,3}Count as having maximum number of Endurance Charges
{variant:1,2,4}Count as having maximum number of Frenzy Charges
{variant:1,2,5}Count as having maximum number of Power Charges
{variant:1}Gain a Frenzy, Endurance, or Power Charge once per second while you are Stationary
{variant:1}Lose all Frenzy, Endurance, and Power Charges when you Move
]],[[
Wake of Destruction
Mesh Boots
Variant: Pre 2.6.0
Variant: Pre 3.11.0
Variant: Current
Adds 1 to 120 Lightning Damage to Attacks
(20-60)% increased Armour and Energy Shield
Gain (10-20) Life per Enemy Killed
{variant:2,3}15% increased Movement Speed
{variant:1,2}10% chance to Cause Monsters to Flee
{variant:3}Drops Shocked Ground while moving, lasting 2 seconds
]],
-- Boots: Evasion/Energy Shield
[[
Brinerot Whalers
Trapper Boots
League: Warbands
Source: Drops from Brinerot Warband monsters
Variant: Pre 2.6.0
Variant: Pre 3.0.0
Variant: Current
20% increased Global Physical Damage
{variant:1}+(60-80) to maximum Energy Shield
{variant:2}+(120-150) to maximum Energy Shield
{variant:3}+(80-100) to maximum Energy Shield
+(20-30)% to Lightning Resistance
{variant:1}20% increased Movement Speed
{variant:2,3}25% increased Movement Speed
(20-40)% increased Projectile Damage
Unaffected by Shocked Ground
]],[[
Bubonic Trail
Murder Boots
League: Abyss
Source: Drops from unique{Amanamu, Liege of the Lightless} or unique{Ulaman, Sovereign of the Well}
Variant: One Abyssal Socket (Pre 3.21.0)
Variant: Two Abyssal Sockets (Pre 3.21.0)
Variant: One Abyssal Socket (Current)
Variant: Two Abyssal Sockets (Current)
{variant:1,3}Has 1 Abyssal Socket
{variant:2,4}Has 2 Abyssal Sockets
Triggers Level 20 Death Walk when Equipped
{variant:1,2}(4-6)% increased maximum Life
{variant:1,2}30% increased Movement Speed
{variant:1,2}10% increased Damage for each type of Abyss Jewel affecting you
{variant:3,4}(40-60)% reduced Duration of Elemental Ailments on You while affected by a Rare Abyss Jewel
{variant:3,4}(24-32)% increased Movement Speed while affected by a Magic Abyss Jewel
{variant:3,4}(16-24)% increased Reservation Efficiency of Skills while affected by a Unique Abyss Jewel
]],[[
Corpsewalker
Carnal Boots
Variant: Pre 3.19.0
Variant: Current
League: Heist
Implicits: 0
Triggers Level 20 Corpse Walk when Equipped
(80-120)% increased Evasion and Energy Shield
25% increased Movement Speed
{variant:1}(20-40)% increased Damage if you have Consumed a corpse Recently
{variant:2}For each corpse within 6 metres, Regenerate 8 Life per second
{variant:1}For each corpse within 6 metres, Regenerate 0.25% Life per second, up to 3%
{variant:2}For each corpse within 6 metres, 1% increased Movement Speed
]],[[
Dance of the Offered
{variant:1}Shackled Boots
{variant:2}Carnal Boots
Variant: Pre 3.14.0
Variant: Current
League: Incursion
Source: Opening normal{Thunder Coffer} in normal{Conduit of Lightning}
Upgrade: Upgrades to unique{Omeyocan} via currency{Vial of the Ritual}
+(50-60) to maximum Mana
{variant:1}+(15-20)% to Lightning Resistance
{variant:2}+(25-30)% to Lightning Resistance
25% increased Movement Speed
You have Onslaught while not on Low Mana
{variant:1}Lose (30-40) Mana per Second
{variant:2}The Agnostic
]],[[
Omeyocan
Carnal Boots
Variant: Pre 3.16.0
Variant: Pre 3.26.0
Variant: Current
League: Incursion
Source: Upgraded from unique{Dance of the Offered} via currency{Vial of the Ritual}
(15-20)% increased maximum Mana
+(25-30)% to Lightning Resistance
30% increased Movement Speed
{variant:1}2% increased Evasion Rating per 500 Maximum Mana
{variant:2}10% increased Evasion Rating per 500 Maximum Mana
{variant:3}20% increased Evasion Rating per 500 Maximum Mana
You have Onslaught while not on Low Mana
Lose 7% of Mana per Second
]],[[
Fenumus' Spinnerets
Assassin's Boots
League: Bestiary
Source: Drops from unique{Fenumus, First of the Night}
(160-200)% increased Evasion and Energy Shield
+(20-30)% to Lightning Resistance
+(17-23)% to Chaos Resistance
25% increased Movement Speed
Aspect of the Spider can inflict Spider's Web on Enemies an additional time
Gain (15-20) Energy Shield for each Enemy you Hit which is affected by a Spider's Web
(40-50)% increased Aspect of the Spider Debuff Duration
]],[[
Inextricable Fate
Fugitive Boots
Source: Drops from unique{The Eater of Worlds}
Implicits: 1
+(17-23)% to Chaos Resistance
+(80-100) to maximum Life
30% increased Movement Speed
You gain 3 Grasping Vines when you take a Critical Strike
Stationary Enemies within 6 metres gain a Grasping Vine every 0.5 seconds
All Damage inflicts Poison against Enemies affected by at least 3 Grasping Vines
You take (30-50)% reduced Extra Damage from Critical Strikes by Poisoned Enemies
]],[[
Nomic's Storm
Strapped Boots
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Current
+(20-30) to Dexterity
+(30-50) to Evasion Rating
+(15-30) to maximum Energy Shield
+20% to Cold Resistance
20% increased Movement Speed
{variant:1}30% increased Physical Damage taken
{variant:2}20% increased Physical Damage taken
{variant:3}15% increased Damage taken while on Full Energy Shield
20% increased Movement Speed while on Full Energy Shield
]],[[
The Stampede
Assassin's Boots
League: Blight
Source: Drops in Blighted Maps
(100-150)% increased Evasion and Energy Shield
(30-40)% increased Stun and Block Recovery
(50-80)% increased Cooldown Recovery Rate of Travel Skills
(30-40)% increased Mana Regeneration Rate while moving
Your Movement Speed is 150% of its base value
This item can be anointed by Cassia
]],[[
Replica Stampede
Assassin's Boots
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Socketed Travel Skills deal 80% more Damage
(100-150)% increased Evasion and Energy Shield
(30-40)% increased Stun and Block Recovery
(30-40)% increased Mana Regeneration Rate while moving
Your Movement Speed is 150% of its base value
This item can be anointed by Cassia
]],[[
Sundance
Clasped Boots
Variant: Pre 2.6.0
Variant: Current
10% increased Attack Speed
(80-120)% increased Evasion Rating
+(20-30)% to Item Rarity
+(30-40)% to Fire Resistance
{variant:1}10% increased Movement Speed
{variant:2}20% increased Movement Speed
]],[[
Sunspite
Clasped Boots
Source: No longer obtainable
Requires Level 59
10% increased Attack Speed
(260-300)% increased Evasion and Energy Shield
+(20-30)% to Item Rarity
+(30-40)% to Fire Resistance
20% increased Movement Speed
(10-20)% increased Movement Speed while Ignited
+25% chance to be Ignited
Regenerate (75-125) Life per second while Ignited
]],[[
Veruso's Ambition
Shackled Boots
League: Necropolis
Grants Ravenous
Enemies display their Monster Category
(80-120)% increased Evasion and Energy Shield
+(13-23)% to Chaos Resistance
(20-30)% increased Movement Speed
]],[[
Voidwalker
Murder Boots
Shaper Item
Source: Drops from unique{The Shaper}
Variant: Pre 3.0.0
Variant: Current
+(30-50) to Dexterity
(140-180)% increased Evasion and Energy Shield
30% increased Movement Speed
20% chance to Avoid Projectiles while Phasing
You have Phasing if you've Killed Recently
{variant:1}Projectiles Pierce all Targets while you have Phasing
{variant:2}Projectiles Pierce 5 additional Targets while you have Phasing
Celestial Footprints
]],[[
Replica Voidwalker
Murder Boots
Shaper Item
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
+(30-50) to Dexterity
(140-180)% increased Evasion and Energy Shield
30% increased Movement Speed
10% increased Damage taken while Phasing
You have Phasing if you've Killed Recently
Projectiles Chain +1 times while you have Phasing
Celestial Footprints
]],
-- Boots: Ward
[[
Olroth's Charge
Runic Sollerets
League: Expedition
Source: Drops from Expedition monsters
(50-80)% increased Ward
(30-50)% slower Restoration of Ward
20% increased Movement Speed
Gain Adrenaline for 3 seconds when Ward Breaks
]],
}
