-- Item data (c) Grinding Gear Games

return {
-- Body: Armour
[[
Blunderbore
Astral Plate
League: Heist
Implicits: 1
+(8-12)% to all Elemental Resistances
+(500-700) Strength Requirement
(80-120)% increased Armour
(50-75)% increased Effect of Shrine Buffs on you
You have Lesser Brutal Shrine Buff
You have Lesser Massive Shrine Buff
]],[[
Bramblejack
Plate Vest
Variant: Pre 3.19.0
Variant: Current
Implicits: 0
{variant:1}Adds 2 to 4 Physical Damage to Attacks
{variant:1}+(12-20) to maximum Life
{variant:2}+(30-60) to maximum Life
{variant:1}-2 Physical Damage taken from Attack Hits
{variant:2}-(15-10) Physical Damage taken from Attack Hits
{variant:1}40% of Melee Physical Damage taken reflected to Attacker
{variant:2}1000% of Melee Physical Damage taken reflected to Attacker
]],[[
Wall of Brambles
Plate Vest
Source: No longer obtainable
Requires Level 30
Implicits: 0
Adds 2 to 4 Physical Damage to Attacks
+2000 to Armour
+(12-20) to maximum Life
-2 Physical Damage taken from Attack Hits
40% of Melee Physical Damage taken reflected to Attacker
]],[[
The Brass Dome
Gladiator Plate
Variant: Pre 3.16.0
Variant: Current
Implicits: 0
{variant:1}30% reduced Chance to Block Attack and Spell Damage
{variant:1}(600-650)% increased Armour
{variant:2}(350-400)% increased Armour
{variant:2}+(1-5)% to all maximum Elemental Resistances
{variant:1}10% reduced Movement Speed
{variant:1}50% increased Shock Duration on you
{variant:2}Strength provides no bonus to Maximum Life
Take no Extra Damage from Critical Strikes
]],[[
Craiceann's Carapace
Golden Plate
Variant: Pre 3.16.0
Variant: Current
League: Bestiary
Source: Drops from unique{Craiceann, First of the Deep}
Requires Level 64
Implicits: 0
Grants Level 20 Aspect of the Crab
{variant:1}(300-350)% increased Armour
{variant:2}(200-250)% increased Armour
+(100-120) to maximum Life
+(25-30)% to Fire and Cold Resistances
Bleeding cannot be inflicted on you
+5 to Maximum number of Crab Barriers
]],[[
Death's Oath
Astral Plate
Variant: Pre 2.0.0
Variant: Pre 3.0.0
Variant: Current
Implicits: 1
+(8-12)% to all Elemental Resistances
{variant:3}Trigger Level 20 Death Aura when Equipped
+(40-50) to all Attributes
(10-15)% increased Attack Speed
(180-220)% increased Armour
{variant:3}+(60-70) to maximum Life
1% of Attack Damage Leeched as Life
{variant:1,2}Deals 450 Chaos Damage per second to Enemies within 3 metres
{variant:1}You take 450 Chaos Damage per second for 0 seconds on Kill
{variant:2,3}You take 450 Chaos Damage per second for 3 seconds on Kill
Gore Footprints
]],[[
Doppelgänger Guise
Sadist Garb
Variant: Pre 3.17.0
Variant: Current
League: Ritual
Source: Drops from unique{The Maven}
Implicits: 0
Grants Unhinge
(40-60)% more Critical Strike Chance while Insane
Enemies Killed by your Hits are destroyed while Insane
{variant:1}(15-25)% more Physical and Chaos Damage Taken while Sane
{variant:2}(30-40)% less Physical and Chaos Damage Taken while Sane
Regenerate 10% Life over one second when Hit while Sane
]],[[
Greed's Embrace
Golden Plate
Variant: Pre 3.25.0
Variant: Current
Implicits: 0
30% reduced Strength Requirement
{variant:1}(10-15)% increased Quantity of Items found
{variant:1}+(30-50)% to Item Rarity
{variant:2}+100% to Item Rarity
-10% to Fire Resistance
+(20-30)% to Cold Resistance
{variant:1}-20% to Lightning Resistance
{variant:2}-(20-10)% to Lightning Resistance
20% reduced Movement Speed
]],[[
Kaom's Heart
Glorious Plate
Variant: Pre 1.0.0
Variant: Pre 3.25.0
Variant: Current
Implicits: 0
Has no Sockets
{variant:2}(20-40)% increased Fire Damage
{variant:1,3}+1000 to maximum Life
{variant:2}+500 to maximum Life
]],[[
Replica Kaom's Heart
Glorious Plate
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 0
Has no Sockets
(30-40)% increased Lightning Damage
+500 to maximum Mana
]],[[
Lioneye's Vision
Crusader Plate
Variant: Pre 3.5.0
Variant: Current
Implicits: 0
Socketed Gems are Supported by Level 15 Pierce Support
{variant:2}+160 Dexterity Requirement
(200-250)% increased Armour
+(60-100) to maximum Life
0.4% of Physical Attack Damage Leeched as Mana
Enemy Projectiles Pierce you
]],[[
Iron Heart
Crusader Plate
Source: No longer obtainable
Implicits: 0
(8-12)% Chance to Block Attack Damage
(80-100)% increased Armour
10% reduced Movement Speed
Cannot Block Spell Damage
Strength's Damage Bonus instead grants 3% increased Melee
Physical Damage per 10 Strength
]],[[
The Iron Fortress
Crusader Plate
Implicits: 0
+1% Chance to Block Attack Damage per 50 Strength
Chance to Block Spell Damage is Unlucky
+(60-120) to Strength
(80-100)% increased Armour
10% reduced Movement Speed
Strength's Damage Bonus instead grants 3% increased Melee
Physical Damage per 10 Strength
]],[[
Perfidy
Glorious Plate
League: Delirium
Variant: Pre 3.25.0
Variant: Current
Implicits: 0
Having a placed Banner does not prevent you gaining Valour
(25-40)% increased Melee Damage
+(60-90) to maximum Life
{variant:2}(25-50)% increased Valour gained
]],[[
Pragmatism
Colosseum Plate
League: Affliction
Source: unique{The King in the Mists} in the normal{Crux of Nothingness}
+12 to Level of Socketed Skill Gems
(80-120)% increased Armour
+(60-100) to maximum Mana
-2 to level of Socketed Skill Gems per Socketed Gem
]],[[
Solaris Lorica
Copper Plate
Variant: Pre 2.6.0
Variant: Current
Implicits: 0
+(10-20) to Strength
(60-80)% increased Armour
{variant:2}25% reduced Chaos Damage taken over time
25% increased Light Radius
Chaos Damage taken does not bypass Energy Shield
{variant:1}-10 Chaos Damage taken
{variant:2}-(30-40) Chaos Damage taken
]],[[
Utula's Hunger
Majestic Plate
(60-100)% increased Armour
Recover (1-3)% of Life on Kill
(30-40)% increased Stun and Block Recovery
+(700-1000) to maximum Life if there are no Life Modifiers on other Equipped Items
]],
-- Body: Evasion
[[
Ashrend
Buckskin Tunic
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 0
{variant:2}Socketed Gems are Supported by Level 10 Added Fire Damage Support
(80-100)% increased Evasion Rating
{variant:2}+(30-50) to maximum Life
+(40-50)% to Fire Resistance
Cannot be Ignited
{variant:1,2}(10-15)% increased Physical Damage with Ranged Weapons
{variant:3}(75-150)% increased Physical Damage with Ranged Weapons
{variant:1,2}-(5-7) Physical Damage taken from Attack Hits
{variant:3}-(60-30) Physical Damage taken from Attack Hits
]],[[
Briskwrap
{variant:1,2,3}Strapped Leather
{variant:4}Sun Leather
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 0
{variant:1}5% increased Dexterity
{variant:2,3,4}15% increased Dexterity
{variant:1,2}5% increased Attack Speed
{variant:3}10% increased Attack Speed
+(120-180) to Evasion Rating
+(30-40)% to Cold Resistance
{variant:1,2,3}5% increased Movement Speed
{variant:1,2,3}(20-25)% increased Mana Recovery from Flasks
{variant:4}(60-100)% increased Mana Recovery from Flasks
{variant:4}1% increased Damage per 15 Dexterity
]],[[
Wildwrap
Strapped Leather
Source: No longer obtainable
Requires Level 57
Implicits: 0
15% increased Dexterity
10% increased Attack Speed
+(600-700) to Evasion Rating
+(30-40)% to Cold Resistance
5% increased Movement Speed
(20-25)% increased Mana Recovery from Flasks
1% increased Damage per 15 Dexterity
]],[[
Bronn's Lithe
Cutthroat's Garb
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 0
{variant:1,2,3}+2 to Level of Socketed Movement Gems
{variant:4}+5 to Level of Socketed Movement Gems
10% increased Attack Speed
{variant:2,3}(35-50)% increased Damage with Movement Skills
{variant:4}(60-100)% increased Damage with Movement Skills
(200-250)% increased Evasion Rating
10% increased Movement Speed
{variant:3}15% increased Attack and Cast Speed if you've used a Movement Skill Recently
]],[[
Cospri's Will
Assassin's Garb
Variant: Pre 3.0.0
Variant: Pre 3.20.0
Variant: Current
Implicits: 1
3% increased Movement Speed
{variant:1,2}(120-160)% increased Evasion Rating
{variant:3}(150-200)% increased Evasion Rating
{variant:1,2}+(17-29)% to Chaos Resistance
{variant:3}+(31-53)% to Chaos Resistance
You can apply an additional Curse
Your Hexes can affect Hexproof Enemies
{variant:1,3}Always Poison on Hit against Cursed Enemies
{variant:2}60% chance to Poison on Hit against Cursed Enemies
]],[[
Foxshade
Wild Leather
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 0
+(20-30) to Dexterity
{variant:1,2}Adds 5 to 12 Physical Damage to Attacks
{variant:1}+150 to Evasion Rating while on Full Life
{variant:2}+500 to Evasion Rating while on Full Life
{variant:3}+1000 to Evasion Rating while on Full Life
(50-70)% increased Evasion Rating
{variant:1,2}10% increased Movement Speed
{variant:3}30% increased Movement Speed when on Full Life
{variant:3}Damage of Enemies Hitting you is Unlucky while you are on Full Life
]],[[
Fox's Fortune
Wild Leather
Source: No longer obtainable
Requires Level 54
Implicits: 0
+(20-30) to Dexterity
Adds 5 to 12 Physical Damage to Attacks
+(400-500) to Evasion Rating
+1500 to Evasion Rating while on Full Life
(120-150)% increased Evasion Rating
10% increased Movement Speed
Damage of Enemies Hitting you is Unlucky while you are on Full Life
]],[[
Hyrri's Ire
Zodiac Leather
Variant: Pre 1.0.0
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.5.0
Variant: Pre 3.9.0
Variant: Current
Implicits: 0
{variant:3,4,5,6}+30% chance to Suppress Spell Damage
{variant:1,2,3}+(20-30) to Dexterity
{variant:4,5,6}+(40-50) to Dexterity
{variant:1}(80-120)% increased Evasion Rating
{variant:2,3,4,5,6}(140-220)% increased Evasion Rating
25% increased Chill Duration on Enemies
{variant:1,2,3}13 to 24 Added Cold Damage with Bow Attacks
{variant:4}(50-60) to (70-80) Added Cold Damage with Bow Attacks
{variant:5}(173-188) to (240-262) Added Cold Damage with Bow Attacks
{variant:6}(105-145) to (160-200) Added Cold Damage with Bow Attacks
{variant:1,2}Acrobatics
]],[[
Replica Hyrri's Ire
Zodiac Leather
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
+30% chance to Suppress Spell Damage
+(40-50) to Intelligence
(140-220)% increased Evasion Rating
25% increased Shock Duration on Enemies
(12-18) to (231-347) Added Lightning Damage with Wand Attacks
]],[[
Kintsugi
Exquisite Leather
Variant: Pre 3.19.0
Variant: Pre 3.26.0
Variant: Current
Implicits: 0
{variant:1}(100-120)% increased Evasion Rating
{variant:2}(120-160)% increased Evasion Rating
{variant:3}(160-220)% increased Evasion Rating
{variant:1}+(60-80) to maximum Life
+(30-50)% to Fire Resistance
{variant:1}20% less Damage taken if you have not been Hit Recently
{variant:2,3}35% less Damage taken if you have not been Hit Recently
{variant:1}50% increased Evasion Rating if you have been Hit Recently
{variant:2,3}100% increased Evasion Rating if you have been Hit Recently
]],[[
Queen of the Forest
Destiny Leather
Variant: Pre 3.1.0
Variant: Current
Implicits: 0
{variant:1}(240-380)% increased Evasion Rating
{variant:2}(200-240)% increased Evasion Rating
+(60-70) to maximum Life
+(6-10)% to Fire Resistance
+(26-40)% to Cold Resistance
+(11-25)% to Lightning Resistance
25% reduced Movement Speed
1% increased Movement Speed per 600 Evasion Rating, up to 75%
-(50-40) Physical Damage taken from Hits by Animals
]],[[
The Rat Cage
Sharkskin Tunic
League: Torment
Variant: Pre 2.6.0
Variant: 3.19.0
Variant: Current
Implicits: 0
(100-120)% increased Evasion Rating
{variant:1,2}+(160-200) to maximum Life
{variant:3}+(200-300) to maximum Life
{variant:1}-5% to maximum Fire Resistance
{variant:2}-50% to Fire Resistance
15% increased Movement Speed
{variant:1,2}20% increased Fire Damage taken
{variant:1,2}10% of Fire Damage from Hits taken as Physical Damage
{variant:3}100% of Fire Damage from Hits taken as Physical Damage
]],[[
The Snowblind Grace
{variant:1,2}Coronal Leather
{variant:3}Zodiac Leather
League: Breach
Source: Drops in Tul Breach or from unique{Tul, Creeping Avalanche}
Upgrade: Upgrades to unique{The Perfect Form} using currency{Blessing of Tul}
Variant: Pre 3.16.0
Variant: Pre 3.21.0
Variant: Current
Implicits: 0
{variant:1}+10% chance to Suppress Spell Damage
{variant:2}+20% chance to Suppress Spell Damage
{variant:1,2}+(30-40) to Dexterity
{variant:3}(10-15)% increased Dexterity
{variant:1}(30-50)% increased Evasion Rating
{variant:2,3}(80-100)% increased Evasion Rating
+(40-60) to maximum Life
{variant:1,2}25% increased Arctic Armour Buff Effect
{variant:3}50% increased Arctic Armour Buff Effect
{variant:3}Arctic Armour has no Reservation
{variant:1,2}Evasion Rating is increased by Overcapped Cold Resistance
]],[[
The Perfect Form
Zodiac Leather
League: Breach
Source: Upgraded from unique{The Snowblind Grace} using currency{Blessing of Tul}
Variant: Pre 3.16.0
Variant: Pre 3.21.0
Variant: Current
Implicits: 0
{variant:3}+50% chance to Suppress Spell Damage
{variant:1}(5-10)% increased Dexterity
{variant:2}(10-15)% increased Dexterity
{variant:1}(30-50)% increased Evasion Rating
{variant:2}(80-100)% increased Evasion Rating
{variant:3}(150-200)% increased Evasion Rating
{variant:1}+(50-80) to maximum Life
{variant:2}+(70-100) to maximum Life
-30% to Cold Resistance
{variant:1,2}Arctic Armour has no Reservation
Evasion Rating is increased by Overcapped Cold Resistance
Acrobatics
]],[[
Replica Perfect Form
Zodiac Leather
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Variant: Pre 3.16.0
Variant: Pre 3.21.0
Variant: Pre 3.23.0
Variant: Current
Implicits: 0
{variant:4}20% Chance to Block Attack Damage
{variant:1}(5-10)% increased Dexterity
{variant:2,3}(10-15)% increased Dexterity
{variant:1}(30-50)% increased Evasion Rating
{variant:2}(80-100)% increased Evasion Rating
{variant:3,4}(150-200)% increased Evasion Rating
{variant:1}+(50-80) to maximum Life
{variant:2,3}+(70-100) to maximum Life
-30% to Cold Resistance
{variant:1,2,3,4}Evasion Rating is increased by Overcapped Cold Resistance
{variant:3}Flesh and Stone has no Reservation
{variant:3}Hollow Palm Technique
{variant:4}Versatile Combatant
]],[[
Yriel's Fostering
Exquisite Leather
Variant: Rhoa Pre 3.26
Variant: Snake Pre 3.26
Variant: Ursa Pre 3.26
Variant: Rhoa Current
Variant: Snake Current
Variant: Ursa Current
Implicits: 0
{variant:1,4}Grants Summon Bestial Rhoa
{variant:2,5}Grants Summon Bestial Snake
{variant:3,6}Grants Summon Bestial Ursa
+(300-400) to Accuracy Rating
(130-150)% increased Evasion Rating
+(90-100) to maximum Life
Projectile Attack Skills have (40-60)% increased Critical Strike Chance
{variant:3}Adds (11-16) to (21-25) Physical Damage to Attacks while you have a Bestial Minion
{variant:6}Adds (18-24) to (30-36) Physical Damage to Attacks while you have a Bestial Minion
{variant:2}Adds (13-19) to (23-29) Chaos Damage to Attacks while you have a Bestial Minion
{variant:5}Adds (23-31) to (37-47) Chaos Damage to Attacks while you have a Bestial Minion
{variant:1}(10-15)% increased Attack and Movement Speed while you have a Bestial Minion
{variant:4}(10-20)% increased Attack and Movement Speed while you have a Bestial Minion
{variant:1}Projectiles from Attacks have 20% chance to Maim on Hit while you have a Bestial Minion
{variant:4}Projectiles from Attacks have 100% chance to Maim on Hit while you have a Bestial Minion
{variant:2}Projectiles from Attacks have 20% chance to Poison on Hit while you have a Bestial Minion
{variant:5}Projectiles from Attacks have 100% chance to Poison on Hit while you have a Bestial Minion
{variant:3}Projectiles from Attacks have 20% chance to inflict Bleeding on Hit while you have a Bestial Minion
{variant:6}Projectiles from Attacks have 100% chance to inflict Bleeding on Hit while you have a Bestial Minion
]],
-- Body: Energy Shield
[[
The Apostate
Cabalist Regalia
Source: Drops from unique{Synthete Nightmare} in normal{The Cortex} (Uber)
+(30-50) to Strength
+(20-30)% to all Elemental Resistances
Gain Maximum Life instead of Maximum Energy Shield from Equipped Armour Items
]],[[
The Beast Fur Shawl
Vaal Regalia
Variant: Pre 3.0.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 0
40% increased Spell Damage
{variant:1}+(55-65) to maximum Energy Shield
{variant:2}+(15-25) to maximum Energy Shield
{variant:1,2}(110-130)% increased Energy Shield
{variant:3}(120-160)% increased Energy Shield
{variant:1,2}(30-40)% increased Energy Shield Recovery rate
{variant:3}(50-100)% increased Energy Shield Recovery rate
10% increased Area of Effect
{variant:1,2}5% increased Damage taken
{variant:3}10% increased Damage taken
]],[[
Cloak of Flame
Scholar's Robe
Variant: Pre 3.19.0
Variant: Current
Implicits: 0
{variant:1}+(30-50)% to Fire Resistance
{variant:2}+(50-75)% to Fire Resistance
{variant:1}(30-50)% increased Ignite Duration on Enemies
{variant:2}(40-75)% increased Ignite Duration on Enemies
{variant:1}10% chance to Ignite
{variant:1}Reflects 15 Fire Damage to Melee Attackers
{variant:2}Reflects 100 Fire Damage to Melee Attackers
{variant:1}20% of Physical Damage from Hits taken as Fire Damage
{variant:2}40% of Physical Damage taken as Fire Damage
]],[[
Cloak of Tawm'r Isley
Savant's Robe
Source: Drops from unique{Elreon, Light's Judge} during Betrayal encounters
Variant: Pre 3.0.0
Variant: Current
Implicits: 0
Socketed Minion Gems are Supported by Level 16 Life Leech
{variant:1}(250-300)% increased Energy Shield
{variant:2}(150-200)% increased Energy Shield
Minions cannot be Blinded
Minions have 15% chance to Blind Enemies on hit
Found Magic Items drop Identified
]],[[
The Coming Calamity
Destroyer Regalia
Implicits: 0
+2 to Level of Socketed Herald Gems
(80-100)% increased Energy Shield
35% chance to avoid being Stunned for each Herald Buff affecting you
Mana Reservation of Herald Skills is always 45%
]],[[
The Covenant
Spidersilk Robe
Variant: Pre 1.0.0
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.0.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 0
{variant:1,2,3,4,5}Socketed Gems are Supported by Level 15 Added Chaos Damage Support
{variant:6}Socketed Gems are Supported by Level 29 Added Chaos Damage Support
{variant:4,5}Socketed Gems Cost and Reserve Life instead of Mana
+(20-30) to Intelligence
{variant:1}(125-150)% increased Energy Shield
{variant:2}(180-220)% increased Energy Shield
{variant:3,4}(280-320)% increased Energy Shield
{variant:5,6}(210-250)% increased Energy Shield
{variant:1,2,3}20% reduced maximum Life
{variant:4,5,6}10% increased maximum Life
{variant:6}Skills gain a Base Life Cost equal to 100% of Base Mana Cost
{variant:1,2,3}Blood Magic
]],[[
Replica Covenant
Spidersilk Robe
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Socketed Gems are Supported by Level 29 Added Cold Damage Support
+(20-30) to Intelligence
(210-250)% increased Energy Shield
10% increased maximum Life
Skills gain a Base Energy Shield Cost equal to 200% of Base Mana Cost
]],[[
Dialla's Malefaction
Sage's Robe
Variant: Pre 3.19.0
Variant: Current
Implicits: 0
{variant:1}Gems Socketed in Red Sockets have +1 to Level
{variant:2}Gems Socketed in Red Sockets have +2 to Level
{variant:1}Gems Socketed in Green Sockets have +10% to Quality
{variant:2}Gems Socketed in Green Sockets have +20% to Quality
{variant:1}Gems Socketed in Blue Sockets gain 25% increased Experience
{variant:2}Gems Socketed in Blue Sockets gain 100% increased Experience
Gems Socketed always have the Quality bonus from Socket Colour
Has no Attribute Requirements
]],[[
Doedre's Skin
Widowsilk Robe
Variant: Pre 3.5.0
Variant: Pre 3.16.0
Variant: Current
Implicits: 0
Socketed Gems are Supported by Level 20 Blasphemy Support
{variant:1,2}Grants Level 20 Summon Doedre's Effigy Skill
{variant:1,2}Socketed Hex Curse Skills are Triggered by Doedre's Effigy when Summoned
{variant:1,2}Hexes from Socketed Skills can apply 5 additional Curses
{variant:1,2}20% less Effect of Curses from Socketed Hex Skills
{variant:3}Grants Level 20 Summon Doedre's Effigy Skill
{variant:3}Socketed Hex Curse Skills are Triggered by Doedre's Effigy when Summoned
{variant:3}Hexes from Socketed Skills can apply 5 additional Curses
+(30-40) to Intelligence
(130-150)% increased Energy Shield
{variant:1}(25-33)% reduced Effect of your Curses
{variant:3}20% less Effect of your Curses
]],[[
Fenumus' Shroud
Widowsilk Robe
League: Bestiary
Source: Drops from unique{Fenumus, First of the Night}
Requires Level 67
Implicits: 0
+(30-40) to Intelligence
(120-140)% increased Energy Shield
Regenerate (80-100) Energy Shield per second
Enemies affected by your Spider's Webs deal 10% reduced Damage
Enemies affected by your Spider's Webs have -10% to All Resistances
(50-70)% increased Aspect of the Spider Area of Effect
]],[[
Fleshcrafter
Necromancer Silks
League: Harvest
Implicits: 0
(100-150)% increased Energy Shield
Chaos Damage taken does not bypass Minions' Energy Shield
Minions have (50-100)% faster start of Energy Shield Recharge
While Minions have Energy Shield, their Hits Ignore Monster Elemental Resistances
Minions Convert 2% of their Maximum Life to Maximum Energy Shield per 1% Chaos Resistance they have
]],[[
Garb of the Ephemeral
Savant's Robe
League: Synthesis
Source: Drops from unique{Synthete Nightmare} in normal{The Cortex}
Implicits: 0
+600 Strength and Intelligence Requirement
{fractured}(180-230)% increased Energy Shield
+10 to maximum Divine Charges
Gain a Divine Charge on Hit
You gain Divinity for 10 seconds on reaching maximum Divine Charges
Lose all Divine Charges when you gain Divinity
Allies within 5 metres cannot have their Action Speed modified to below Base Value
Enemies within 6 metres cannot deal Critical Strikes
]],[[
Infernal Mantle
{variant:1}Occultist's Vestment
{variant:2,3,4,5}Widowsilk Robe
Variant: Pre 2.0.0
Variant: Pre 3.0.0
Variant: Pre 3.14.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 1
{variant:1}(3-10)% increased Spell Damage
{variant:1,2,3,4}+1 to Level of Socketed Fire Gems
{variant:5}+3 to Level of Socketed Fire Gems
{variant:1,2,3,4}(25-35)% increased Fire Damage
100% increased Global Critical Strike Chance
{variant:1,2}(190-230)% increased Energy Shield
{variant:3,4,5}(120-160)% increased Energy Shield
15% of Fire Damage Converted to Chaos Damage
{variant:1,2,5}100% increased Spell Damage taken when on Low Mana
{variant:3}25% increased Spell Damage taken when on Low Mana
{variant:4}15% increased Spell Damage taken when on Low Mana
]],[[
Shavronne's Wrappings
Occultist's Vestment
Variant: Pre 1.0.0
Variant: Pre 3.0.0
Variant: Current
Implicits: 1
(3-10)% increased Spell Damage
{variant:1}(200-250)% increased Energy Shield
{variant:2}(140-200)% increased Energy Shield
{variant:3}(150-200)% increased Energy Shield
10% faster start of Energy Shield Recharge
+(30-40)% to Lightning Resistance
Reflects 1 to 250 Lightning Damage to Melee Attackers
Chaos Damage taken does not bypass Energy Shield
]],[[
Skin of the Loyal
Simple Robe
League: Breach
Source: Drops in Chayula Breach or from unique{Chayula, Who Dreamt}
Upgrade: Upgrades to unique{Skin of the Lords} using currency{Blessing of Chayula}
Implicits: 0
Sockets cannot be modified
+1 to Level of Socketed Gems
100% increased Global Defences
]],[[
Soul Mantle
Spidersilk Robe
Variant: Pre 1.2.0
Variant: Pre 2.6.0
Variant: Pre 3.16.0
Variant: Pre 3.17.0
Variant: Current
Implicits: 0
{variant:1,2}Socketed Gems are Supported by Level 14 Spell Totem Support
{variant:3,4,5}Socketed Gems are Supported by Level 20 Spell Totem Support
(20-25)% increased Spell Damage
(100-120)% increased Energy Shield
{variant:1}25% increased Totem Life
{variant:2,3}50% increased Totem Life
{variant:4,5}(20-30)% increased Totem Life
{variant:1,2,3,4}+1 to maximum number of Summoned Totems
Inflicts a random Hex on you when your Totems die
]],[[
Tabula Rasa
Simple Robe
Sockets: W-W-W-W-W-W
]],[[
Thousand Ribbons
Simple Robe
Variant: Pre 3.0.0
Variant: Pre 3.19.0
Variant: Current
Socketed Gems are Supported by Level 5 Elemental Proliferation Support
{variant:1,2}Adds 2 to 3 Fire Damage to Spells and Attacks
{variant:3}Adds (2-4) to (5-9) Fire Damage to Spells and Attacks
{variant:1,2}Adds 2 to 3 Cold Damage to Spells and Attacks
{variant:3}Adds (2-4) to (5-9) Cold Damage to Spells and Attacks
{variant:1,2}Adds 1 to 4 Lightning Damage to Spells and Attacks
{variant:3}Adds 1 to (4-12) Lightning Damage to Spells and Attacks
{variant:1}10% reduced Cast Speed
{variant:1,2}+(10-20) to Evasion Rating
{variant:3}+(30-60) to Evasion Rating
{variant:1,2}+(10-20) to maximum Energy Shield
{variant:3}+(30-60) to maximum Energy Shield
{variant:1,2}+6 to maximum Life
{variant:3}+(25-50) to maximum Life
{variant:1,2}+6 to maximum Mana
{variant:3}+(25-50) to maximum Mana
{variant:1,2}+(5-10)% to Fire Resistance
{variant:3}+(15-30)% to Fire Resistance
{variant:1,2}+(5-10)% to Cold Resistance
{variant:3}+(15-30)% to Cold Resistance
{variant:1,2}+(5-10)% to Lightning Resistance
{variant:3}+(15-30)% to Lightning Resistance
]],[[
Vis Mortis
Necromancer Silks
Variant: Pre 2.6.0
Variant: Pre 3.8.0
Variant: Current
Implicits: 0
{variant:1}(100-120)% increased Energy Shield
{variant:2,3}(200-220)% increased Energy Shield
+(20-30) to maximum Mana
Minions have 20% reduced maximum Life
Minions deal 15% increased Damage
{variant:1,2}+1 to maximum number of Spectres
{variant:1}Minions gain Unholy Might for 5 seconds on Kill
{variant:2}Minions gain Unholy Might for 10 seconds on Kill
{variant:3}Minions gain (15-20)% of Elemental Damage as Extra Chaos Damage
]],[[
Zahndethus' Cassock
Sage's Robe
Variant: Pre 1.0.0
Variant: Pre 1.3.0
Variant: Pre 2.6.0
Variant: Current
Implicits: 0
{variant:2,3,4}Adds 1 to 40 Lightning Damage to Attacks
{variant:1}Adds 1 to 25 Lightning Damage
{variant:1,2,3}(75-100)% increased Energy Shield
{variant:4}(125-150)% increased Energy Shield
{variant:1}+(20-25)% to Chaos Resistance
{variant:2,3,4}+(40-50)% to Chaos Resistance
25% increased Light Radius
{variant:1}25% chance to create Consecrated Ground when you Block
{variant:2}50% chance to create Consecrated Ground when you Block
{variant:3,4}100% chance to create Consecrated Ground when you Block
]],[[
Ghostwrithe
Silken Vest
+(100-200) to maximum Energy Shield
+(50-100) to maximum Life
+50% to Chaos Resistance
50% of Maximum Life Converted to Energy Shield
]],
-- Body: Armour/Evasion
[[
Belly of the Beast
Full Wyrmscale
Implicits: 0
(150-200)% increased Armour
(30-40)% increased maximum Life
+(10-15)% to all Elemental Resistances
50% increased Flask Life Recovery rate
Extra gore
]],[[
Cherrubim's Maleficence
Triumphant Lamellar
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Current
Implicits: 0
{variant:1,2}(10-20)% increased Chaos Damage
{variant:3}(50-80)% increased Chaos Damage
(160-200)% increased Armour and Evasion
+(70-100) to maximum Life
{variant:1}30% increased total Recovery per second from Life Leech
{variant:2,3}100% increased total Recovery per second from Life Leech
]],[[
Daresso's Defiance
Full Dragonscale
Variant: Pre 2.6.0
Variant: Pre 3.5.0
Variant: Pre 3.16.0
Variant: Pre 3.19.0
Variant: Pre 3.26.0
Variant: Current
Implicits: 0
{variant:1,2,3}(160-200)% increased Armour and Evasion
{variant:4,5,6}(180-220)% increased Armour and Evasion
{variant:1,2}+(40-60) to maximum Life
{variant:3,4,5,6}+(60-90) to maximum Life
{variant:5}2% of Attack Damage Leeched as Life
{variant:6}2% of Attack Damage Leeched as Life
You lose all Endurance Charges when Hit
You gain an Endurance Charge on Kill
{variant:1}You gain Onslaught for 1 second per Endurance Charge when Hit
{variant:2}You gain Onslaught for 2 seconds per Endurance Charge when Hit
{variant:3,4,5,6}You gain Onslaught for 5 seconds per Endurance Charge when Hit
{variant:3,4}(60-100)% increased Effect of Onslaught on you
{variant:5,6}100% increased Effect of Onslaught on you
{variant:1,2,3,4}(0.4-0.6)% of Physical Attack Damage Leeched as Life
]],[[
Farrul's Fur
Triumphant Lamellar
League: Bestiary
Source: Drops from unique{Farrul, First of the Plains}
Implicits: 0
(100-150)% increased Armour and Evasion
+(80-100) to maximum Life
Aspect of the Cat has no Reservation
+2 seconds to Cat's Stealth Duration
Gain up to your maximum number of Frenzy and Power Charges when you gain Cat's Stealth
You have Phasing while you have Cat's Stealth
]],[[
Replica Farrul's Fur
Triumphant Lamellar
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 0
(100-150)% increased Armour and Evasion
+(80-100) to maximum Life
+2 seconds to Cat's Agility Duration
Aspect of the Cat has no Reservation
Gain up to your maximum number of Frenzy and Endurance Charges when you gain Cat's Agility
You have Onslaught while you have Cat's Agility
]],[[
Gruthkul's Pelt
Wyrmscale Doublet
Variant: Pre 3.5.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 0
{variant:1}(60-100)% increased Global Physical Damage
{variant:2,3}100% increased Global Physical Damage
{variant:3}(300-400)% increased Armour and Evasion
{variant:1}+(130-160) to maximum Life
{variant:2}+(200-240) to maximum Life
{variant:3}+(240-300) to maximum Life
{variant:1,2}+(20-40)% to Cold Resistance
{variant:1}Regenerate 2% of Life per second
{variant:2}Regenerate 5% of Life per second
{variant:3}Regenerate 10% of Life per second
15% increased Character Size
Spell Skills deal no Damage
Your Spells are disabled
]],[[
Lightning Coil
Desert Brigandine
Variant: Pre 1.3.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 0
Adds 1 to (20-30) Lightning Damage to Attacks
(90-120)% increased Armour and Evasion
+(60-80) to maximum Life
-60% to Lightning Resistance
{variant:1}40% of Physical Damage from Hits taken as Lightning Damage
{variant:2}30% of Physical Damage from Hits taken as Lightning Damage
{variant:3}50% of Physical Damage from Hits taken as Lightning Damage
]],[[
Viper's Scales
Full Scale Armour
Source: No longer obtainable
Implicits: 0
(80-100)% increased Armour and Evasion
+(30-40) to maximum Life
+(15-25)% to Cold Resistance
5% increased Movement Speed
20% chance to Poison on Hit with Attacks
Cannot be Poisoned
]],[[
Rigwald's Hunt
General's Brigandine
(160-200)% increased Armour and Evasion
Minions have (20-30)% increased Movement Speed
Minions have 1% chance to deal Double Damage per Fortification on you
(30-40)% increased Fortification Duration
Minions have (6-12)% increased Attack Speed
Increases and Reductions to Minion Maximum Life also apply to you at 15% of their value
]],
-- Body: Armour/Energy Shield
[[
Ambu's Charge
Crusader Chainmail
Variant: Pre 1.0.0
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 0
{variant:1}(80-100)% increased Armour and Energy Shield
{variant:2}(140-180)% increased Armour and Energy Shield
{variant:3,4,5}(180-220)% increased Armour and Energy Shield
{variant:4,5}+(60-80) to maximum Life
{variant:1,2}+10% to all Elemental Resistances
{variant:3,4,5}+15% to all Elemental Resistances
{variant:1,2,3,4}Gain an Endurance Charge when you take a Critical Strike
{variant:1,2,3}Regenerate 2% of Life per second while on Low Life
{variant:1,2,3,4}Share Endurance Charges with Party members within 12 metres
{variant:5}Gain up to maximum Endurance Charges when you take a Critical Strike
{variant:4}Regenerate 2% of Life per second if you have been Hit Recently
{variant:5}Your party members within 6 metres maximum Endurance Charges is equal to yours
]],[[
Replica Ambu's Charge
Crusader Chainmail
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 0
(180-220)% increased Armour and Energy Shield
+(60-80) to maximum Life
+15% to all Elemental Resistances
Share Endurance Charges with Party members within 12 metres
Gain an Endurance Charge when you are Hit
Lose 2% of Life per second if you have been Hit Recently
]],[[
Chains of Command
Saintly Chainmail
Implicits: 0
Trigger Level 20 Animate Guardian's Weapon when Animated Guardian Kills an Enemy
10% chance to Trigger Level 18 Animate Guardian's Weapon when Animated Weapon Kills an Enemy
(150-190)% increased Armour and Energy Shield
+(60-90) to maximum Life
Animated Guardian deals 5% increased Damage per Animated Weapon
Animated and Manifested Minions' Melee Strikes deal Splash
Damage to surrounding targets
Animated and Manifested Minions' Melee Strikes deal 50% less Splash Damage
You cannot have Non-Animated, Non-Manifested Minions
]],[[
Doryani's Prototype
Saint's Hauberk
League: Harvest
Implicits: 0
(150-200)% increased Armour and Energy Shield
+(60-90) to maximum Life
Deal no Non-Lightning Damage
Armour also applies to Lightning Damage taken from Hits
Lightning Resistance does not affect Lightning Damage taken
Enemies within 6 metres have Lightning Resistance equal to yours
]],[[
The Fourth Vow
Devout Chainmail
(150-250)% increased Armour and Energy Shield
+(17-29)% to Chaos Resistance
Regenerate 3% of Life per second
Armour also applies to Chaos Damage taken from Hits
Physical Damage taken bypasses Energy Shield
]],[[
Geofri's Sanctuary
Elegant Ringmail
Variant: Pre 2.6.0
Variant: Pre 3.0.0
Variant: Current
Implicits: 0
(50-75)% increased Armour and Energy Shield
{variant:1,2}+(70-80) to maximum Energy Shield
{variant:3}+(30-40) to maximum Energy Shield
{variant:1,2}+(50-70) to maximum Life
{variant:3}+(60-70) to maximum Life
+(14-18)% to all Elemental Resistances
{variant:1}+1 maximum Energy Shield per 5 Strength
{variant:2,3}+2 maximum Energy Shield per 5 Strength
Zealot's Oath
]],[[
Icetomb
Latticed Ringmail
Variant: Pre 2.0.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 0
{variant:1}+15 to Strength
{variant:2,3}+(30-40) to Strength
{variant:1}+15 to Intelligence
{variant:2,3}+(30-40) to Intelligence
(140-160)% increased Armour and Energy Shield
+(50-75)% to Cold Resistance
Cannot be Chilled
{variant:1,2}150% increased Chill Duration on Enemies
{variant:3}20% chance to Freeze Enemies for 1 second when they Hit you
]],[[
Crystal Vault
Latticed Ringmail
Source: No longer obtainable
Requires Level 49
Implicits: 0
+(30-40) to Strength
+(30-40) to Intelligence
(140-160)% increased Armour and Energy Shield
+(50-75)% to Cold Resistance
Cannot be Chilled
20% of Physical Damage from Hits taken as Cold Damage
30% of Fire Damage from Hits taken as Cold Damage
(15-20)% increased Effect of Cold Ailments
]],[[
Incandescent Heart
Saintly Chainmail
Variant: Pre 2.6.0
Variant: Current
Implicits: 0
{variant:1}+(60-80) to Armour
{variant:1}(120-140)% increased Armour and Energy Shield
{variant:2}(220-240)% increased Armour and Energy Shield
+(80-90) to maximum Life
{variant:1,2}(0.8-1)% of Attack Damage Leeched as Life
{variant:2}Gain (10-20)% of Elemental Damage as Extra Chaos Damage
25% of Elemental Damage from Hits taken as Chaos Damage
(20-30)% increased Light Radius
Light Radius is based on Energy Shield instead of Life
]],[[
The Ivory Tower
Saint's Hauberk
Implicits: 0
+(40-70) to Intelligence
+30 to maximum Energy Shield per 100 Reserved Life
+(80-100) to maximum Mana
Regenerate 2% of Energy Shield per second
Chaos Damage is taken from Mana before Life
]],[[
Kingsguard
Conquest Chainmail
Implicits: 0
(150-170)% increased Armour and Energy Shield
+(60-90) to maximum Life
+(50-70) to maximum Mana
30% increased Endurance Charge Duration
Gain 100 Life when you lose an Endurance Charge
]],[[
Lightbane Raiment
Ornate Ringmail
Variant: Pre 1.0.0
Variant: Pre 1.3.0
Variant: Pre 2.0.0
Variant: Current
Implicits: 0
{variant:1}(80-100)% increased Armour and Energy Shield
{variant:2,3,4}(120-140)% increased Armour and Energy Shield
{variant:1,2,3}10% of Physical Damage Converted to Chaos Damage
{variant:4}30% of Physical Damage Converted to Chaos Damage
{variant:1}Reflects (10-20) Chaos Damage to Melee Attackers
{variant:2,3,4}Reflects 30 Chaos Damage to Melee Attackers
25% reduced Light Radius
{variant:1}25% chance to create Desecrated Ground when you Block
{variant:2}50% chance to create Desecrated Ground when you Block
{variant:3,4}100% chance to create Desecrated Ground when you Block
]],[[
Loreweave
Elegant Ringmail
Source: Vendor Recipe
Variant: Pre 3.6.0
Variant: Current
Implicits: 0
Has 6 Sockets
+(8-24) to all Attributes
Adds (4-10) to (14-36) Physical Damage to Attacks
(20-60)% increased Global Critical Strike Chance
+(15-50) to maximum Energy Shield
+(20-60) to maximum Life
+(20-50) to maximum Mana
+(6-30)% to Item Rarity
(15-50)% increased Elemental Damage
{variant:1}Your Maximum Resistances are (76-80)%
{variant:2}Your Maximum Resistances are (76-78)%
]],[[
Replica Loreweave
Elegant Ringmail
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 0
Has 6 Sockets
+(8-24) to all Attributes
Adds (4-10) to (14-36) Physical Damage to Attacks
(120-160)% increased Global Critical Strike Chance
+(150-200) to maximum Energy Shield
+(120-160) to maximum Life
+(120-160) to maximum Mana
+(6-30)% to Item Rarity
(15-50)% increased Elemental Damage
Your Maximum Resistances are (70-72)%
]],[[
Rotting Legion
Loricated Ringmail
Source: No longer obtainable
League: Blight
Implicits: 0
Socketed Gems are Supported by Level 1 Meat Shield Support
(100-140)% increased Armour and Energy Shield
+(50-80) to maximum Life
(5-8)% increased Damage per Raised Zombie
1% less Elemental Damage taken per Raised Zombie
]],[[
Sporeguard
Saint's Hauberk
League: Blight
Source: Drops in Blighted Maps
Variant: Pre 3.26.0
Variant: Current
Implicits: 0
Trigger Level 10 Contaminate when you Kill an Enemy
(200-250)% increased Armour and Energy Shield
(7-10)% increased maximum Life
{variant:1}+(17-23)% to Chaos Resistance
{variant:2}+(29-43)% to Chaos Resistance
Enemies on Fungal Ground you Kill Explode, dealing 10% of their Life as Chaos Damage
You have Fungal Ground around you while stationary
This item can be anointed by Cassia
]],[[
Voll's Protector
Holy Chainmail
League: Legion
Variant: Pre 3.7.0
Variant: Current
Implicits: 0
{variant:1}60% increased Armour and Energy Shield
{variant:2}(100-150)% increased Armour and Energy Shield
50% reduced maximum Mana
Gain a Power Charge for each Enemy you hit with a Critical Strike
{variant:2}Inner Conviction
]],[[
Waxen Soul
Saint's Hauberk
League: Ritual
Source: Reward from Nameless Ritual, and rarely a regular Ritual
(10-20)% increased maximum Life
+(17-29)% to Chaos Resistance
Curse Skills cost Life instead of Mana
Curse Aura Skills reserve Life instead of Mana
Gain a random Blood Shrine buff every 10 seconds
2% increased Effect of Shrine Buffs on you for each 5% of Life Reserved
10% chance to Trigger Explosive Toad when you kill an Enemy
]],
-- Body: Evasion/Energy Shield
[[
Bloodbond
Bone Armour
Variant: Pre 3.16.0
Variant: Current
Implicits: 0
Grants Level 15 Blood Offering
(100-120)% increased Evasion and Energy Shield
(15-25)% increased maximum Life
Minions have (20-30)% increased maximum Life
Regenerate 1% of Life per second
{variant:1}Minions have +(6-10)% chance to Suppress Spell Damage
{variant:2}Minions have +(12-15)% chance to Suppress Spell Damage
]],[[
Carcass Jack
Varnished Coat
Variant: Pre 3.0.0
Variant: Pre 3.5.0
Variant: Current
Implicits: 0
(120-150)% increased Evasion and Energy Shield
+(50-70) to maximum Life
+(9-12)% to all Elemental Resistances
{variant:1,2}20% increased Area of Effect
{variant:3}(40-50)% increased Area of Effect
{variant:1}12% increased Area Damage
{variant:2,3}(40-50)% increased Area Damage
Extra gore
]],[[
Cloak of Defiance
Lacquered Garb
Variant: Pre 1.3.0
Variant: Pre 3.0.0
Variant: Pre 3.5.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 0
{variant:1,2,3}(110-150)% increased Evasion and Energy Shield
{variant:4,5}(300-400)% increased Evasion and Energy Shield
{variant:1,2}+(90-110) to maximum Mana
{variant:3,4,5}+(100-150) to maximum Mana
{variant:3,4,5}Regenerate 1% of Mana per second
{variant:1,2}(40-50)% increased Mana Regeneration Rate
{variant:1,3,4}10% of Damage is taken from Mana before Life
Mind Over Matter
]],[[
Dendrobate
Sentinel Jacket
Implicits: 0
Socketed Gems are Supported by Level 10 Chance to Poison Support
(130-150)% increased Evasion and Energy Shield
+40 to maximum Energy Shield
+(15-25)% to all Elemental Resistances
(75-100)% increased Damage with Poison if you have at least 300 Dexterity
(15-25)% increased Poison Duration if you have at least 150 Intelligence
]],[[
The Eternity Shroud
Blood Raiment
Shaper Item
Elder Item
Source: Drops from unique{The Elder} (Uber)
Implicits: 0
Trigger Level 20 Glimpse of Eternity when Hit
(100-150)% increased Evasion and Energy Shield
+(70-100) to maximum Life
+(17-23)% to Chaos Resistance
Gain (3-5)% of Elemental Damage as Extra Chaos Damage per Shaper Item Equipped
Hits ignore Enemy Monster Chaos Resistance if all Equipped Items are Shaper Items
]],[[
Replica Eternity Shroud
Blood Raiment
Shaper Item
Elder Item
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 0
Trigger Level 20 Shade Form when Hit
(100-150)% increased Evasion and Energy Shield
+(70-100) to maximum Life
+(17-23)% to Chaos Resistance
Gain (3-5)% of Physical Damage as Extra Chaos Damage per Elder Item Equipped
Hits ignore Enemy Monster Chaos Resistance if all Equipped Items are Elder Items
]],[[
Expedition's End
Sentinel Jacket
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 0
(100-150)% increased Evasion and Energy Shield
(5-10)% increased maximum Life
All Damage can Freeze
Freeze Chilled Enemies as though dealing (50-100)% more Damage
Enemies within 3 metres are Chilled
]],[[
Inpulsa's Broken Heart
Sadist Garb
Variant: Pre 3.5.0
Variant: Pre 3.7.0
Variant: Current
Implicits: 0
+(60-80) to maximum Life
(20-50)% increased Damage if you have Shocked an Enemy Recently
{variant:1,2}(25-40)% increased Effect of Shock
{variant:3}(15-25)% increased Effect of Shock
{variant:1}Shocked Enemies you Kill Explode, dealing (5-10)% of
{variant:1}their Life as Lightning Damage which cannot Shock
{variant:2,3}Shocked Enemies you Kill Explode, dealing 5% of
{variant:2,3}their Life as Lightning Damage which cannot Shock
Unaffected by Shock
]],[[
The Restless Ward
Carnal Armour
Variant: Pre 2.6.0
Variant: Pre.3.19.0
Variant: Current
Implicits: 1
+(20-25) to maximum Mana
{variant:1}(120-150)% increased Evasion and Energy Shield
{variant:2,3}(220-250)% increased Evasion and Energy Shield
{variant:1}+(40-60) to maximum Life
{variant:2,3}+(60-80) to maximum Life
{variant:1,2}1% increased Movement Speed per Frenzy Charge
{variant:3}4% increased Movement Speed per Frenzy Charge
{variant:1}Regenerate (15-20) Life per second per Endurance Charge
{variant:2}Regenerate (20-30) Life per second per Endurance Charge
{variant:3}Regenerate 75 Life per second per Endurance Charge
{variant:1,2}100% increased Endurance, Frenzy and Power Charge Duration
{variant:3}(100-200)% increased Endurance, Frenzy and Power Charge Duration
]],[[
Replica Restless Ward
Carnal Armour
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 1
+(20-25) to maximum Mana
(220-250)% increased Evasion and Energy Shield
+(60-80) to maximum Life
6% increased Movement Speed per Frenzy Charge
-2 to Maximum Endurance Charges
-2 to Maximum Frenzy Charges
Regenerate (100-140) Life per second per Endurance Charge
]],[[
Saqawal's Nest
Blood Raiment
League: Bestiary
Source: Drops from unique{Saqawal, First of the Sky}
Implicits: 0
+(25-75) to all Attributes
+(30-40)% to Lightning Resistance
(12-20)% increased Mana Reservation Efficiency of Skills
100% increased Aspect of the Avian Buff Effect
Aspect of the Avian also grants Avian's Might and Avian's Flight to Allies within 6 metres
+(120-150) to Evasion Rating and Energy Shield
]],[[
Shroud of the Lightless
Carnal Armour
League: Abyss
Source: Drops from unique{Amanamu, Liege of the Lightless} or unique{Ulaman, Sovereign of the Well}
Variant: Two Abyssal Sockets (Pre 3.12.0)
Variant: One Abyssal Socket (Pre 3.12.0)
Variant: Two Abyssal Sockets (Pre 3.21.0)
Variant: One Abyssal Socket (Pre 3.21.0)
Variant: Three Abyssal Sockets (Current)
Variant: Two Abyssal Sockets (Current)
Variant: One Abyssal Socket (Current)
Implicits: 1
+(20-25) to maximum Mana
{variant:5}Has 3 Abyssal Sockets
{variant:1,3,6}Has 2 Abyssal Sockets
{variant:2,4,7}Has 1 Abyssal Socket
{variant:1,2}Socketed Gems are Supported by Level 20 Elemental Penetration Support
{variant:3,4}Socketed Gems are Supported by Level 25 Elemental Penetration Support
20% chance to Trigger Level 20 Shade Form when you Use a Socketed Skill
(160-180)% increased Evasion and Energy Shield
{variant:1,2,3,4}(6-10)% increased maximum Life
{variant:1,2,3,4}(9-15)% increased maximum Mana
{variant:1,2,3,4}1% increased Maximum Life per Abyss Jewel affecting you
{variant:5,6,7}3% increased Maximum Life per Abyss Jewel affecting you
{variant:1,2,3,4}1% increased Maximum Mana per Abyss Jewel affecting you
{variant:5,6,7}3% increased Maximum Mana per Abyss Jewel affecting you
{variant:5,6,7}Penetrate 4% Elemental Resistances per Abyss Jewel affecting you
]],[[
Replica Shroud of the Lightless
Carnal Armour
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 1
+(20-25) to maximum Mana
Has 6 Abyssal Sockets
]],[[
Stasis Prison
Carnal Armour
Source: Drops in Unrelenting Domain of Timeless Conflict
Variant: Pre 3.29.0
Variant: Current
Implicits: 1
+(20-25) to maximum Mana
{variant:2}(80-100)% increased Implicit Modifier magnitudes
(140-160)% increased Evasion and Energy Shield
{variant:1}+(80-100) to maximum Life
Temporal Rift has no Reservation
(80-100)% of Damage taken Recouped as Life
Debuffs on you expire (80-100)% faster
]],[[
Tinkerskin
Sadist Garb
Implicits: 0
(140-170)% increased Evasion and Energy Shield
+(60-90) to maximum Life
(10-15)% increased Cooldown Recovery Rate for throwing Traps
15% chance to gain a Frenzy Charge when your Trap is triggered by an Enemy
30% chance to gain Phasing for 4 seconds when your Trap is triggered by an Enemy
Recover 100 Life when your Trap is triggered by an Enemy
Recover 50 Energy Shield when your Trap is triggered by an Enemy
]],[[
Victario's Influence
Lacquered Garb
Variant: Pre 2.6.0
Variant: Current
Implicits: 0
+1 to Level of Socketed Aura Gems
{variant:1}Socketed Gems are Supported by Level 1 Generosity Support
{variant:2}Socketed Gems are Supported by Level 30 Generosity Support
Socketed Gems have 45% increased Reservation Efficiency
(120-150)% increased Evasion and Energy Shield
{variant:1}(10-20)% increased Area of Effect of Aura Skills
{variant:2}(20-40)% increased Area of Effect of Aura Skills
(10-15)% increased effect of Non-Curse Auras from your Skills
]],[[
Servant of Decay
Torturer Garb
Source: Drops from unique{Incarnation of Fear} in normal{Moment of Trauma}
Trigger Level 20 Summon Void Spawn every 4 seconds
(150-200)% increased Energy Shield
+(23-37)% to Chaos Resistance
(4-6)% of Damage from Hits is taken from Void Spawns' Life before you per Void Spawn
Gain (4-6)% of Non-Chaos Damage as Extra Chaos Damage per Summoned Void Spawn
]],[[
Seven Teachings
Waxed Garb
Source: Drops from unique{Incarnation of Dread} in normal{Moment of Reverence}
Requires Level 77
Trigger a Socketed Spell on Unarmed Melee Critical Strike, with a 0.25 second Cooldown
(1-7)% more Attack Speed with Unarmed Melee Attacks
(100-777)% increased Evasion and Energy Shield
(1-7)% increased Movement Speed
+(0.1-0.7) metres to Melee Strike Range with Unarmed Attacks
+(1-7)% to Unarmed Melee Attack Critical Strike Chance
+(10-77)% to Critical Strike Multiplier with Unarmed Melee Attacks
]],
-- Body: Armour/Evasion/Energy Shield
[[
The Admiral
Varnished Coat
League: Heist
Source: Drops from unique{Admiral Darnaw} in normal{Contract: Death to Darnaw}
Variant: Pre 3.26.0
Variant: Current
Implicits: 0
+(30-40) to Intelligence
{variant:1}(100-140)% increased Evasion and Energy Shield
{variant:2}(120-200)% increased Evasion and Energy Shield
+(10-20)% to all Elemental Resistances
{variant:1}(5-10)% chance to Freeze, Shock and Ignite
{variant:2}(10-25)% chance to Freeze, Shock and Ignite
Elemental Damage you Deal with Hits is Resisted by lowest Elemental Resistance instead
]],[[
Atziri's Splendour
Sacrificial Garb
Source: Drops from unique{Atziri, Queen of the Vaal} in normal{The Alluring Abyss}
Variant: Pre 3.0.0 (Armour)
Variant: Pre 3.0.0 (Armour/Evasion)
Variant: Pre 3.0.0 (Evasion)
Variant: Pre 3.0.0 (Evasion/ES + Life)
Variant: Pre 3.0.0 (Evasion/ES + ES)
Variant: Pre 3.0.0 (Energy Shield)
Variant: Pre 3.0.0 (Armour/ES + Life)
Variant: Pre 3.0.0 (Armour/ES + ES)
Variant: Pre 3.0.0 (Armour/Evasion/ES)
Variant: Current (Armour)
Variant: Current (Armour/Evasion)
Variant: Current (Evasion)
Variant: Current (Evasion/ES + Life)
Variant: Current (Evasion/ES + ES)
Variant: Current (Energy Shield)
Variant: Current (Armour/ES + Life)
Variant: Current (Armour/ES + ES)
Variant: Current (Armour/Evasion/ES)
Requires Level 75
Implicits: 1
+1 to Level of all Vaal Skill Gems
{variant:1,10}(380-420)% increased Armour
{variant:3,12}(380-420)% increased Evasion Rating
{variant:7,16}(200-220)% increased Armour and Energy Shield
{variant:8,17}(200-220)% increased Armour and Energy Shield
{variant:2,11}(200-220)% increased Armour and Evasion
{variant:4,13}(200-220)% increased Evasion and Energy Shield
{variant:5,14}(200-220)% increased Evasion and Energy Shield
{variant:9,18}(270-340)% increased Armour, Evasion and Energy Shield
{variant:5,6,8}+(90-100) to maximum Energy Shield
{variant:14,15,17}+(70-80) to maximum Energy Shield
{variant:6,15}(270-300)% increased Energy Shield
{variant:1,2,3,4,7,10,11,12,13,16}+(90-100) to maximum Life
+(20-24)% to all Elemental Resistances
Gain 100 Life per Enemy Killed
Gain 100 Mana per Enemy Killed
]],[[
Shadowstitch
Sacrificial Garb
League: Incursion
Source: Double Corrupting Sacrificial Garb
Variant: Pre 3.10.0
Variant: Current
Implicits: 0
+(1-50) to all Attributes
{variant:2}(250-350)% increased Armour, Evasion and Energy Shield
Recover (3-5)% of Life on Kill
Recover (3-5)% of Energy Shield on Kill
(8-10)% increased Maximum Life for each Corrupted Item Equipped
(10-12)% increased Maximum Energy Shield for each Corrupted Item Equipped
-(8-6)% to all Resistances for each Corrupted Item Equipped
Corrupted
]],[[
The Queen's Hunger
Vaal Regalia
League: Betrayal
Source: Drops from unique{Catarina, Master of Undeath}
Crafted: true
Implicits: 0
Trigger Level 20 Bone Offering, Flesh Offering, Spirit Offering every 5 seconds in sequence
Offering Skills Triggered this way also affect you
(100-130)% increased Energy Shield
(6-10)% increased maximum Life
]]
}
