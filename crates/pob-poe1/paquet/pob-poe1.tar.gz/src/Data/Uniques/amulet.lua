-- Item data (c) Grinding Gear Games

return {
-- Amulet
[[
The Anvil
Amber Amulet
Variant: Pre 1.3.0
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 45
Implicits: 1
{tags:attribute}+(20-30) to Strength
{variant:1}10% Chance to Block Attack Damage
{variant:2,3}8% Chance to Block Attack Damage
{variant:4}(10-15)% Chance to Block Attack Damage
{tags:attack,speed}10% reduced Attack Speed
{tags:caster,speed}10% reduced Cast Speed
{tags:defences}+(400-500) to Armour
{variant:1}{tags:resource}(30-40) Life gained when you Block
{variant:2,3,4}{tags:resource}(34-48) Life gained when you Block
{variant:1}{tags:resource}(10-20) Mana gained when you Block
{variant:2,3,4}{tags:resource}(18-24) Mana gained when you Block
{variant:1}{tags:speed}20% reduced Movement Speed
{variant:2}{tags:speed}10% reduced Movement Speed
+3% to maximum Chance to Block Attack Damage
{variant:1}{tags:physical_damage}Reflects 200 to 250 Physical Damage to Attackers on Block
{variant:2,3,4}{tags:physical_damage}Reflects 240 to 300 Physical Damage to Attackers on Block
]],[[
Bloodsoaked Medallion
Amber Amulet
Requires Level 49
Implicits: 1
{tags:attribute}+(20-30) to Strength
{tags:critical}(30-50)% increased Global Critical Strike Chance
{tags:resource}+(50-70) to maximum Life
{tags:resistance}+(17-29)% to Chaos Resistance
Every 10 seconds:
Gain 2% of Life per Enemy Hit with Attacks for 5 seconds
Gain 5% of Life per Enemy Killed for 5 seconds
]],[[
Araku Tiki
Coral Amulet
Variant: Pre 3.19.0
Variant: Current
Implicits: 1
{tags:resource}Regenerate (2-4) Life per second
{variant:1}{tags:defences}+100 to Evasion Rating while on Low Life
{variant:2}{tags:defences}+(150-250) to Evasion Rating while on Low Life
{tags:resource}+(30-50) to maximum Life
{tags:resistance}+(20-30)% to Fire Resistance
{variant:1}{tags:resource}Regenerate 1% of Life per second while on Low Life
{variant:2}Gain Elusive on reaching Low Life
{variant:2}You have Phasing while on Low Life
]],[[
Ngamahu Tiki
Coral Amulet
Source: No longer obtainable
Requires Level 36
Implicits: 1
{tags:resource}Regenerate (2-4) Life per second
{tags:elemental_damage}(50-70)% increased Fire Damage
{tags:defences}+100 to Evasion Rating while on Low Life
{tags:resource}+(30-50) to maximum Life
{tags:resistance}+(20-30)% to Fire Resistance
{tags:resource}Regenerate 1% of Life per second while on Low Life
]],[[
The Ascetic
Gold Amulet
Source: No longer obtainable
Implicits: 1
+(12-20)% to Item Rarity
+(80-100)% to Item Rarity with a Normal Item Equipped
(10-15)% increased Quantity of Items found with a Magic Item Equipped
]],[[
Ashes of the Stars
Onyx Amulet
Variant: Pre 3.23.0
Variant: Current
Source: Drops from unique{The Eater of Worlds} (Uber)
Requires Level 60
Implicits: 1
{tags:attribute}+(10-16) to all Attributes
(5-10)% increased Experience Gain of Gems
{variant:1}(10-20)% increased Reservation Efficiency of Skills
+1 to Level of all Skill Gems
+(20-30)% to Quality of all Skill Gems
]],[[
Astramentis
Onyx Amulet
Implicits: 1
{tags:attribute}+(10-16) to all Attributes
{tags:attribute}+(80-100) to all Attributes
{tags:attack}-4 Physical Damage taken from Attack Hits
]],[[
Atziri's Foible
Paua Amulet
Variant: Pre 2.6.0
Variant: Current
Requires Level 16
Implicits: 1
{tags:resource}(20-30)% increased Mana Regeneration Rate
{variant:1}{tags:resource}+50 to maximum Mana
{variant:2}{tags:resource}+100 to maximum Mana
{variant:1}{tags:resource}(8-12)% increased maximum Mana
{variant:2}{tags:resource}(16-24)% increased maximum Mana
{variant:1}{tags:resource}(40-60)% increased Mana Regeneration Rate
{variant:2}{tags:resource}(80-100)% increased Mana Regeneration Rate
Items and Gems have 25% reduced Attribute Requirements
]],[[
Replica Atziri's Foible
Paua Amulet
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 16
Implicits: 1
{tags:resource}Regenerate (1-2)% of Life per second
{tags:resource}+100 to maximum Life
{tags:resource}(20-25)% increased Life Regeneration rate
Items and Gems have 25% reduced Attribute Requirements
]],[[
Aul's Uprising
Onyx Amulet
League: Delve
Source: Drops from unique{Aul, the Crystal King}
Variant: Strength: Anger
Variant: Strength: Determination
Variant: Strength: Pride
Variant: Strength: Purity of Fire
Variant: Strength: Vitality
Variant: Dexterity: Grace
Variant: Dexterity: Haste
Variant: Dexterity: Hatred
Variant: Dexterity: Purity of Ice
Variant: Intelligence: Clarity
Variant: Intelligence: Discipline
Variant: Intelligence: Malevolence
Variant: Intelligence: Purity of Elements
Variant: Intelligence: Purity of Lightning
Variant: Intelligence: Wrath
Variant: Intelligence: Zealotry
Variant: Envy
Requires Level 55
Implicits: 1
{tags:attribute}+(10-16) to all Attributes
{variant:17}Grants Level 15 Envy
{variant:17}{tags:attribute}+(15-20) to all Attributes
{variant:1,2,3,4,5}{tags:attribute}+(20-30) to Strength
{variant:6,7,8,9}{tags:attribute}+(20-30) to Dexterity
{variant:10,11,12,13,14,15,16}{tags:attribute}+(20-30) to Intelligence
{variant:1,2,3,4,5}{tags:defences}(15-20)% increased Armour
{variant:6,7,8,9}{tags:defences}(15-20)% increased Evasion Rating
{variant:10,11,12,13,14,15,16}{tags:defences}(15-20)% increased maximum Energy Shield
{tags:resource}+(50-70) to maximum Life
{variant:17}{tags:defences}(15-20)% increased Global Defences
{variant:10,11,12,13,14,15,16}{tags:critical}Hits against Enemies within 6 metres have 50% increased Critical Strike Chance
{variant:6,7,8,9}Enemies within 6 metres grant 25% increased Flask Charges
{variant:1,2,3,4,5}Enemies within 6 metres have 10% reduced Stun and Block Recovery
{variant:1}Anger has no Reservation
{variant:10}Clarity has no Reservation
{variant:12}Malevolence has no Reservation
{variant:2}Determination has no Reservation
{variant:11}Discipline has no Reservation
{variant:17}Envy has no Reservation
{variant:6}Grace has no Reservation
{variant:7}Haste has no Reservation
{variant:8}Hatred has no Reservation
{variant:3}Pride has no Reservation
{variant:13}Purity of Elements has no Reservation
{variant:4}Purity of Fire has no Reservation
{variant:9}Purity of Ice has no Reservation
{variant:14}Purity of Lightning has no Reservation
{variant:5}Vitality has no Reservation
{variant:15}Wrath has no Reservation
{variant:16}Zealotry has no Reservation
]],[[
The Aylardex
Agate Amulet
Variant: Pre 2.5.0
Variant: Current
Requires Level 32
Implicits: 1
{tags:attribute}+(16-24) to Strength and Intelligence
{tags:resource}+(30-50) to maximum Life
{tags:resource}+(50-70) to maximum Mana
+1 to Maximum Power Charges
{tags:resource}10% increased Mana Regeneration Rate per Power Charge
{variant:2}(80-100)% increased Power Charge Duration
{tags:resource}1% of Damage is taken from Mana before Life per Power Charge
{tags:critical}40% reduced Critical Strike Chance per Power Charge
]],[[
Eternal Damnation
Agate Amulet
Variant: Pre 3.25.0
Variant: Current
League: Sanctum
Source: Drops from unique{Lycia, Herald of the Scourge} in normal{The Beyond}
Requires Level 52
Implicits: 1
{tags:attribute}+(16-24) to Strength and Intelligence
{tags:resource}+(40-70) to maximum Mana
{tags:resistance}+(-13-13)% to Chaos Resistance
{tags:resistance}-5% to all maximum Resistances
Gain additional Elemental Damage Reduction equal to half your Chaos Resistance
{variant:2}Maximum Endurance, Frenzy and Power Charges is 0
]],[[
Badge of the Brotherhood
Turquoise Amulet
League: Blight
Requires Level 60
Implicits: 1
{tags:attribute}+(16-24) to Dexterity and Intelligence
Your Maximum Frenzy Charges is equal to your Maximum Power Charges
(7-10)% increased Cooldown Recovery Rate of Travel Skills per Frenzy Charge
(7-10)% increased Effect of Elusive on you per Power Charge
(20-25)% chance to lose a Frenzy Charge when you use a Travel Skill
(20-25)% chance to lose a Power Charge when you gain Elusive
]],
[[
Replica Badge of the Brotherhood
Turquoise Amulet
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 60
Implicits: 1
{tags:attribute}+(16-24) to Dexterity and Intelligence
Your Maximum Endurance Charges is equal to your Maximum Frenzy Charges
+1 to maximum Fortification per Endurance Charge
(7-10)% increased Cooldown Recovery Rate of Travel Skills per Frenzy Charge
(20-25)% chance to lose a Frenzy Charge when you use a Travel Skill
(20-25)% chance to lose an Endurance Charge when you gain Fortification
]],[[
Bisco's Collar
Gold Amulet
Variant: Pre 3.0.0
Variant: Pre 3.2.0
Variant: Current
Source: No longer obtainable
Requires Level 30
Implicits: 1
+(12-20)% to Item Rarity
{variant:1}+150% to Rarity of Items Dropped by Slain Magic Enemies
{variant:2,3}+(100-150)% to Rarity of Items Dropped by Slain Magic Enemies
{variant:1}100% increased Quantity of Items Dropped by Slain Normal Enemies
{variant:2}(50-100)% increased Quantity of Items Dropped by Slain Normal Enemies
{variant:3}(35-50)% increased Quantity of Items Dropped by Slain Normal Enemies
]],[[
Blightwell
{variant:1,2}Clutching Talisman
{variant:3}Shield Crab Talisman
Variant: Pre 3.16.0
Variant: Pre 3.29.0
Variant: Current
League: Talisman Hardcore
Talisman Tier: 2
Requires Level 28
Implicits: 1
{variant:1,2}{tags:defences}(15-25)% increased Global Defences
{variant:1,2}{tags:defences}+(20-30) to maximum Energy Shield
{variant:3}{tags:defences}+(50-100) to maximum Energy Shield
{tags:resistance}+(15-30)% to Fire Resistance
{tags:resistance}+(15-30)% to Lightning Resistance
{variant:3}(15-30)% increased Flask Effect Duration
{variant:1}{tags:defences}30% slower start of Energy Shield Recharge during any Flask Effect
{variant:2,3}{tags:defences}50% slower start of Energy Shield Recharge during any Flask Effect
{variant:1}{tags:defences}400% increased Energy Shield Recharge Rate during any Flask Effect
{variant:2,3}{tags:defences}(150-200)% increased Energy Shield Recharge Rate during any Flask Effect
{variant:1,2}Corrupted
]],[[
Blood of Corruption
Amber Amulet
Source: Use currency{Vaal Orb} on unique{Tear of Purity}
Implicits: 1
{tags:attribute}+(20-30) to Strength
Grants Level 20 Gluttony of Elements
{tags:chaos_damage,attack}Adds 19 to 43 Chaos Damage to Attacks
{tags:resistance}-(10-5)% to all Elemental Resistances
{tags:resistance}+(17-29)% to Chaos Resistance
Corrupted
]],[[
Bloodgrip
{variant:1}Coral Amulet
{variant:2,3}Marble Amulet
Variant: Pre 3.0.0
Variant: Pre 3.12.0
Variant: Current
Implicits: 2
{variant:1}{tags:resource}Regenerate (2-4) Life per second
{variant:2,3}{tags:resource}Regenerate (1.4-2)% of Life per second
{tags:physical_damage,attack}Adds 10 to 20 Physical Damage to Attacks
{tags:resource}+(60-70) to maximum Life
{variant:1,2}{tags:resource}Regenerate (8-12) Life per second
{variant:3}{tags:resource}Regenerate (16-24) Life per second
{tags:resource}100% increased Life Recovery from Flasks
{tags:attack}Moving while Bleeding doesn't cause you to take extra Damage
]],[[
Carnage Heart
Onyx Amulet
Variant: Pre 2.6.0
Variant: Current
Implicits: 1
{tags:attribute}+(10-16) to all Attributes
{tags:attribute}+(20-40) to all Attributes
{variant:1}{tags:defences}25% reduced maximum Energy Shield
{variant:1}{tags:resource}25% reduced maximum Life
{tags:resistance}+(10-20)% to all Elemental Resistances
{tags:resource,attack}(1.2-2)% of Physical Attack Damage Leeched as Life
{variant:2}{tags:resource}50% increased total Recovery per second from Life Leech
{variant:2}(30-40)% increased Damage while Leeching
Extra gore
]],[[
Crystallised Omniscience
Onyx Amulet
Source: Drops from unique{The Searing Exarch} (Uber)
Requires Level 61
Implicits: 1
{tags:attribute}+(10-16) to all Attributes
{tags:attribute}Modifiers to Attributes instead apply to Omniscience
{tags:resistance}+1% to all Elemental Resistances per 15 Omniscience
{tags:elemental_damage}Penetrate 1% Elemental Resistances per 15 Omniscience
Attribute Requirements can be satisfied by (15-25)% of Omniscience
]],[[
Daresso's Salute
Citrine Amulet
League: Anarchy
Implicits: 1
{tags:attribute}+(16-24) to Strength and Dexterity
{tags:defences}50% reduced maximum Energy Shield
{tags:resistance}+(30-40)% to Fire Resistance
{tags:resistance}+(30-40)% to Cold Resistance
{tags:speed}10% increased Movement Speed when on Full Life
{tags:attack}+0.2 metres to Melee Strike Range
{tags:attack}60% increased Melee Damage when on Full Life
]],[[
Defiance of Destiny
Paua Amulet
Variant: Pre 3.25.0
Variant: Current
Requires Level 49
Implicits: 1
{tags:resource}(20-30)% increased Mana Regeneration Rate
{tags:resource}+(60-80) to maximum Life
{tags:resistance}+(10-40)% to Fire Resistance
{tags:resistance}+(10-40)% to Cold Resistance
{tags:resistance}+(10-40)% to Lightning Resistance
{variant:1}{tags:resource}Gain (25-35)% of Missing Unreserved Life before being Hit by an Enemy
{variant:2}{tags:resource}Gain (10-20)% of Missing Unreserved Life before being Hit by an Enemy
]],[[
The Ephemeral Bond
Lapis Amulet
League: Heist
Requires Level 68
Implicits: 1
{tags:attribute}+(20-30) to Intelligence
{tags:resource}(25-40)% increased Mana Regeneration Rate
{tags:resistance}+(15-25)% to all Elemental Resistances
{tags:critical}+(30-40)% to Critical Strike Multiplier if you've gained a Power Charge Recently
{tags:elemental_damage}(1-2) to (36-40) Lightning Damage per Power Charge
90% less Power Charge Duration
]],[[
The Untouched Soul
Gold Amulet
Variant: Pre 3.29.0
Variant: Current
League: Affliction
Requires Level 48
Implicits: 1
+(12-20)% to Item Rarity
{tags:resource}Players have +40 to maximum Life for each Empty Red Socket on any Equipped Item
{tags:attack}Players have +225 to Accuracy Rating for each Empty Green Socket on any Equipped Item
{tags:resource}Players have +40 to maximum Mana for each Empty Blue Socket on any Equipped Item
{variant:1}{tags:resistance}Players have +18% to all Elemental Resistances for each Empty White Socket
{variant:1}{tags:resistance}on any Equipped Item
{variant:2}{tags:resistance}Players have +12% to all Elemental Resistances for each Empty White Socket
{variant:2}{tags:resistance}on any Equipped Item
]],[[
Doedre's Tongue
Lapis Amulet
Requires Level 24
Implicits: 1
{tags:attribute}+(20-30) to Intelligence
{tags:resistance}+(30-35)% to all Elemental Resistances
(25-50)% chance to Freeze, Shock and Ignite
Cursed Enemies cannot inflict Elemental Ailments on You
]],[[
Extractor Mentis
Agate Amulet
Variant: Pre 3.5.0
Variant: Current
Implicits: 1
{tags:attribute}+(16-24) to Strength and Intelligence
{tags:attribute}+(30-50) to Strength
{tags:resource}Recover 1% of Life on Kill
5% chance to grant Onslaught to Enemies within 2 metres on Kill
5% chance to grant Chaotic Might to Enemies within 2 metres on Kill
{variant:1}5% chance to gain Onslaught for 10 seconds on Kill
{variant:2}10% chance to gain Onslaught for 10 seconds on Kill
{variant:1}5% chance to gain Chaotic Might for 10 seconds on Kill
{variant:2}10% chance to gain Chaotic Might for 10 seconds on Kill
]],[[
Eye of Chayula
Onyx Amulet
Upgrade: Upgrades to unique{Presence of Chayula} using currency{Blessing of Chayula}
Implicits: 1
{tags:attribute}+(10-16) to all Attributes
{tags:resource}20% reduced maximum Life
+30% to Item Rarity
Cannot be Stunned
]],[[
Presence of Chayula
Onyx Amulet
League: Breach
Source: Upgraded from unique{Eye of Chayula} using currency{Blessing of Chayula}
Requires Level 60
Implicits: 1
{tags:attribute}+(10-16) to all Attributes
+30% to Item Rarity
{tags:resistance}+60% to Chaos Resistance
Cannot be Stunned
{tags:resource,defences}20% of Maximum Life Converted to Energy Shield
]],[[
Eye of Innocence
Citrine Amulet
Requires Level 68
Implicits: 1
{tags:attribute}+(16-24) to Strength and Dexterity
10% chance to Ignite
(50-70)% increased Damage while Ignited
{tags:elemental_damage}Take 100 Fire Damage when you Ignite an Enemy
{tags:resource}2% of Fire Damage Leeched as Life while Ignited
]],[[
Eyes of the Greatwolf
Greatwolf Talisman
Version: Pre 3.25.0
Version: Pre 3.29.0
Version: Current
Selected Variant Group: 1=65
Selected Variant Group: 2=41
Variant: Attributes
Variant: Global Defences
Variant: Chaos Damage
Variant: Attack Damage
Variant: Cold Damage
Variant: Fire Damage
Variant: Lightning Damage
Variant: Spell Damage
Variant: Global Physical Damage
Variant: Mana
Variant: Damage
Variant: Physical Damage Reduction
Variant: Chance to Freeze, Shock and Ignite
Variant: Crit Chance
Variant: Area of Effect
Variant: Attack/Cast Speed
Variant: Item Quantity (Pre 3.25.0)
Variant: Life
Variant: Crit Multiplier
Variant: Maximum number of Raised Zombies
Variant: Frenzy Charge on Kill
Variant: Power Charge on Kill
Variant: Endurance Charge on Kill
Variant: Life Regen
Variant: Cold taken as Fire
Variant: Cold taken as Lightning
Variant: Fire taken as Cold
Variant: Fire taken as Lightning
Variant: Lightning taken as Cold
Variant: Lightning taken as Fire
Variant: Gain Physical as random Element
Variant: Extra Pierces
Variant: Damage over Time Multiplier
Variant: Action Speed
Variant: Extra Pierces
Variant: Additional Projectile
Variant: Global Defences
Variant: Area of Effect
Variant: Cold and Lightning taken as Fire
Variant: Cold Penetration
Variant: Crit Multiplier
Variant: Fire Penetration
Variant: Freeze Enemies when Hit
Variant: Cooldown Recovery
Variant: Damage over Time Multiplier
Variant: Herald Gem Levels
Variant: Skill Gem Levels
Variant: Skill Gem Quality
Variant: Ignore Physical Damage Reduction
Variant: Maximum Power Charges
Variant: Lightning Penetration
Variant: Mark Effect
Variant: Maximum Cold Resistance
Variant: Maximum Endurance Charges
Variant: Maximum Fire Resistance
Variant: Maximum Frenzy Charges
Variant: Life as Extra Armour
Variant: Life
Variant: Maximum Lightning Resistance
Variant: Mana
Variant: Maximum Spectres
Variant: Minimum Charges
Variant: Minion Damage over Time Multiplier
Variant: Movement Speed
Variant: Attributes
Variant: Projectile Speed
Variant: Unaffected by Ignite
Variant: Utility Flask Charges
Variant: Additional Exerted Attack
Variant: Withered Effect
Requires Level 52
Implicits: 70
{version:1,2}{variant:1}{group:1,2}{tags:attribute}(12-16)% increased Attributes
{version:3}{variant:65}{group:1,2}{tags:attribute}{enchant}15% increased Attributes
{version:1,2}{variant:11}{group:1,2}(25-35)% increased Damage
{version:1,2}{variant:4}{group:1,2}{tags:attack}(20-30)% increased Attack Damage
{version:1,2}{variant:8}{group:1,2}{tags:caster}(20-30)% increased Spell Damage
{version:1,2}{variant:9}{group:1,2}{tags:physical_damage}(20-30)% increased Global Physical Damage
{version:1,2}{variant:33}{group:1,2}+(12-18)% to Damage over Time Multiplier
{version:3}{variant:45}{group:1,2}{enchant}+20% to Damage over Time Multiplier
{version:1,2}{variant:6}{group:1,2}{tags:elemental_damage}(20-30)% increased Fire Damage
{version:1,2}{variant:5}{group:1,2}{tags:elemental_damage}(20-30)% increased Cold Damage
{version:1,2}{variant:7}{group:1,2}{tags:elemental_damage}(20-30)% increased Lightning Damage
{version:1,2}{variant:3}{group:1,2}{tags:chaos_damage}(19-31)% increased Chaos Damage
{version:1,2}{variant:14}{group:1,2}{tags:critical}(40-50)% increased Global Critical Strike Chance
{version:1,2}{variant:19}{group:1,2}{tags:critical}+(24-36)% to Global Critical Strike Multiplier
{version:3}{variant:41}{group:1,2}{tags:critical}{enchant}+40% to Global Critical Strike Multiplier
{version:1,2}{variant:18}{group:1,2}{tags:resource}(8-12)% increased maximum Life
{version:3}{variant:58}{group:1,2}{tags:resource}{enchant}15% increased maximum Life
{version:1,2}{variant:10}{group:1,2}{tags:resource}(20-30)% increased maximum Mana
{version:3}{variant:60}{group:1,2}{tags:resource}{enchant}30% increased maximum Mana
{version:1}{variant:17}{group:1,2}(6-10)% increased Quantity of Items found
{version:3}{variant:55}{group:1,2}{tags:resistance}{enchant}+4% to maximum Fire Resistance
{version:3}{variant:53}{group:1,2}{tags:resistance}{enchant}+4% to maximum Cold Resistance
{version:3}{variant:59}{group:1,2}{tags:resistance}{enchant}+4% to maximum Lightning Resistance
{version:1,2}{variant:32}{group:1,2}Projectiles Pierce 2 additional Targets
{version:3}{variant:35}{group:1,2}{enchant}Projectiles Pierce 3 additional Targets
{version:3}{variant:36}{group:1,2}{enchant}Skills fire an additional Projectile
{version:3}{variant:66}{group:1,2}{tags:speed}{enchant}30% increased Projectile Speed
{version:3}{variant:64}{group:1,2}{tags:speed}{enchant}12% increased Movement Speed
{version:3}{variant:54}{group:1,2}{enchant}+1 to Maximum Endurance Charges
{version:3}{variant:56}{group:1,2}{enchant}+1 to Maximum Frenzy Charges
{version:3}{variant:50}{group:1,2}{enchant}+1 to Maximum Power Charges
{version:1,2}{variant:15}{group:1,2}(5-8)% increased Area of Effect
{version:3}{variant:38}{group:1,2}{enchant}16% increased Area of Effect
{version:1,2}{variant:24}{group:1,2}{tags:resource}Regenerate 2% of Life per second
{version:1,2}{variant:16}{group:1,2}{tags:attack,caster,speed}(6-10)% increased Attack and Cast Speed
{version:1,2}{variant:20}{group:1,2}+1 to maximum number of Raised Zombies
{version:3}{variant:61}{group:1,2}{enchant}+1 to maximum number of Spectres
{version:1,2}{variant:12}{group:1,2}(4-6)% additional Physical Damage Reduction
{version:3}{variant:52}{group:1,2}{tags:caster}{enchant}30% increased Effect of your Marks
{version:1,2}{variant:23}{group:1,2}10% chance to gain an Endurance Charge on Kill
{version:1,2}{variant:21}{group:1,2}10% chance to gain a Frenzy Charge on Kill
{version:1,2}{variant:22}{group:1,2}10% chance to gain a Power Charge on Kill
{version:1,2}{variant:13}{group:1,2}(4-6)% chance to Freeze, Shock and Ignite
{version:1,2}{variant:2}{group:1,2}{tags:defences}(15-25)% increased Global Defences
{version:3}{variant:37}{group:1,2}{tags:defences}{enchant}30% increased Global Defences
{version:1,2}{variant:31}{group:1,2}{tags:physical_damage,elemental_damage}Gain (6-12)% of Physical Damage as Extra Damage of a random Element
{version:3}{variant:42}{group:1,2}{tags:elemental_damage}{enchant}Damage Penetrates 15% Fire Resistance
{version:3}{variant:40}{group:1,2}{tags:elemental_damage}{enchant}Damage Penetrates 15% Cold Resistance
{version:3}{variant:51}{group:1,2}{tags:elemental_damage}{enchant}Damage Penetrates 15% Lightning Resistance
{version:1,2}{variant:27}{group:1,2}50% of Fire Damage from Hits taken as Cold Damage
{version:1,2}{variant:28}{group:1,2}50% of Fire Damage from Hits taken as Lightning Damage
{version:1,2}{variant:25}{group:1,2}50% of Cold Damage from Hits taken as Fire Damage
{version:1,2}{variant:26}{group:1,2}50% of Cold Damage from Hits taken as Lightning Damage
{version:3}{variant:39}{group:1,2}{enchant}100% of Cold and Lightning Damage from Hits taken as Fire Damage
{version:1,2}{variant:30}{group:1,2}50% of Lightning Damage from Hits taken as Fire Damage
{version:1,2}{variant:29}{group:1,2}50% of Lightning Damage from Hits taken as Cold Damage
{version:3}{variant:34}{group:1,2}{tags:speed}{enchant}8% increased Action Speed
{version:3}{variant:47}{group:1,2}{enchant}+1 to Level of all Skill Gems
{version:3}{variant:48}{group:1,2}{enchant}+15% to Quality of all Skill Gems
{version:3}{variant:44}{group:1,2}{enchant}20% increased Cooldown Recovery Rate
{version:3}{variant:63}{group:1,2}{enchant}Minions have +30% to Damage over Time Multiplier
{version:3}{variant:43}{group:1,2}{enchant}20% chance to Freeze Enemies for 1 second when they Hit you
{version:3}{variant:46}{group:1,2}{enchant}+2 to Level of all Herald Skill Gems
{version:3}{variant:49}{group:1,2}{enchant}Hits ignore Enemy Physical Damage Reduction
{version:3}{variant:57}{group:1,2}{tags:defences}{enchant}Gain 15% of Maximum Life as Extra Armour
{version:3}{variant:62}{group:1,2}{enchant}+1 to Minimum Endurance, Frenzy and Power Charges
{version:3}{variant:67}{group:1,2}{enchant}Unaffected by Ignite
{version:3}{variant:68}{group:1,2}{enchant}Utility Flasks gain 2 Charges every 3 seconds
{version:3}{variant:69}{group:1,2}{enchant}Warcries Exert 1 additional Attack
{version:3}{variant:70}{group:1,2}{enchant}35% increased Effect of Withered
{version:3}(50-100)% increased Enchantment Modifier magnitudes
{version:1,2}Implicit Modifier magnitudes are doubled
]],[[
The Felbog Fang
Citrine Amulet
League: Harvest
Source: Drops from unique{Namharim, Born of Night} in normal{The Sacred Grove}
Variant: Pre 3.20.0
Variant: Current
Requires Level 61
Implicits: 1
{tags:attribute}+(16-24) to Strength and Dexterity
{tags:attribute}+(30-50) to Intelligence
{tags:caster,speed}(10-15)% increased Cast Speed
(10-15)% increased Area of Effect
{variant:1,2}{tags:caster}Enemies Cursed by you are Hindered if 25% of Curse Duration expired
{tags:caster}Your Curses have 25% increased Effect if 50% of Curse Duration expired
{variant:1}{tags:caster}Enemies Cursed by you take 25% increased Damage if 75% of Curse Duration expired
{variant:2}{tags:caster}Enemies Cursed by you take 35% increased Damage if 75% of Curse Duration expired
]],[[
Fury Valve
Turquoise Amulet
Requires Level 40
Implicits: 1
{tags:attribute}+(16-24) to Dexterity and Intelligence
{tags:defences}(15-25)% increased Evasion Rating
{tags:resistance}+(15-20)% to all Elemental Resistances
Skills fire 2 additional Projectiles
{tags:speed}(20-30)% increased Projectile Speed
Modifiers to number of Projectiles instead apply
to the number of targets Projectiles Split towards
]],[[
Gloomfang
Blue Pearl Amulet
Variant: Pre 3.11.0
Variant: Current
Implicits: 1
{tags:resource}(48-56)% increased Mana Regeneration Rate
{tags:resource}0.5% of Chaos Damage Leeched as Life
{tags:resource,caster}Lose (10-15) Life per Enemy Hit with Spells
{tags:resource,attack}Lose (20-25) Life per Enemy Hit with Attacks
Skills Chain +1 times
{variant:2}{tags:speed}(30-40)% increased Projectile Speed
{variant:2}{tags:chaos_damage}Projectiles that have Chained gain (20-35)% of Non-Chaos Damage as extra Chaos Damage
{variant:1}{tags:chaos_damage}Projectiles gain (15-20)% of Non-Chaos Damage as extra Chaos Damage per Chain
]],[[
The Halcyon
Jade Amulet
Variant: Pre 3.21.0
Variant: Current
League: Breach
Source: Drops in Tul Breach or from unique{Tul, Creeping Avalanche}
Upgrade: Upgrades to unique{The Pandemonius} using currency{Blessing of Tul}
Requires Level 35
Implicits: 1
{tags:attribute}+(20-30) to Dexterity
{variant:1}{tags:elemental_damage}(10-20)% increased Cold Damage
{tags:resistance}+(35-40)% to Cold Resistance
30% increased Freeze Duration on Enemies
10% chance to Freeze
{variant:2}Freezes you inflict spread to other Enemies within 1.5 metres
60% increased Damage if you've Frozen an Enemy Recently
]],[[
The Pandemonius
Jade Amulet
League: Breach
Source: Upgraded from unique{The Halcyon} using currency{Blessing of Tul}
Requires Level 64
Implicits: 1
{tags:attribute}+(20-30) to Dexterity
{tags:elemental_damage}(20-30)% increased Cold Damage
{tags:resistance}+(35-40)% to Cold Resistance
Chill Enemy for 1 second when Hit, reducing their Action Speed by 30%
Blind Chilled Enemies on Hit
{tags:elemental_damage}Damage Penetrates 20% Cold Resistance against Chilled Enemies
]],[[
Hinekora's Sight
Onyx Amulet
Variant: Pre 3.16.0
Variant: Pre 3.37.0
Variant: Current
Requires Level 44
Implicits: 1
{tags:attribute}+(10-16) to all Attributes
{variant:2}Prevent +3% of Suppressed Spell Damage
{variant:3}Prevent +(4-6)% of Suppressed Spell Damage
{variant:1}+(6-10)% chance to Suppress Spell Damage
{variant:1}+(6-10)% chance to Suppress Spell Damage
{variant:1}{tags:attack}+1000 to Accuracy Rating
{variant:2,3}{tags:attack}+(600-1000) to Accuracy Rating
{variant:2,3}{tags:defences}+(600-1000) to Evasion Rating
Cannot be Blinded
]],[[
Replica Hinekora's Sight
Onyx Amulet
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 44
Implicits: 1
{tags:attribute}+(10-16) to all Attributes
{tags:attack}+(600-1000) to Accuracy Rating
{tags:defences}+(600-1000) to Armour
{tags:resistance}+1% to all maximum Elemental Resistances
You cannot be Maimed
]],[[
Hyrri's Truth
Jade Amulet
League: Synthesis
Variant: Pre 3.16.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 64
Implicits: 1
{tags:attribute}+(20-30) to Dexterity
{variant:1,2}Grants Level 22 Precision
{variant:3}Grants Level 30 Precision
{variant:1,2}{tags:attribute}+(25-35) to Dexterity
{variant:3}{tags:attribute}+(40-80) to Dexterity
{variant:1,2}{tags:physical_damage,attack}Adds (12-15) to (24-28) Physical Damage to Attacks
{variant:1,2}{tags:elemental_damage,attack}Adds (11-15) to (23-28) Cold Damage to Attacks
{variant:1,2}{tags:critical}+(23-28)% to Global Critical Strike Multiplier
{variant:3}{tags:critical}+(25-50)% to Global Critical Strike Multiplier
{variant:1,2}{tags:resource,attack}(0.8-1)% of Physical Attack Damage Leeched as Life
{variant:3}Bow Attacks have Culling Strike
{variant:1,2,3}{tags:resource}Precision has 100% increased Mana Reservation Efficiency
]],[[
Replica Hyrri's Truth
Jade Amulet
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Variant: Pre 3.16.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 64
Implicits: 1
{tags:attribute}+(20-30) to Dexterity
Grants Level 22 Hatred
{variant:1,2}{tags:attribute}+(25-35) to Dexterity
{variant:3}{tags:attribute}+(30-55) to Dexterity
{variant:1,2}{tags:physical_damage,attack}Adds (12-15) to (24-28) Physical Damage to Attacks
{variant:1,2}{tags:elemental_damage,attack}Adds (11-15) to (23-28) Cold Damage to Attacks
{variant:1,2}{tags:critical}+(23-28)% to Global Critical Strike Multiplier
{variant:3}{tags:critical}+(18-35)% to Global Critical Strike Multiplier
{variant:3}Bow Attacks have Culling Strike
{variant:1,2,3}{tags:resource}Hatred has 100% increased Mana Reservation Efficiency
{variant:1,2}(0.8-1)% of Cold Damage Leeched as Life
]],[[
The Ignomon
Gold Amulet
Variant: Pre 3.19.0
Variant: Current
Implicits: 1
+(12-20)% to Item Rarity
{variant:1}{tags:attribute}+10 to Dexterity
{variant:1}{tags:elemental_damage,attack}Adds 12 to 24 Fire Damage to Attacks
{variant:2}{tags:elemental_damage,attack}Adds (18-24) to (32-40) Fire Damage to Attacks
{tags:attack}+(100-150) to Accuracy Rating
{tags:defences}+(100-150) to Evasion Rating
{tags:resistance}+20% to Fire Resistance
{variant:2}20% increased Light Radius
{variant:2}Enemies within 3.5 metres are Blinded
]],[[
The Effigon
Gold Amulet
Source: No longer obtainable
Requires Level 57
Implicits: 1
+(12-20)% to Item Rarity
{tags:attribute}+10 to Dexterity
{tags:elemental_damage,attack}Adds 12 to 24 Fire Damage to Attacks
{tags:attack}+(100-150) to Accuracy Rating
{tags:defences}+(100-150) to Evasion Rating
{tags:resistance}+20% to Fire Resistance
{tags:attack}Your Hits can't be Evaded by Blinded Enemies
{tags:elemental_damage}Damage Penetrates 10% Fire Resistance against Blinded Enemies
]],[[
Ikiaho's Promise
Coral Amulet
Requires Level 30
Implicits: 1
{tags:resource}Regenerate (2-4) Life per second
{tags:resource}Regenerate (3-5) Mana per second
{tags:resource}(30-40)% increased Life Recovery from Flasks
{tags:resource}(20-30)% increased Mana Recovery from Flasks
{tags:resource}Life Flasks used while on Low Life apply Recovery Instantly
{tags:resource}Mana Flasks used while on Low Mana apply Recovery Instantly
]],[[
Impresence
Onyx Amulet
Elder Item
Source: Drops from unique{The Elder}
Variant: Physical
Variant: Fire
Variant: Cold
Variant: Lightning
Variant: Chaos
Requires Level 64
Implicits: 1
{tags:attribute}+(10-16) to all Attributes
{variant:5}(30-40)% increased Damage over Time
{variant:1}{tags:physical_damage}Adds (12-16) to (20-25) Physical Damage
{variant:2}{tags:elemental_damage}Adds (20-24) to (33-36) Fire Damage
{variant:3}{tags:elemental_damage}Adds (20-24) to (33-36) Cold Damage
{variant:4}{tags:elemental_damage}Adds (10-13) to (43-47) Lightning Damage
{variant:5}{tags:chaos_damage}Adds (17-19) to (23-29) Chaos Damage
{variant:1}{tags:defences}+(400-500) to Armour
{tags:resource}+(50-70) to maximum Life
{variant:3}{tags:resource}(45-50)% increased Mana Regeneration Rate
{variant:2}{tags:resistance}+(20-25)% to Fire Resistance
{variant:3}{tags:resistance}+(20-25)% to Cold Resistance
{variant:4}{tags:resistance}+(20-25)% to Lightning Resistance
{variant:5}{tags:resistance}+(17-23)% to Chaos Resistance
{variant:1}(30-40)% increased Stun and Block Recovery
{variant:2}{tags:resource}Regenerate 1% of Life per second
{variant:4}{tags:defences}Regenerate 1% of Energy Shield per second
{variant:4}{tags:caster}Conductivity has no Reservation if Cast as an Aura
{variant:5}{tags:caster}Despair has no Reservation if Cast as an Aura
{variant:2}{tags:caster}Flammability has no Reservation if Cast as an Aura
{variant:3}{tags:caster}Frostbite has no Reservation if Cast as an Aura
{variant:1}{tags:caster}Vulnerability has no Reservation if Cast as an Aura
Gain Maddening Presence for 10 seconds when you Kill a Rare or Unique Enemy
]],[[
Karui Ward
Jade Amulet
Variant: Pre 2.6.0
Variant: Current
Implicits: 1
{tags:attribute}+(20-30) to Dexterity
{tags:attribute}+(20-30) to Strength
{tags:attack}+100 to Accuracy Rating
{tags:speed}30% increased Projectile Speed
{tags:speed}10% increased Movement Speed
{variant:2}30% increased Projectile Damage
]],[[
Replica Karui Ward
Jade Amulet
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 1
{tags:attribute}+(20-30) to Dexterity
{tags:attribute}+(20-30) to Intelligence
{tags:attack}+100 to Accuracy Rating
{tags:speed}10% increased Movement Speed
30% increased Area of Effect
30% increased Area Damage
]],[[
Karui Charge
Jade Amulet
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Current
Requires Level 24
Implicits: 1
{tags:attribute}+(20-30) to Dexterity
{tags:attribute}+(20-30) to Strength
{variant:1}{tags:attack,speed}(15-20)% increased Attack Speed
{variant:2}{tags:attack,speed}(5-10)% increased Attack Speed
{tags:attack}+100 to Accuracy Rating
{tags:speed}30% increased Projectile Speed
{tags:speed}10% increased Movement Speed
{variant:2}30% increased Projectile Damage
]],[[
Khatal's Geyser
Lapis Amulet
League: Mirage
Source: No longer obtainable
Requires Level 56
Implicits: 1
{tags:attribute}+(20-30) to Intelligence
Can't use Life Flasks
{tags:resource}+(55-70) to maximum Mana
Increases and Reductions to Effect of Flasks applied to you
also applies to Effect of Arcane Surge on you at (200-250)% of their value
You have Arcane Surge during Effect of any Mana Flask
{tags:resource}Mana Flask Effects are not removed when Unreserved Mana is Filled
{tags:resource}Mana Flask Effects do not Queue
]],
[[
Khatal's Weeping
Lapis Amulet
League: Mirage
Source: No longer obtainable
Requires Level 56
Implicits: 1
{tags:attribute}+(20-30) to Intelligence
{tags:resource}+(80-100) to maximum Life
{tags:resource}Can't use Mana Flasks
{tags:resource}On non-channelling Attack, set a Life Flask with greater than 50% of maximum Charges remaining to 50%
{tags:resource}For each Charge removed this way, that Attack gains +2% to Damage over time Multiplier
{tags:resource}While on Low Life, Life Flasks gain (3-6) Charges every 3 seconds
]],[[
Leadership's Price
Onyx Amulet
League: Heist
Source: Drops from unique{Vic Vox} and unique{Vinny Vox} in normal{Contract: The Twins}
Requires Level 68
Implicits: 1
{tags:attribute}+(10-16) to all Attributes
{tags:resistance}+(-3-3)% to maximum Fire Resistance
{tags:resistance}+(-3-3)% to maximum Cold Resistance
{tags:resistance}+(-3-3)% to maximum Lightning Resistance
You have Scorching Conflux, Brittle Conflux and Sapping Conflux while your two highest Attributes are equal
Cannot Ignite, Chill, Freeze or Shock
Corrupted
]],[[
Maligaro's Cruelty
Turquoise Amulet
Requires Level 20
Implicits: 1
{tags:attribute}+(16-24) to Dexterity and Intelligence
{tags:resource}(4-8)% increased maximum Life
(25-30)% chance to gain a Frenzy Charge on Killing an Enemy affected by at least 5 Poisons
(12-15)% chance to gain a Power Charge on Killing an Enemy affected by fewer than 5 Poisons
{tags:chaos_damage}10% increased Damage with Poison per Frenzy Charge
3% increased Poison Duration per Power Charge
]],[[
The Jinxed Juju
Citrine Amulet
Variant: Pre 3.16.0
Variant: Pre 3.20.0
Variant: Current
Requires Level 48
Implicits: 1
{tags:attribute}+(16-24) to Strength and Dexterity
{tags:attribute}+(30-40) to Intelligence
{tags:resistance}+(23-31)% to Chaos Resistance
{variant:1}{tags:caster}(10-15)% increased Effect of your Curses
{variant:2}{tags:caster}(5-10)% increased Effect of your Curses
{variant:1,3}(10-15)% increased effect of Non-Curse Auras from your Skills
{variant:2}(5-10)% increased effect of Non-Curse Auras from your Skills
10% of Damage from Hits is taken from your Raised Spectres' Life before you
]],[[
Marylene's Fallacy
Lapis Amulet
Variant: Pre 1.3.0
Variant: Pre 2.0.0
Variant: Pre 2.2.0
Variant: Pre 2.6.0
Variant: Current
Requires Level 40
Implicits: 1
{tags:attribute}+(20-30) to Intelligence
{tags:attack}+(80-120) to Accuracy Rating
{variant:1,2,3}{tags:critical}+(140-160)% to Global Critical Strike Multiplier
{variant:4,5}{tags:critical}+(210-240)% to Global Critical Strike Multiplier
{tags:defences}+(80-100) to Evasion Rating
(10-15)% increased Light Radius
{variant:1}{tags:critical}60% less Critical Strike Chance
{variant:2}{tags:critical}50% less Critical Strike Chance
{variant:3,4,5}{tags:critical}40% less Critical Strike Chance
{tags:critical}Critical Strikes have Culling Strike
]],[[
Natural Hierarchy
{variant:1}Rotfeather Talisman
{variant:2}Rhex Talisman
Variant: Pre 3.29.0
Variant: Current
League: Talisman Standard, Talisman Hardcore
Talisman Tier: 3
Requires Level 44
Implicits: 1
{variant:1}(25-35)% increased Damage
{variant:1}{tags:physical_damage}(10-15)% increased Global Physical Damage
{variant:1}{tags:elemental_damage}(25-30)% increased Fire Damage
{variant:1}{tags:elemental_damage}(20-25)% increased Cold Damage
{variant:1}{tags:elemental_damage}(15-20)% increased Lightning Damage
{variant:1}{tags:chaos_damage}(30-35)% increased Chaos Damage
{variant:2}{tags:physical_damage,elemental_damage}Gain (10-15)% of Physical Damage as Extra Lightning Damage
{variant:2}{tags:elemental_damage}Gain (15-20)% of Lightning Damage as Extra Cold Damage
{variant:2}{tags:elemental_damage}Gain (20-25)% of Cold Damage as Extra Fire Damage
{variant:2}{tags:elemental_damage,chaos_damage}Gain (25-30)% of Fire Damage as Extra Chaos Damage
{variant:1}Corrupted
]],[[
Night's Hold
Black Maw Talisman
League: Talisman Standard, Talisman Hardcore
Talisman Tier: 1
Requires Level 12
Implicits: 1
Has 1 Socket
+2 to Level of Socketed Gems
Socketed Gems are Supported by Level 10 Added Chaos Damage Support
Socketed Gems are Supported by Level 10 Blind Support
Socketed Gems are Supported by Level 10 Cast when Stunned Support
Corrupted
]],[[
Perquil's Toe
Gold Amulet
Requires Level 29
Implicits: 1
+(12-20)% to Item Rarity
{tags:attribute}+(40-50) to Dexterity
{tags:speed}(5-8)% increased Movement Speed
{tags:elemental_damage}Lightning Damage of Enemies Hitting you is Lucky
Damage with Hits of Allies within 5 metres is Lucky
]],[[
The Primordial Chain
Coral Amulet
League: Delve
Variant: Pre 3.26.0
Variant: Current
Requires Level 34
Implicits: 1
{tags:resource}Regenerate (2-4) Life per second
+3 to maximum number of Summoned Golems
You cannot have non-Golem Minions
25% reduced Golem Size
{variant:1}Golems Deal (45-35)% less Damage
{variant:2}Golems Deal (25-35)% less Damage
{variant:1}{tags:resource}Golems have (45-35)% less Life
{variant:2}{tags:resource}Golems have (25-35)% less Life
{tags:speed}Golems have (80-100)% increased Movement Speed
Primordial
]],[[
Rashkaldor's Patience
Jade Amulet
Variant: Pre 3.19.0
Variant: Current
Requires Level 48
Implicits: 1
{tags:attribute}+(20-30) to Dexterity
{tags:resource}+(40-80) to maximum Life
{tags:resource}+(20-40) to maximum Mana
{variant:1}20% increased Duration of Elemental Ailments on Enemies
{variant:2}20% reduced Duration of Elemental Ailments on Enemies
{variant:1}Items and Gems have 10% reduced Attribute Requirements
{variant:2}Items and Gems have 10% increased Attribute Requirements
{variant:1}5% chance to Freeze, Shock and Ignite
{variant:2}Always Freeze, Shock and Ignite
{variant:1}Cannot gain Power Charges
]],[[
Retaliation Charm
Citrine Amulet
Variant: Pre 3.19.0
Variant: Current
Requires Level 30
Implicits: 1
{tags:attribute}+(16-24) to Strength and Dexterity
{variant:1}(25-40)% increased Damage with Hits and Ailments against Blinded Enemies
{variant:1}{tags:critical}(30-50)% increased Critical Strike Chance against Blinded Enemies
{variant:1}{tags:critical}(40-50)% chance to Blind Enemies on Critical Strike
{variant:2}{tags:attack}(10-20)% chance to Blind Enemies on Hit with Attacks
Blind does not affect your Light Radius
Blind you inflict is Reflected to you
{variant:2}(10-20)% chance to gain a Frenzy Charge on Hit while Blinded
]],[[
Rigwald's Curse
{variant:1,2}Wereclaw Talisman
{variant:3}Wolf Alpha Talisman
League: Talisman Standard
Variant: Pre 2.2.0
Variant: Pre 3.29.0
Variant: Current
Talisman Tier: 2
Requires Level 28
Implicits: 2
{variant:1}{tags:critical}+(16-24)% to Global Critical Strike Multiplier
{variant:2}{tags:critical}+(24-36)% to Global Critical Strike Multiplier
{variant:1,2}{tags:critical}+7% to Unarmed Melee Attack Critical Strike Chance
{variant:3}{tags:critical}+(5-10)% to Unarmed Melee Attack Critical Strike Chance
{tags:attack}Modifiers to Claw Damage also apply to Unarmed Attack Damage with Melee Skills
{tags:attack,speed}Modifiers to Claw Attack Speed also apply to Unarmed Attack Speed with Melee Skills
{tags:attack,critical}Modifiers to Claw Critical Strike Chance also apply to Unarmed Critical Strike Chance with Melee Skills
{variant:1,2}Corrupted
]],[[
Rotmother's Mutiny
Pearlescent Amulet
Variant: Fire
Variant: Cold
Variant: Lightning
League: Allflame
Source: Drops from Treasure Clam chests in normal{The Fathomless Depths}
Requires Level 28
Implicits: 1
{tags:resistance}+(8-10)% to all Elemental Resistances
{tags:resistance}+(20-25)% to all Elemental Resistances
{tags:resistance}+(1-3)% to all maximum Resistances
(20-40)% increased Light Radius
{variant:2}+1% to Chaos Resistance per 1% Cold Resistance
{variant:1}+1% to Chaos Resistance per 1% Fire Resistance
{variant:3}+1% to Chaos Resistance per 1% Lightning Resistance
]],[[
Sacrificial Heart
Paua Amulet
Variant: Pre 3.14.0
Variant: Current
League: Incursion
Source: Drops from unique{The Vaal Omnitect}
Upgrade: Upgrades to unique{Zerphi's Heart} via currency{Vial of Sacrifice}
Requires Level 32
Implicits: 1
{tags:resource}(20-30)% increased Mana Regeneration Rate
{tags:elemental_damage}Adds (22-27) to (34-38) Fire Damage
{tags:elemental_damage}Adds (20-23) to (31-35) Cold Damage
{tags:elemental_damage}Adds (1-3) to (47-52) Lightning Damage
{variant:2}Gain up to maximum Power Charges when you use a Vaal Skill
{variant:1}Gain a Power Charge when you use a Vaal Skill
{tags:resource}Gain 10 Life per Enemy Hit if you have used a Vaal Skill Recently
{tags:speed}10% increased Movement Speed if you have used a Vaal Skill Recently
]],[[
Zerphi's Heart
Paua Amulet
League: Incursion
Source: Upgraded from unique{Sacrificial Heart} via currency{Vial of Sacrifice}
Variant: Pre 3.10.0
Variant: Current
Requires Level 70
Implicits: 1
{tags:resource}(20-30)% increased Mana Regeneration Rate
{tags:chaos_damage}Adds (48-53) to (58-60) Chaos Damage
Items and Gems have 50% increased Attribute Requirements
Chaos Damage can Ignite, Chill and Shock
{variant:1}Gain Soul Eater for 10 seconds when you use a Vaal Skill
{variant:2}Gain Soul Eater for 20 seconds when you use a Vaal Skill
]],[[
Shaper's Seed
Agate Amulet
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 1
{tags:attribute}+(16-24) to Strength and Intelligence
{variant:1,2}{tags:resource}(30-50)% increased Mana Regeneration Rate
{variant:3}{tags:resource}(60-100)% increased Mana Regeneration Rate
{variant:1,2}{tags:resource}Regenerate 2% of Life per second
{variant:3}{tags:resource}Regenerate 4% of Life per second
{variant:1}{tags:resource}Allies within 5 metres gain 1% of Life Regenerated per second
{variant:2}{tags:resource}Allies within 5 metres gain 2% of Life Regenerated per second
{variant:3}{tags:resource}Allies within 5 metres gain 4% of Life Regenerated per second
{variant:1,2}{tags:resource}Allies within 5 metres gain 40% increased Mana Regeneration Rate
{variant:3}{tags:resource}Allies within 5 metres gain 80% increased Mana Regeneration Rate
]],[[
Sidhebreath
Paua Amulet
Variant: Pre 3.0.0
Variant: Pre 3.8.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 1
{tags:resource}(20-30)% increased Mana Regeneration Rate
{tags:resistance}+25% to Cold Resistance
{variant:1,2}{tags:resource,attack}0.2% of Physical Attack Damage Leeched as Mana
{tags:resource}Minions have (10-15)% increased maximum Life
{variant:1,2,3}{tags:speed}Minions have (10-15)% increased Movement Speed
{variant:4}Minions convert 50% of Physical Damage to Cold Damage
{variant:1,2}Minions deal (10-15)% increased Damage
{variant:3}{tags:elemental_damage}Minions deal (5-9) to (11-15) additional Cold Damage
{variant:4}{tags:elemental_damage}Minions deal (25-35) to (50-65) additional Cold Damage
{variant:4}Minions deal no Non-Cold Damage
{variant:2,3}{tags:resource}(10-15)% reduced Mana Cost of Minion Skills
]],[[
Solstice Vigil
Onyx Amulet
Shaper Item
Source: Drops from unique{The Shaper}
Variant: Pre 3.10.0
Variant: Current
Requires Level 64
Implicits: 1
{tags:attribute}+(10-16) to all Attributes
{variant:1}(20-25)% increased Damage
{variant:2}(30-40)% increased Damage
{tags:resource}+(50-70) to maximum Life
{variant:1}{tags:resource}Regenerate (2-3) Mana per second
{variant:2}{tags:resource}Regenerate (8-10) Mana per second
Gain Shaper's Presence for 10 seconds when you kill a Rare or Unique Enemy
{tags:caster}Temporal Chains has no Reservation if Cast as an Aura
]],[[
Star of Wraeclast
Ruby Amulet
Source: Vendor Recipe
Variant: Pre 2.6.0
Variant: Pre 3.8.0
Variant: Current
Requires Level 28
Implicits: 1
{tags:resistance}+(20-30)% to Fire Resistance
{variant:3}Grants Level 10 Frostblink
{variant:1,2}Grants Illusory Warp
{tags:elemental_damage}(30-50)% increased Cold Damage
{tags:resistance}+(10-15)% to all Elemental Resistances
{variant:1}{tags:caster}30% increased Area of Effect of Hex Skills
{variant:2,3}{tags:caster}60% increased Area of Effect of Hex Skills
{tags:caster}You cannot be Cursed with Silence
{variant:3}{tags:caster}Frostblink has 50% increased Duration
Corrupted
]],[[
Stone of Lazhwar
Lapis Amulet
Variant: Pre 3.4.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 1
{tags:attribute}+(20-30) to Intelligence
{variant:1}15% Chance to Block Spell Damage
{variant:2,3}(12-15)% Chance to Block Spell Damage
{variant:1,2}{tags:caster,speed}(10-15)% increased Cast Speed
{variant:3}{tags:caster,speed}(15-20)% increased Cast Speed
{variant:1,2}{tags:resource}+(30-50) to maximum Mana
{variant:3}{tags:resource}+(40-70) to maximum Mana
]],[[
Stranglegasp
Onyx Amulet
Source: Drops in Blight-ravaged Maps
Requires Level 52
Implicits: 1
{tags:attribute}+(10-16) to all Attributes
Can have 3 additional Enchantment Modifiers
]],[[
Tavukai
Coral Amulet
League: Legion
Variant: Pre 3.19.0
Variant: Current
Requires Level 54
Implicits: 1
{tags:resource}Regenerate (2-4) Life per second
{tags:attribute}+(30-40) to Intelligence
{tags:resistance}Minions have +(-17-17)% to Chaos Resistance
Summon Raging Spirit has (20-30)% increased Duration
{variant:1}Summoned Raging Spirits deal (60-80)% increased Damage
{variant:2}Summoned Raging Spirits deal (25-40)% increased Damage
{variant:1}{tags:resource}Summoned Raging Spirits have (80-100)% increased maximum Life
{variant:2}{tags:resource}Summoned Raging Spirits have (25-40)% increased maximum Life
{tags:chaos_damage}Summoned Raging Spirits take 20% of their Maximum Life per second as Chaos Damage
]],[[
Tainted Pact
Coral Amulet
Requires Level 42
Implicits: 1
{tags:resource}Regenerate (2-4) Life per second
{tags:attribute}+(20-30) to Strength
{tags:resource,attack}(2-3)% of Physical Attack Damage Leeched as Life
{tags:resource,attack}(1-1.5)% of Physical Attack Damage Leeched as Mana
Taking Chaos Damage over Time heals you instead while Leeching Life
]],[[
Tear of Purity
Lapis Amulet
Variant: Pre 3.16.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 1
{tags:attribute}+(20-30) to Intelligence
{variant:1,2}{tags:attribute}+(5-10) to all Attributes
{variant:3}{tags:attribute}+(10-20) to all Attributes
{tags:resource}+(20-40) to maximum Life
{variant:2}{tags:resistance}+5% to all Elemental Resistances
{variant:3}{tags:resistance}+(5-10)% to all Elemental Resistances
{variant:1}5% chance to Avoid Elemental Ailments
]],[[
Ungil's Harmony
Turquoise Amulet
Variant: Pre 3.11.0
Variant: Current
Requires Level 23
Implicits: 1
{tags:attribute}+(16-24) to Dexterity and Intelligence
{variant:1}{tags:critical}100% increased Global Critical Strike Chance
{variant:2}{tags:critical}(250-350)% increased Global Critical Strike Chance
{tags:resource}+(30-50) to maximum Life
{tags:resource}+(30-50) to maximum Mana
40% increased Stun and Block Recovery
{tags:critical}Your Critical Strikes do not deal extra Damage
]],[[
The Utmost
Gold Amulet
Source: Created from unique{Primordial Fragments} obtained from Uber bosses
Requires Level 40
Implicits: 1
+(12-20)% to Item Rarity
+(0-30)% chance to Suppress Spell Damage
{tags:resistance}+(0-5)% to all maximum Elemental Resistances
{tags:attack,caster,speed}(0-40)% increased Attack and Cast Speed
{tags:elemental_damage}Damage Penetrates (0-20)% Elemental Resistances
Corrupted
]],[[
Uul-Netol's Vow
Unset Amulet
Source: Drops from unique{Breachlord} in a normal{Flawless Breachstone}
Requires Level 72
Implicits: 1
Has 1 Socket
Socketed Support Gems can also Support Skills from Equipped Body Armour
{tags:resistance}+(-30-30)% to Fire Resistance
{tags:resistance}+(-30-30)% to Cold Resistance
{tags:resistance}+(-30-30)% to Lightning Resistance
{tags:resistance}+(-23-23)% to Chaos Resistance
]],[[
Victario's Acuity
Turquoise Amulet
League: Onslaught
Implicits: 1
{tags:attribute}+(16-24) to Dexterity and Intelligence
{tags:resistance}+(30-40)% to Lightning Resistance
{tags:resistance}+(8-10)% to Chaos Resistance
10% chance to gain a Frenzy Charge on Kill
10% chance to gain a Power Charge on Kill
{tags:speed}5% increased Projectile Speed per Frenzy Charge
5% increased Projectile Damage per Power Charge
]],[[
Voice of the Storm
Lapis Amulet
League: Breach
Source: Drops in Esh Breach or from unique{Esh, Forked Thought}
Upgrade: Upgrades to unique{Choir of the Storm} using currency{Blessing of Esh}
Variant: Pre 3.16.0
Variant: Pre 3.21.0
Variant: Current
Requires Level 69
Implicits: 1
{tags:attribute}+(20-30) to Intelligence
{variant:1,2}{tags:critical}Trigger Level 12 Lightning Bolt when you deal a Critical Strike
{tags:attribute}+(10-15) to all Attributes
{variant:3}{tags:elemental_damage}50% increased Lightning Damage
{tags:resource}(10-20)% increased maximum Mana
{variant:1,2}{tags:critical}Critical Strike Chance is increased by Overcapped Lightning Resistance
{variant:3}Lightning Damage with Non-Critical Strikes is Lucky
]],[[
Choir of the Storm
Lapis Amulet
League: Breach
Source: Upgraded from unique{Voice of the Storm} using currency{Blessing of Esh}
Variant: Pre 3.0.0
Variant: Pre 3.16.0
Variant: Pre 3.21.0
Variant: Current
Requires Level 69
Implicits: 1
{tags:attribute}+(20-30) to Intelligence
{variant:1,2,3}{tags:critical}Trigger Level 20 Lightning Bolt when you deal a Critical Strike
{variant:4}{tags:critical}Trigger Level 30 Lightning Bolt when you deal a Critical Strike
{variant:1,2,3}{tags:elemental_damage}50% increased Lightning Damage
{tags:resource}(10-20)% increased maximum Mana
{variant:1,3,4}{tags:resistance}-30% to Lightning Resistance
{tags:critical}Critical Strike Chance is increased by Overcapped Lightning Resistance
]],[[
Voll's Devotion
Agate Amulet
League: Anarchy, Onslaught
Requires Level 32
Implicits: 1
{tags:attribute}+(16-24) to Strength and Intelligence
{tags:defences}+(20-30) to maximum Energy Shield
{tags:resource}+(30-40) to maximum Life
{tags:resistance}+(15-20)% to all Elemental Resistances
30% reduced Endurance Charge Duration
30% reduced Power Charge Duration
Gain an Endurance Charge when you lose a Power Charge
]],[[
Warped Timepiece
Turquoise Amulet
Variant: Pre 3.11.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 50
Implicits: 1
{tags:attribute}+(16-24) to Dexterity and Intelligence
{variant:1}{tags:attack,speed}(8-12)% increased Attack Speed
{variant:2}{tags:attack,speed}(10-15)% increased Attack Speed
{variant:3}{tags:attack,speed}(10-25)% increased Attack Speed
{variant:1}{tags:caster,speed}(8-12)% increased Cast Speed
{variant:2}{tags:caster,speed}(10-15)% increased Cast Speed
{variant:3}{tags:caster,speed}(10-25)% increased Cast Speed
{variant:1}{tags:speed}12% increased Movement Speed
{variant:2,3}{tags:speed}(10-15)% increased Movement Speed
{variant:1}(8-12)% increased Skill Effect Duration
{variant:2}(10-15)% increased Skill Effect Duration
{variant:3}(10-20)% reduced Skill Effect Duration
{variant:3}Debuffs on you expire 100% faster
{variant:1,2}{tags:resource,defences}30% increased total Recovery per second from Life, Mana, or Energy Shield Leech
]],[[
Willowgift
Jade Amulet
Requires Level 52
Implicits: 1
{tags:attribute}+(20-30) to Dexterity
{tags:attribute}10% reduced Strength
{tags:attribute}15% increased Dexterity
{tags:resistance}-(30-20)% to Fire Resistance
{tags:resistance}+(30-40)% to Cold Resistance
You do not inherently take less Damage for having Fortification
+4% chance to Suppress Spell Damage per Fortification
{tags:attack,caster,speed}(15-25)% increased Attack and Cast Speed while at maximum Fortification
]],[[
Winterheart
Gold Amulet
Variant: Pre 3.15.0
Variant: Current
Requires Level 42
Implicits: 1
+(12-20)% to Item Rarity
{tags:attribute}+(20-30) to Dexterity
{tags:resource}+(50-70) to maximum Life
{tags:resistance}+75% to Cold Resistance
Cannot be Chilled
{variant:1}{tags:resource}Regenerate 20% of Life per second while Frozen
{variant:2}{tags:resource}Regenerate 10% of Life per second while Frozen
]],[[
Replica Winterheart
Gold Amulet
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 42
Implicits: 1
+(12-20)% to Item Rarity
{tags:attribute}+(20-30) to Dexterity
{tags:defences}+(50-70) to maximum Energy Shield
{tags:resistance}+75% to Lightning Resistance
{tags:defences}Regenerate 5% of Energy Shield per second while Shocked
Unaffected by Shock
]],[[
Xoph's Heart
Amber Amulet
Variant: Pre 3.21.0
Variant: Current
League: Breach
Source: Drops in Xoph Breach or from unique{Xoph, Dark Embers}
Upgrade: Upgrades to unique{Xoph's Blood} using currency{Blessing of Xoph}
Requires Level 35
Implicits: 1
{tags:attribute}+(20-30) to Strength
{tags:attribute}+(20-30) to Strength
{tags:elemental_damage}25% increased Fire Damage
{tags:resource}+(25-35) to maximum Life
{tags:resistance}+(20-40)% to Fire Resistance
{variant:1}Cover Enemies in Ash when they Hit you
{variant:2}Enemies within 3 metres are Covered in Ash
]],[[
Xoph's Blood
Amber Amulet
League: Breach
Source: Upgraded from unique{Xoph's Heart} using currency{Blessing of Xoph}
Requires Level 64
Implicits: 1
{tags:attribute}+(20-30) to Strength
{tags:attribute}10% increased Strength
{tags:resource}10% increased maximum Life
{tags:resistance}+(20-40)% to Fire Resistance
{tags:elemental_damage}Damage Penetrates 10% Fire Resistance
Cover Enemies in Ash when they Hit you
{tags:elemental_damage}Avatar of Fire
]],[[
Yoke of Suffering
Onyx Amulet
Variant: Pre 3.24.0
Variant: Current
Requires Level 70
Implicits: 1
{tags:attribute}+(10-16) to all Attributes
{tags:resistance}+(10-20)% to Fire Resistance
{tags:resistance}+(10-20)% to Cold Resistance
{tags:resistance}+(20-40)% to Lightning Resistance
30% reduced Duration of Ailments on Enemies
(5-10)% chance to Shock
{variant:1}Enemies take 5% increased Damage for each type of Ailment you have inflicted on them
{variant:2}Enemies take (5-10)% increased Damage for each type of Ailment you have inflicted on them
Your Elemental Damage can Shock
]],[[
The Eternal Struggle
Onyx Amulet
Searing Exarch Item
Eater of Worlds Item
Source: Drops from unique{The Black Star} or unique{The Infinite Hunger}
Requires Level 61
Implicits: 2
{tags:speed}6% increased Movement Speed
9% increased Mana Reservation Efficiency of Skills
{tags:attribute}+(20-50) to Strength
{tags:attribute}+(20-50) to Dexterity
{tags:attribute}+(20-50) to Intelligence
{tags:defences}(10-15)% increased Global Defences
Critical Strikes inflict Malignant Madness if The Eater of Worlds is dominant
Kill Enemies that have 15% or lower Life on Hit if The Searing Exarch is dominant
]],[[
Venarius' Astrolabe
Astrolabe Amulet
Source: Drops from unique{Incarnation of Neglect} in normal{Moment of Loneliness}
Implicits: 2
Implicit Modifiers Cannot Be Changed
Has Elder, Shaper and all Conqueror Influences
The stars are aligned if you have 6 Influence types among other Equipped Items
You have Elemental Conflux if the stars are aligned
+(1-3) to Level of all Elemental Skill Gems if the stars are aligned
+(1-3) to Level of all Elemental Support Gems if the stars are aligned
]],[[
Whispers of Infinity
Seaglass Amulet
Variant: Pre 3.27.0
Variant: Current
Source: Drops from unique{Incarnation of Dread} in normal{Moment of Reverence}
Implicits: 1
{tags:defences}(20-30)% faster start of Energy Shield Recharge
{tags:chaos_damage,resource,attack}(5-10) to (20-25) Added Attack Chaos Damage per 100 Maximum Mana
{variant:1}{tags:defences}+(200-400) to maximum Energy Shield
{variant:2}{tags:defences}+(50-100) to maximum Energy Shield
{tags:resource}(40-60)% reduced maximum Mana
{tags:resource,defences}Skills Cost Energy Shield instead of Mana or Life
]],[[
Bonemeld
Marble Amulet
Source: Drops from unique{Incarnation of Dread} in normal{Moment of Reverence}
Implicits: 1
{tags:resource}Regenerate (1.4-2)% of Life per second
{tags:attribute}+(10-20) to all Attributes
+(1-2) to Level of all Minion Skill Gems
{tags:resistance}-2% to all Resistances per Minion from your Non-Vaal Skills
{tags:defences}(3-4)% increased Defences per Minion from your Non-Vaal Skills
{tags:resistance}Minions gain added Resistances equal to 50% of your Resistances
]],[[
Haunting Memories
Turquoise Amulet
Source: Drops from unique{Uber Incarnation of Neglect} in normal{Moment of Loneliness}
Requires Level 64
Implicits: 1
{tags:attribute}+(16-24) to Dexterity and Intelligence
+(6-10)% chance to Suppress Spell Damage
(50-100)% of Suppressed Spell Damage taken bypasses Energy Shield
(50-100)% of Suppressed Spell Damage taken Recouped as Energy Shield
{tags:attribute}+(20-30) to Dexterity and Intelligence
{tags:defences}+(40-60) to maximum Energy Shield
{tags:resource}+(40-60) to maximum Life
]],
}
