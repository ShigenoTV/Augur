-- Item data (c) Grinding Gear Games

return {
-- Flask: Life
[[
Blood of the Karui
Sanctified Life Flask
League: Domination, Nemesis
Variant: Pre 1.3.0
Variant: Pre 2.6.0
Variant: Pre 3.15.0
Variant: Pre 3.16.0
Variant: Current
{variant:3}100% increased Life Recovered
{variant:4,5}50% increased Life Recovered
{variant:1}(20-30)% reduced Recovery rate
{variant:2,3,4}(5-20)% increased Recovery rate
{variant:5}(35-50)% reduced Recovery rate
Recover Full Life at the end of the Effect
{variant:1,2}Cannot gain Life during effect
]],
-- Flask: Mana
[[
Doedre's Elixir
Greater Mana Flask
Variant: Pre 2.0.0
Variant: Pre 3.15.0
Variant: Current
Implicits: 0
{variant:1}(100-50)% increased Charges per use
{variant:2}(150-120)% increased Charges per use
{variant:3}(250-300)% increased Charges per use
{variant:1,2}Removes 20% of your maximum Energy Shield on use
{variant:3}Removes 80% of your maximum Energy Shield on use
{variant:1,2}You take 10% of your maximum Life as Chaos Damage on use
{variant:3}You take 50% of your maximum Life as Chaos Damage on use
{variant:1,2}Gain 1 Endurance Charge on use
{variant:3}Gain (1-3) Endurance Charge on use
{variant:1,2}Gain 1 Frenzy Charge on use
{variant:3}Gain (1-3) Frenzy Charge on use
{variant:1,2}Gain 1 Power Charge on use
{variant:3}Gain (1-3) Power Charge on use
]],[[
Lavianga's Spirit
Sanctified Mana Flask
League: Domination, Nemesis
(30-50)% increased Amount Recovered
100% increased Recovery rate
Skills Cost no Mana during Effect
]],[[
Replica Lavianga's Spirit
Sanctified Mana Flask
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
(30-50)% increased Amount Recovered
50% reduced Recovery rate
(5-15)% increased Attack Speed during Effect
(5-15)% increased Cast Speed during Effect
10% increased Mana Cost of Skills during Effect
]],[[
Zerphi's Last Breath
Grand Mana Flask
Variant: Pre 3.2.0
Variant: Current
League: Perandus
50% increased Charges per use
{variant:1}Grants Last Breath when you Use a Skill during Effect, for 800% of Mana Cost
{variant:2}Grants Last Breath when you Use a Skill during Effect, for (450-600)% of Mana Cost
]],[[
Wellwater Phylactery
Colossal Mana Flask
Source: Drops from unique{Uber Incarnation of Dread} in normal{Moment of Reverence}
Requires Level 64
(200-300)% increased Charges per use
(150-200)% increased Amount Recovered
(40-60)% less Duration
Removes (10-15)% of Life when Used
Starts Energy Shield Recharge when Used
Energy Shield Recharge is not delayed by Damage during Effect
]],
-- Flask: Hybrid
[[
Divination Distillate
Large Hybrid Flask
Variant: Pre 1.1.0
Variant: Pre 2.2.0
Variant: Pre 3.5.0
Variant: Pre 3.15.0
Variant: Pre 3.25.0
Variant: Current
{variant:1,2}+6% to all maximum Elemental Resistances during Effect
{variant:3}+4% to all maximum Elemental Resistances during Effect
{variant:1}(20-25)% increased Quantity of Items found during Effect
{variant:2,3,4}(12-18)% increased Quantity of Items found during Effect
{variant:5}(8-12)% increased Quantity of Items found during Effect
{variant:1,2,3,4}+(40-60)% to Item Rarity during Effect
{variant:5}+(20-30)% to Item Rarity during Effect
{variant:6}+(30-50)% to Item Rarity during Effect
25% increased Light Radius during Effect
{variant:4,5}+50% to Elemental Resistances during Effect
{variant:6}+10% to Elemental Resistances during Effect
]],[[
The Writhing Jar
Hallowed Hybrid Flask
(10-20)% reduced Charges per use
(65-75)% reduced Amount Recovered
Instant Recovery
2 Enemy Writhing Worms escape the Flask when used
Writhing Worms are destroyed when Hit
]],
-- Flask: Utility
[[
Atziri's Promise
Amethyst Flask
Source: Drops from unique{Atziri, Queen of the Vaal} in normal{The Apex of Sacrifice}
Variant: Pre 3.0.0
Variant: Pre 3.15.0
Variant: Current
Requires Level 68
{variant:1}Gain (13-15)% of Elemental Damage as Extra Chaos Damage during effect
{variant:2}Gain (10-15)% of Elemental Damage as Extra Chaos Damage during effect
{variant:3}Gain (5-8)% of Elemental Damage as Extra Chaos Damage during effect
2% of Chaos Damage Leeched as Life during Effect
{variant:1}Gain (22-25)% of Physical Damage as Extra Chaos Damage during effect
{variant:2}Gain (15-20)% of Physical Damage as Extra Chaos Damage during effect
{variant:3}Gain (5-8)% of Physical Damage as Extra Chaos Damage during effect
]],[[
Progenesis
Amethyst Flask
Source: Drops from unique{The Maven} (Uber)
Requires Level 60
(10-20)% reduced Charges per use
(-35-35)% reduced Duration
When Hit during effect, 25% of Life loss from Damage taken occurs over 4 seconds instead
]],[[
Bottled Faith
Sulphur Flask
League: Synthesis
Source: Drops from unique{Synthete Nightmare} in normal{The Cortex}
Variant: Pre 3.15.0
Variant: Pre 3.16.0
Variant: Current
Implicits: 1
Creates Consecrated Ground on Use
{variant:1}(30-50)% increased Duration
{variant:2}(20-40)% increased Duration
{variant:3}(15-30)% reduced Duration
Consecrated Ground created by this Flask has Tripled Radius
{variant:1}+(1-2)% to Critical Strike Chance against Enemies on Consecrated Ground during Effect
Consecrated Ground created during Effect applies (7-10)% increased Damage taken to Enemies
{variant:2,3}(100-150)% increased Critical Strike Chance against Enemies on Consecrated Ground during Effect
]],[[
Coralito's Signature
Diamond Flask
Variant: Pre 3.15.0
Variant: Current
25% chance to Poison on Hit during Effect
Your Critical Strikes do not deal extra Damage during Effect
{variant:1}(50-75)% increased Duration of Poisons you inflict during Effect
{variant:2}+(20-30)% to Damage over Time Multiplier for Poison from Critical Strikes during Effect
{variant:1}Take 30 Chaos Damage per Second during Effect
{variant:2}Take 250 Chaos Damage per Second during Effect
{variant:1}Grants Perfect Agony during effect
]],[[
Coruscating Elixir
Ruby Flask
Variant: Pre 2.6.0
Variant: Pre 3.16.0
Variant: Current
Implicits: 0
{variant:2}100% increased Duration
{variant:3}25% increased Duration
Chaos Damage taken does not bypass Energy Shield during effect
Removes all but one Life on use
Removed life is Regenerated as Energy Shield over 2 seconds
]],[[
Cinderswallow Urn
Silver Flask
League: Betrayal
Source: Drops from unique{Catarina, Master of Undeath}
Has Alt Variant: true
Selected Variant: 16
Selected Alt Variant: 6
Variant: Pre 3.26 Crit Chance
Variant: Damage Taken is Leeched as Life
Variant: Item Rarity
Variant: Pre 3.26 Movement Speed/Stun Avoidance
Variant: Stun Avoidance
Variant: Life Regen
Variant: Reduced Reflected Damage Taken
Variant: Physical Damage can Ignite
Variant: Ignited enemies have Malediction
Variant: Additional Curse
Variant: Ignite Spread
Variant: Ignite Leech
Variant: Pre 3.15.0
Variant: Pre 3.16.0 Crit Chance
Variant: Pre 3.26
Variant: Life on Kill
Variant: Mana on Kill
Variant: ES on Kill
Requires Level 48
Implicits: 0
{variant:15}+90 to Maximum Charges
{variant:16,17,18}+(10-20) to Maximum Charges
{variant:13}Recharges 1 Charge when you Consume an Ignited corpse
{variant:15,16,17,18}Recharges 5 Charges when you Consume an Ignited corpse
{variant:14}(175-200)% increased Charges per use
{variant:4,5}{crafted}50% Chance to Avoid being Stunned during Effect
{variant:11}{crafted}Ignites you inflict during Effect spread to other Enemies within 1.5 metres
{variant:9}{crafted}Enemies Ignited by you during Effect have Malediction
{variant:3}{crafted}+(20-30)% to Item Rarity during Effect
{variant:12}{crafted}Leech 1.5% of Expected Ignite Damage as Life when you Ignite an Enemy during Effect
{variant:2}{crafted}15% of Damage Taken from Hits is Leeched as Life during Effect
{variant:6}{crafted}Regenerate 3% of Life per second during Effect
{variant:10}{crafted}You can apply an additional Curse during Effect
{variant:8}{crafted}Your Physical Damage can Ignite during Effect
{variant:13}Enemies Ignited by you during Effect take 10% increased Damage
{variant:14,15,16,17,18}Enemies Ignited by you during Effect take (7-10)% increased Damage
{variant:13,15,16}Recover (1-3)% of Life when you Kill an Enemy during Effect
{variant:13,15,17}Recover (1-3)% of Mana when you Kill an Enemy during Effect
{variant:13,15,18}Recover (1-3)% of Energy Shield when you Kill an Enemy during Effect
{variant:14}{crafted}(60-80)% increased Critical Strike Chance during Effect
{variant:1}{crafted}(45-55)% increased Critical Strike Chance during Effect
{variant:4}{crafted}(8-12)% increased Movement Speed during Effect
{variant:7}{crafted}(60-80)% reduced Reflected Damage taken during Effect
]],[[
Dying Sun
Ruby Flask
Source: Drops from unique{The Shaper}
Variant: Pre 3.0.0
Variant: Pre 3.15.0
Variant: Pre 3.16.0
Variant: Current
Requires Level 68
{variant:2}(-10-10)% reduced Charges per use
{variant:3,4}(125-150)% increased Charges per use
{variant:3}(40-60)% reduced Duration
{variant:4}(40-60)% less Duration
{variant:1}30% increased Area of Effect during Effect
{variant:2}(15-25)% increased Area of Effect during Effect
{variant:3,4}(10-20)% increased Area of Effect during Effect
Skills fire 2 additional Projectiles during Effect
]],[[
Forbidden Taste
Quartz Flask
Variant: Pre 1.2.3
Variant: Pre 2.6.0
Variant: Pre 3.15.0
Variant: Current
{variant:1,2}50% increased Charges per use
{variant:1}Recover 50% of Life on use
{variant:2}Recover 75% of Life on use
{variant:3,4}Recover (75-100)% of Life on use
{variant:1}15% of Maximum Life taken as Chaos Damage per second
{variant:2,3}8% of Maximum Life taken as Chaos Damage per second
{variant:4}25% of Maximum Life taken as Chaos Damage per second
]],[[
Kiara's Determination
Silver Flask
Variant: Pre 3.0.0
Variant: Pre 3.15.0
Variant: Current
Implicits: 0
{variant:1}50% reduced Duration
{variant:2}60% reduced Duration
{variant:3}(60-80)% reduced Duration
Immunity to Freeze, Chill, Curses and Stuns during Effect
]],[[
Lion's Roar
Granite Flask
Variant: Pre 2.2.0
Variant: Pre 3.0.0
Variant: Pre 3.15.0
Variant: Current
{variant:1}(70-100)% increased Charges per use
Knocks Back Enemies in an Area when you use a Flask
75% chance to cause Enemies to Flee on use
Adds Knockback to Melee Attacks during Effect
{variant:1}30% more Melee Physical Damage during effect
{variant:2}(30-35)% more Melee Physical Damage during effect
{variant:3}(20-25)% more Melee Physical Damage during effect
{variant:4}(7-10)% more Melee Physical Damage during effect
]],[[
Rotgut
Quicksilver Flask
Variant: Pre 2.2.0
Variant: Pre 2.6.0
Variant: Pre 3.15.0
Variant: Current
Requires Level 40
{variant:1,2}15% chance to gain a Flask Charge when you deal a Critical Strike
{variant:3,4}50% chance to gain a Flask Charge when you deal a Critical Strike
{variant:1}(150-100)% increased Charges per use
{variant:2,3}(100-50)% increased Charges per use
{variant:3}50% increased Duration
{variant:4}(30-50)% increased Duration
Consumes Frenzy Charges on use
{variant:1,2}Gain Onslaught for 1 second per Frenzy Charge consumed on use
{variant:3}Gain Onslaught for 2 seconds per Frenzy Charge consumed on use
{variant:4}Gain Onslaught for 3 seconds per Frenzy Charge consumed on use
{variant:1,2,3}(10-30)% increased Movement Speed during Effect
]],[[
Rumi's Concoction
Granite Flask
Variant: Pre 1.3.0
Variant: Pre 2.5.0
Variant: Pre 3.15.0
Variant: Current
Requires Level 68
{variant:1}+(30-40)% Chance to Block Attack Damage during Effect
{variant:2}+(20-30)% Chance to Block Attack Damage during Effect
{variant:3}+(14-20)% Chance to Block Attack Damage during Effect
{variant:4}+(8-12)% Chance to Block Attack Damage during Effect
{variant:1}+(15-20)% Chance to Block Spell Damage during Effect
{variant:2}+(10-15)% Chance to Block Spell Damage during Effect
{variant:3}+(6-10)% Chance to Block Spell Damage during Effect
{variant:4}+(4-6)% Chance to Block Spell Damage during Effect
]],[[
Replica Rumi's Concoction
Granite Flask
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 68
90% reduced Duration
Gain 1 Endurance Charge on use
Petrified during Effect
+(35-50)% Chance to Block Attack Damage during Effect
+(20-30)% Chance to Block Spell Damage during Effect
]],[[
Sin's Rebirth
Stibnite Flask
Implicits: 1
Creates a Smoke Cloud on Use
Grants Immunity to Ignite for 4 seconds if used while Ignited
Removes all Burning when used
Unholy Might during Effect
]],[[
The Sorrow of the Divine
Sulphur Flask
Variant: Pre 3.7.0
Variant: Current
League: Legion
Implicits: 1
Creates Consecrated Ground on Use
{variant:2}Life Recovery from Flasks also applies to Energy Shield during Effect
{variant:2}Zealot's Oath during Effect
(25-50)% increased Duration
{variant:1}Zealot's Oath during Effect
]],[[
Replica Sorrow of the Divine
Sulphur Flask
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 1
Creates Consecrated Ground on Use
Life Recovery from Flasks also applies to Energy Shield during Effect
Eldritch Battery during Effect
(25-50)% increased Duration
]],[[
Soul Catcher
Quartz Flask
League: Incursion
Source: Drops from unique{The Vaal Omnitect}
Upgrade: Upgrades to unique{Soul Ripper} via currency{Vial of the Ghost}
Variant: Pre 3.10.0
Variant: Pre 3.15.0
Variant: Current
Cannot gain Mana during effect
{variant:2}(80-120)% increased Critical Strike Chance with Vaal Skills during effect
{variant:3}(60-80)% increased Critical Strike Chance with Vaal Skills during effect
{variant:1}(60-100)% increased Damage with Vaal Skills during effect
{variant:2}(80-120)% increased Damage with Vaal Skills during effect
{variant:3}(60-80)% increased Damage with Vaal Skills during effect
{variant:1}Non-Aura Vaal Skills require 25% reduced Souls Per Use during Effect
{variant:2}Vaal Skills used during effect have (20-40)% reduced Soul Gain Prevention Duration
{variant:3}Vaal Skills used during effect have 10% reduced Soul Gain Prevention Duration
]],[[
Soul Ripper
Quartz Flask
League: Incursion
Source: Upgraded from unique{Soul Catcher} via currency{Vial of the Ghost}
Variant: Pre 3.10.0
Variant: Current
{variant:2}+(-40-90) to Maximum Charges
{variant:1}100% increased Charges per use
{variant:2}Loses all Charges when you enter a new area
{variant:2}Consumes Maximum Charges to use
{variant:2}Gain Vaal Souls equal to Charges Consumed when used
{variant:1}Vaal Skills deal (30-40)% more Damage during Effect
{variant:1}Vaal Skills used during effect do not apply Soul Gain Prevention
{variant:1}Gains no Charges during Effect of any Soul Ripper Flask
]],[[
Stormblood
Sapphire Flask
League: Allflame
Source: Drops from unique{Velka, the Tide Witch}
Requires Level 36
(20-40)% chance to gain a Flask Charge when you deal a Critical Strike
All Damage from Critical Strikes can apply Cold Ailments during effect
50% reduced Duration
]],[[
Stormblood
Topaz Flask
League: Allflame
Source: Drops from unique{Velka, the Tide Witch}
Requires Level 36
(20-40)% chance to gain a Flask Charge when you deal a Critical Strike
All Damage from Critical Strikes can apply Lightning Ailments during effect
50% reduced Duration
]],[[
Taste of Hate
Sapphire Flask
Variant: Pre 2.2.0
Variant: Pre 3.0.0
Variant: Pre 3.15.0
Variant: Pre 3.25.0
Variant: Current
{variant:5}(20-30)% of Fire and Lightning Damage from Hits taken as Cold Damage during Effect
{variant:1}30% of Physical Damage from Hits taken as Cold Damage during Effect
{variant:2,3}20% of Physical Damage from Hits taken as Cold Damage during Effect
{variant:4}(10-15)% of Physical Damage from Hits taken as Cold Damage during Effect
{variant:1,2}Gain (20-30)% of Physical Damage as Extra Cold Damage during effect
{variant:3}Gain (15-20)% of Physical Damage as Extra Cold Damage during effect
{variant:4,5}Gain (10-15)% of Physical Damage as Extra Cold Damage during effect
30% chance to Avoid being Chilled during Effect
30% chance to Avoid being Frozen during Effect
]],[[
The Overflowing Chalice
Sulphur Flask
Variant: Pre 3.15.0
Variant: Current
Implicits: 1
Creates Consecrated Ground on Use
{variant:1}100% increased Charge Recovery
{variant:2}(40-60)% increased Charge Recovery
{variant:1}(10-20)% increased Duration
{variant:1}100% increased Charges gained by Other Flasks during Effect
{variant:2}(50-100)% increased Charges gained by Other Flasks during Effect
Gains no Charges during Effect of any Overflowing Chalice Flask
]],[[
Vessel of Vinktar
Topaz Flask
Source: Drops from unique{Avatar of Thunder} in unique{The Vinktar Square}
Variant: Pre 2.2.0 (Penetration)
Variant: Pre 2.2.0 (Spells)
Variant: Pre 2.2.0 (Attacks)
Variant: Pre 2.2.0 (Conversion)
Variant: Pre 3.0.0 (Penetration)
Variant: Pre 3.0.0 (Spells)
Variant: Pre 3.0.0 (Attacks)
Variant: Pre 3.0.0 (Conversion)
Variant: Pre 3.14.0 (Spells)
Variant: Pre 3.14.0 (Conversion)
Variant: Pre 3.15.0 (Penetration)
Variant: Pre 3.15.0 (Spells)
Variant: Pre 3.15.0 (Attacks)
Variant: Current (Conversion)
Variant: Current (Proliferation)
Variant: Current (Penetration)
Variant: Current (Spells)
Variant: Current (Attacks)
Requires Level 68
{variant:5,6,7,8,9,10,11,12,13}(80-100)% increased Charges per use
{variant:14,15,16,17,18}(125-150)% increased Charges per use
Shocks Enemies within 3 metres during Effect, causing 10% increased Damage taken
You are Shocked during Effect, causing 50% increased Damage taken
{variant:4,8,10}20% of Physical Damage Converted to Lightning during Effect
{variant:14}50% of Physical Damage Converted to Lightning during Effect
{variant:1,5,11}Damage Penetrates 10% Lightning Resistance during Effect
{variant:16}Damage Penetrates 6% Lightning Resistance during Effect
{variant:15}(25-40)% increased Effect of Shocks you inflict during Effect
{variant:15}Shocks you inflict during Effect spread to other Enemies within 2 metres
{variant:3,7,13}Adds (25-35) to (110-130) Lightning Damage to Attacks during Effect
{variant:18}Adds (10-15) to (55-65) Lightning Damage to Attacks during Effect
{variant:2,6,9}Adds (15-25) to (70-90) Lightning Damage to Spells during Effect
{variant:12}Adds (25-35) to (110-130) Lightning Damage to Spells during Effect
{variant:17}Adds (10-15) to (55-65) Lightning Damage to Spells during Effect
{variant:1,2,3,4}30% of Lightning Damage Leeched as Life during Effect
{variant:5,6,7,8,9,10,11,12,13,14,15,16,17,18}20% of Lightning Damage Leeched as Life during Effect
{variant:1,2,3,4}30% of Lightning Damage Leeched as Mana during Effect
{variant:5,6,7,8}20% of Lightning Damage Leeched as Mana during Effect
{variant:1,2,3,4}Life and Mana Leech are instant during effect
]],[[
The Wise Oak
Bismuth Flask
Variant: Pre 3.0.0
Variant: Pre 3.15.0
Variant: Current
{variant:1,2}During Effect, 10% reduced Damage taken of each Element for which your Uncapped Elemental Resistance is lowest
{variant:3}During Effect, 6% reduced Damage taken of each Element for which your Uncapped Elemental Resistance is lowest
{variant:1}During Effect, Damage Penetrates 20% Resistance of each Element for which your Uncapped Elemental Resistance is highest
{variant:2}During Effect, Damage Penetrates (10-15)% Resistance of each Element for which your Uncapped Elemental Resistance is highest
{variant:3}During Effect, Damage Penetrates (5-8)% Resistance of each Element for which your Uncapped Elemental Resistance is highest
]],[[
Oriath's End
Bismuth Flask
Source: Drops from unique{Sirus, Awakener of Worlds} (Uber)
Requires Level 56
(20-40)% increased Charge Recovery
Enemies you Kill during Effect have a (20-30)% chance to Explode, dealing a tenth of their maximum Life as Damage of a Random Element
]],[[
Witchfire Brew
Stibnite Flask
Variant: Pre 3.0.0
Variant: Pre 3.15.0
Variant: Current
Requires Level 48
Implicits: 1
Creates a Smoke Cloud on Use
{variant:1,2}50% increased Charges per use
{variant:3}(-10-10)% reduced Charges per use
Grants Level 21 Despair Curse Aura during Effect
{variant:1}(50-70)% increased Damage Over Time during Effect
{variant:2}(25-40)% increased Damage Over Time during Effect
]],[[
Replica Witchfire Brew
Stibnite Flask
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 48
Implicits: 1
Creates a Smoke Cloud on Use
(-10-10)% reduced Charges per use
Grants Level 21 Vulnerability Curse Aura during Effect
]],[[
Wine of the Prophet
Gold Flask
Source: Drops from unique{Incarnation of Dread} in normal{Moment of Reverence}
Requires Level 33
+60 to Maximum Charges
(20-100)% increased Charges per use
Grants a random Divination Buff for 20 seconds when Used
]],
-- Flask: Ward
[[
Elixir of the Unbroken Circle
Iron Flask
Variant: Pre 3.25.0
Variant: Current
League: Expedition
Source: Drops from unique{Medved, Feller of Heroes} in normal{Expedition Logbook}
Implicits: 1
Restores Ward on use
{variant:1}(20-40)% increased Duration
{variant:2}(50-80)% increased Duration
Recover 4% of Life per Endurance Charge on use
Lose all Endurance Charges on use
Gain 1 Endurance Charge per Second during Effect
]],[[
Olroth's Resolve
Iron Flask
Variant: Pre 3.25.0
Variant: Current
League: Expedition
Source: Drops from unique{Olroth, Origin of the Fall} in normal{Expedition Logbook}
Implicits: 1
Restores Ward on use
(50-40)% increased Charges per use
Ward does not Break during Effect
{variant:1}70% less Ward during Effect
{variant:2}85% less Ward during Effect
]],[[
Starlight Chalice
Iron Flask
League: Expedition
Source: Drops from unique{Uhtred, Covetous Traitor} in normal{Expedition Logbook}
Implicits: 1
Restores Ward on use
(20-30)% increased Charge Recovery
Inflict Fire, Cold and Lightning Exposure on Enemies within 3 metres when used
(20-30)% increased Effect of Non-Damaging Ailments you inflict during Effect
]],[[
Vorana's Preparation
Iron Flask
League: Expedition
Source: Drops from unique{Vorana, Last to Fall} in normal{Expedition Logbook}
Implicits: 1
Restores Ward on use
(-10-10)% reduced Charges per use
Debilitate Enemies within 3 metres for 2 Seconds when Effect ends
Effect is removed when Ward Breaks
Culling Strike during Effect
]],
}
