-- Item data (c) Grinding Gear Games

return {
-- Weapon: Dagger
[[
Arakaali's Fang
Fiend Dagger
Variant: Pre 3.29.0
Variant: Current
Implicits: 2
{variant:2}(50-55)% increased Global Critical Strike Chance
{variant:1}40% increased Global Critical Strike Chance
Trigger Level 1 Raise Spiders on Kill
(170-200)% increased Physical Damage
Adds (8-13) to (20-30) Physical Damage
Adds 1 to 59 Chaos Damage
15% chance to Poison on Hit
]],[[
Bino's Kitchen Knife
Slaughter Knife
Variant: Pre 2.2.0
Variant: Pre 3.20.0
Variant: Pre 3.28.0
Variant: Current
Requires Level 65
Implicits: 2
{variant:4}(40-45)% increased Global Critical Strike Chance
{variant:1,2,3}30% increased Global Critical Strike Chance
{variant:1,2}30% increased Damage over Time
{variant:1,2}Adds (50-60) to (120-140) Physical Damage
{variant:3,4}Adds (140-155) to (210-235) Physical Damage
(40-50)% increased Critical Strike Chance
{variant:1}+(10-15)% to Global Critical Strike Multiplier
{variant:2,3,4}+(15-25)% to Global Critical Strike Multiplier
{variant:3}+(8-12)% to Chaos Resistance
{variant:4}+(17-29)% to Chaos Resistance
{variant:1,2,3,4}On Killing a Poisoned Enemy, Enemies within 3 metres are Poisoned, and you and
{variant:1,2,3,4}Allies Regenerate 400 Life per second for the Poison's duration if within 3 metres
]],[[
Bloodplay
Stiletto
Variant: Pre 2.6.0
Variant: Current
Implicits: 2
{variant:2}(40-45)% increased Global Critical Strike Chance
{variant:1}30% increased Global Critical Strike Chance
+20 to Dexterity
(20-40)% increased Physical Damage
Adds (3-6) to (9-13) Physical Damage
10% increased Attack Speed
{variant:1}10% chance to cause Bleeding on Hit
{variant:2}30% chance to cause Bleeding on Hit
Extra gore
]],[[
Replica Bloodplay
Stiletto
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Variant: Pre 3.29.0
Variant: Current
Implicits: 2
{variant:2}(40-45)% increased Global Critical Strike Chance
{variant:1}30% increased Global Critical Strike Chance
+20 to Strength
(20-40)% increased Physical Damage
Adds (3-6) to (9-13) Physical Damage
30% chance to cause Bleeding on Hit
(100-150)% increased Critical Strike Chance against Bleeding Enemies
Extra gore
]],[[
Cold Iron Point
Ezomyte Dagger
Variant: Pre 3.29.0
Variant: Current
Implicits: 2
{variant:2}(40-45)% increased Global Critical Strike Chance
{variant:1}30% increased Global Critical Strike Chance
+3 to Level of all Physical Spell Skill Gems
Deal no Elemental Damage
]],[[
Replica Cold Iron Point
Ezomyte Dagger
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Variant: Pre 3.29.0
Variant: Current
Implicits: 2
{variant:2}(40-45)% increased Global Critical Strike Chance
{variant:1}30% increased Global Critical Strike Chance
+3 to Level of all Cold Spell Skill Gems
Deal no Cold Damage
]],[[
The Consuming Dark
Fiend Dagger
Variant: Pre 2.2.0
Variant: Pre 3.0.0
Variant: Current
Implicits: 2
{variant:3}(50-55)% increased Global Critical Strike Chance
{variant:1,2}40% increased Global Critical Strike Chance
+(20-40) to Intelligence
(40-60)% increased Fire Damage
+1 to Level of all Fire Spell Skill Gems
{variant:1}45% of Fire Damage Converted to Chaos Damage
{variant:2,3}30% of Fire Damage Converted to Chaos Damage
{variant:1,2}Your Chaos Damage Poisons Enemies
{variant:3}Your Chaos Damage has 60% chance to Poison Enemies
]],[[
Divinarius
Imperial Skean
League: Legion
Variant: Pre 3.7.0
Variant: Pre 3.20.0
Variant: Current
Implicits: 2
{variant:3}(40-45)% increased Global Critical Strike Chance
{variant:1,2}30% increased Global Critical Strike Chance
{variant:1,2}(50-70)% increased Spell Damage
{variant:3}(150-200)% increased Spell Damage
{variant:1}Gain 10 Life per Enemy Killed
{variant:2}Gain 30 Life per Enemy Killed
{variant:3}Gain (100-200) Life per Enemy Killed
{variant:1}Gain 5 Mana per Enemy Killed
{variant:2}Gain 10 Mana per Enemy Killed
{variant:3}Gain (50-100) Mana per Enemy Killed
{variant:1,2}10% increased Area of Effect
{variant:3}30% increased Area of Effect
{variant:2}(125-175)% increased Critical Strike Chance for Spells if you've Killed Recently
{variant:3}(200-250)% increased Critical Strike Chance for Spells if you've Killed Recently
{variant:2}+(40-60)% to Critical Strike Multiplier for Spells if you haven't Killed Recently
{variant:3}+(60-100)% to Critical Strike Multiplier for Spells if you haven't Killed Recently
]],[[
Goredrill
Skinning Knife
Variant: Pre 3.29.0
Variant: Current
Implicits: 2
{variant:2}(40-45)% increased Global Critical Strike Chance
{variant:1}30% increased Global Critical Strike Chance
+(10-15) to Dexterity
(50-70)% increased Physical Damage
Adds (1-2) to (3-5) Physical Damage
30% increased Critical Strike Chance
40% increased Attack Damage against Bleeding Enemies
50% chance to cause Bleeding on Critical Strike
]],[[
Sanguine Gambol
Skinning Knife
Source: No longer obtainable
Requires Level 59
Implicits: 1
30% increased Global Critical Strike Chance
+(10-15) to Dexterity
(50-70)% increased Physical Damage
Adds (70-85) to (110-118) Physical Damage
30% increased Critical Strike Chance
40% increased Attack Damage against Bleeding Enemies
50% chance to Cause Bleeding on Critical Strike
You have Crimson Dance if you have dealt a Critical Strike Recently
]],[[
Goblinedge
Ambusher
League: Ritual
Variant: Pre 3.29.0
Variant: Current
Implicits: 2
{variant:2}(40-45)% increased Global Critical Strike Chance
{variant:1}30% increased Global Critical Strike Chance
(200-250)% increased Physical Damage
(20-25)% increased Attack Speed if you haven't gained a Frenzy Charge Recently
(60-80)% increased Critical Strike Chance if you haven't gained a Power Charge Recently
+3 seconds to Duration of Frenzy and Power Charges on Culling Strike
Gain (120-150) Life on Culling Strike
Gain (10-20) Mana on Culling Strike
]],[[
Heartbreaker
Royal Skean
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 2
{variant:3}(40-45)% increased Global Critical Strike Chance
{variant:1,2}30% increased Global Critical Strike Chance
{variant:1}(40-50)% increased Spell Damage
{variant:2,3}(60-70)% increased Spell Damage
{variant:1,2}+50 to maximum Energy Shield
{variant:1,2}10% faster start of Energy Shield Recharge
{variant:3}(40-80)% faster start of Energy Shield Recharge
{variant:1,2}+(40-50) to maximum Mana
{variant:3}+(60-100) to maximum Mana
Your Spells have Culling Strike
]],[[
Replica Heartbreaker
Royal Skean
Variant: Pre 3.19.0
Variant: Current
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 2
{variant:2}(40-45)% increased Global Critical Strike Chance
{variant:1}30% increased Global Critical Strike Chance
(60-70)% increased Spell Damage
{variant:1}+50 to maximum Energy Shield
{variant:1}10% faster start of Energy Shield Recharge
{variant:2}(40-80)% faster start of Energy Shield Recharge
{variant:1}+(40-50) to maximum Life
{variant:2}+(30-50) to maximum Life
20% increased Impale Effect
20% chance to Impale on Spell Hit
]],[[
The Hidden Blade
Ambusher
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Variant: Pre 3.29.0
Variant: Current
Implicits: 2
{variant:2}(40-45)% increased Global Critical Strike Chance
{variant:1}30% increased Global Critical Strike Chance
Trigger Level 20 Unseen Strike every 0.5 seconds while Phasing
+(20-40) to Dexterity
(230-260)% increased Physical Damage
30% reduced Attack Speed while Phasing
]],[[
Mark of the Doubting Knight
Platinum Kris
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.26.0
Variant: Current
Implicits: 2
{variant:4}(60-65)% increased Global Critical Strike Chance
{variant:1,2,3}50% increased Global Critical Strike Chance
+5% Chance to Block Attack Damage while Dual Wielding
{variant:1}(180-210)% increased Physical Damage
{variant:2}(210-240)% increased Physical Damage
{variant:3,4}(250-270)% increased Physical Damage
{variant:1,2,3}10% increased Attack Speed
{variant:4}20% reduced Attack Speed
{variant:4}(20-30)% increased Critical Strike Chance
{variant:4}+(30-40)% to Global Critical Strike Multiplier
{variant:1,2,3}+(6-10)% to all Elemental Resistances
{variant:3,4}50% chance to Cause Bleeding on Critical Strike
{variant:3,4}50% chance to Cause Poison on Critical Strike
{variant:1,2}Melee Critical Strikes have 25% chance to cause Bleeding
{variant:1,2}Melee Critical Strikes have 25% chance to Poison the Enemy
]],[[
Mightflay
Flaying Knife
Variant: Pre 3.29.0
Variant: Current
Implicits: 2
{variant:2}(40-45)% increased Global Critical Strike Chance
{variant:1}30% increased Global Critical Strike Chance
+25 to Strength
(80-100)% increased Physical Damage
Adds 12 to 24 Physical Damage
Grants 10 Life per Enemy Hit
]],[[
Taproot
Ambusher
Variant: Pre 3.29.0
Variant: Current
Implicits: 2
{variant:2}(40-45)% increased Global Critical Strike Chance
{variant:1}30% increased Global Critical Strike Chance
(180-200)% increased Physical Damage
(10-15)% increased Attack Speed
(15-20)% increased Poison Duration
0.5% of Attack Damage Leeched as Mana against Poisoned Enemies
0.5% of Attack Damage Leeched as Life against Maimed Enemies
(15-20)% chance to Maim on Hit
20% chance to Poison on Hit
]],[[
Ungil's Gauche
Boot Knife
Variant: Pre 1.1.0
Variant: Pre 1.3.0
Variant: Current
Implicits: 2
{variant:3}(40-45)% increased Global Critical Strike Chance
{variant:1,2}30% increased Global Critical Strike Chance
{variant:2}+20% Chance to Block Attack Damage while Dual Wielding
{variant:1,3}+12% Chance to Block Attack Damage while Dual Wielding
+(10-20) to Dexterity
(80-100)% increased Physical Damage
Adds 3 to 30 Lightning Damage
10% increased Attack Speed
50% increased Global Critical Strike Chance
]],[[
Replica Ungil's Gauche
Boot Knife
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Variant: Pre 3.29.0
Variant: Current
Implicits: 2
{variant:2}(40-45)% increased Global Critical Strike Chance
{variant:1}30% increased Global Critical Strike Chance
+18% Chance to Block Attack Damage while Dual Wielding
+(10-20) to Dexterity
10% increased Attack Speed
50% increased Global Critical Strike Chance
Chill Attackers for 4 seconds on Block
Shock Attackers for 4 seconds on Block
]],[[
Vulconus
Demon Dagger
Variant: Pre 3.5.0
Variant: Current
Implicits: 1
(50-55)% increased Global Critical Strike Chance
Adds (85-110) to (135-150) Physical Damage
Adds (130-160) to (220-240) Fire Damage
{variant:2}50% chance to cause Bleeding on Hit
{variant:1}Attacks with this Weapon deal (80-100) to (160-200) added Fire Damage to Bleeding Enemies
{variant:1}Attacks with this Weapon deal (80-100) to (160-200) added Physical Damage to Ignited Enemies
{variant:1}Attacks with this Weapon have 25% chance to inflict Bleeding against Ignited Enemies
{variant:2}(70-100)% increased Fire Damage with Hits and Ailments against Bleeding Enemies
{variant:2}(70-100)% increased Physical Damage with Hits and Ailments against Ignited Enemies
Every 8 seconds, gain Avatar of Fire for 4 seconds
{variant:1}(80-120)% increased Critical Strike Chance while you have Avatar of Fire
{variant:2}(160-200)% increased Critical Strike Chance while you have Avatar of Fire
50% of Physical Damage Converted to Fire while you have Avatar of Fire
{variant:1}+1000 Armour while you do not have Avatar of Fire
{variant:2}+2000 Armour while you do not have Avatar of Fire
]],[[
White Wind
Imperial Skean
Variant: Pre 3.11.0
Variant: Pre 3.16.0
Variant: Current
Implicits: 1
(40-45)% increased Global Critical Strike Chance
Adds (160-190) to (280-320) Cold Damage
(10-15)% increased Attack Speed
{variant:1}+(300-400) to Evasion Rating
{variant:2,3}+(1000-1500) to Evasion Rating
{variant:1}100% increased Cold Damage while your Off Hand is empty
{variant:2,3}(100-200)% increased Cold Damage while your Off Hand is empty
{variant:1,2}+(15-25)% chance to Suppress Spell Damage while your Off Hand is empty
{variant:3}+(30-40)% chance to Suppress Spell Damage while your Off Hand is empty
]],[[
Widowmaker
Boot Blade
Variant: Pre 3.0.0
Variant: Current
Implicits: 2
{variant:2}(40-45)% increased Global Critical Strike Chance
{variant:1}30% increased Global Critical Strike Chance
{variant:1}Adds (15-25) to (35-45) Physical Damage
{variant:2}Adds (35-40) to (55-60) Physical Damage
(22-30)% increased Critical Strike Chance
+(30-40)% to Global Critical Strike Multiplier
100% increased Critical Strike Chance against Enemies that are on Full Life
1% of Attack Damage Leeched as Life on Critical Strike
]],
[[
Festering Resentment
Demon Dagger
Source: Drops from unique{Uber Incarnation of Neglect} in normal{Moment of Loneliness}
Variant: Pre 3.29.0
Variant: Current
Implicits: 2
{variant:2}(50-55)% increased Global Critical Strike Chance
{variant:1}40% increased Global Critical Strike Chance
Trigger a Socketed Spell when you Block, with a 0.25 second Cooldown
+(30-45)% Chance to Block Spell Damage while in Off Hand
(100-150)% increased Spell Damage
(100-150)% increased Damage with Poison
Triggered Spells Poison on Hit
All Damage with Triggered Spells can Poison
]],
}
